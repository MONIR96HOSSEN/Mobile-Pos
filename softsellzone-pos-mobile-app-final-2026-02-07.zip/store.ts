import React, { createContext, useContext, useState, useEffect } from 'react';
import { AppData, Sale, Purchase, Product, Customer, Supplier, LedgerEntry, User, Expense, Reminder, SaleReturn, PurchaseReturn, Wastage } from './types';
import { INITIAL_DATA } from './constants';

interface StoreContextType {
  data: AppData;
  currentUser: User | null;
  login: (username: string, password: string) => boolean;
  logout: () => void;
  updateCurrentUser: (userData: Partial<User>) => void;
  addUser: (user: Omit<User, 'id'>) => void;
  updateUser: (id: string, userData: Partial<User>) => void;
  deleteUser: (userId: string) => void;
  addSale: (sale: Omit<Sale, 'id' | 'invoiceNo'>) => void;
  deleteSale: (saleId: string) => void;
  addPurchase: (purchase: Omit<Purchase, 'id'>) => void;
  addSaleReturn: (ret: Omit<SaleReturn, 'id'>) => void;
  deleteSaleReturn: (retId: string) => void;
  addPurchaseReturn: (ret: Omit<PurchaseReturn, 'id'>) => void;
  deletePurchaseReturn: (retId: string) => void;
  addWastage: (waste: Omit<Wastage, 'id'>) => void;
  deleteWastage: (wasteId: string) => void;
  addProduct: (product: Omit<Product, 'id'>) => void;
  updateProduct: (id: string, product: Partial<Product>) => void;
  deleteProduct: (id: string) => void;
  addCustomer: (customer: Omit<Customer, 'id'>) => void;
  addSupplier: (supplier: Omit<Supplier, 'id'>) => void;
  addExpense: (expense: Omit<Expense, 'id'>) => void;
  updateExpense: (id: string, expense: Partial<Expense>) => void;
  deleteExpense: (id: string) => void;
  addReminder: (reminder: Omit<Reminder, 'id' | 'completed'>) => void;
  updateReminder: (id: string, reminder: Partial<Reminder>) => void;
  deleteReminder: (id: string) => void;
  toggleReminder: (id: string) => void;
  collectDue: (customerId: string, amount: number, note: string) => void;
  paySupplier: (supplierId: string, amount: number, note: string) => void;
  updateSettings: (settings: AppData['settings']) => void;
  importData: (newData: AppData) => void;
  resetDatabase: () => void;
  language: 'en' | 'bn';
  setLanguage: (lang: 'en' | 'bn') => void;
}

const StoreContext = createContext<StoreContextType | undefined>(undefined);

export const StoreProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [data, setData] = useState<AppData>(() => {
    const saved = localStorage.getItem('hisab_nikash_data');
    return saved ? JSON.parse(saved) : INITIAL_DATA;
  });
  const [language, setLanguage] = useState<'en' | 'bn'>('bn');
  const [currentUser, setCurrentUser] = useState<User | null>(() => {
    const saved = localStorage.getItem('hisab_nikash_user');
    return saved ? JSON.parse(saved) : null;
  });

  useEffect(() => {
    localStorage.setItem('hisab_nikash_data', JSON.stringify(data));
  }, [data]);

  useEffect(() => {
    localStorage.setItem('hisab_nikash_user', JSON.stringify(currentUser));
  }, [currentUser]);

  const login = (username: string, password: string) => {
    const user = data.users.find(u => u.username === username && u.password === password);
    if (user) {
      setCurrentUser(user);
      return true;
    }
    return false;
  };

  const logout = () => {
    setCurrentUser(null);
  };

  const updateCurrentUser = (userData: Partial<User>) => {
    if (!currentUser) return;
    const updated = { ...currentUser, ...userData };
    setCurrentUser(updated);
    setData(prev => ({
      ...prev,
      users: prev.users.map(u => u.id === currentUser.id ? updated : u)
    }));
  };

  const addUser = (userData: Omit<User, 'id'>) => {
    const newUser = { ...userData, id: Date.now().toString() };
    setData(prev => ({ ...prev, users: [...prev.users, newUser] }));
  };

  const updateUser = (id: string, userData: Partial<User>) => {
    setData(prev => ({
      ...prev,
      users: prev.users.map(u => u.id === id ? { ...u, ...userData } : u)
    }));
  };

  const deleteUser = (userId: string) => {
    setData(prev => ({ ...prev, users: prev.users.filter(u => u.id !== userId) }));
  };

  const importData = (newData: AppData) => {
    setData(newData);
    localStorage.setItem('hisab_nikash_data', JSON.stringify(newData));
  };

  const resetDatabase = () => {
    const freshData: AppData = {
      ...INITIAL_DATA,
      settings: data.settings,
      users: data.users,
      products: [],
      customers: [{ id: 'c1', name: 'Walk-in Customer', phone: '0000000000', address: 'N/A', balance: 0 }],
      suppliers: [],
      sales: [],
      purchases: [],
      saleReturns: [],
      purchaseReturns: [],
      wastages: [],
      ledgers: [],
      expenses: [],
      reminders: []
    };
    setData(freshData);
  };

  const addSale = (saleData: Omit<Sale, 'id' | 'invoiceNo'>) => {
    const id = Date.now().toString();
    const invoiceNo = `INV-${data.sales.length + 1001}`;
    const newSale: Sale = { ...saleData, id, invoiceNo };

    setData(prev => {
      const updatedProducts = prev.products.map(p => {
        const item = saleData.items.find(i => i.productId === p.id);
        return item ? { ...p, stock: p.stock - item.quantity } : p;
      });

      const updatedCustomers = prev.customers.map(c => {
        if (c.id === saleData.customerId) {
          return { ...c, balance: c.balance + saleData.dueAmount };
        }
        return c;
      });

      const newLedgers = [...prev.ledgers];
      if (saleData.dueAmount > 0) {
        const customer = updatedCustomers.find(c => c.id === saleData.customerId);
        newLedgers.push({
          id: `L-${Date.now()}`,
          date: saleData.date,
          entityId: saleData.customerId,
          entityType: 'Customer',
          type: 'Debit',
          amount: saleData.dueAmount,
          description: `Sale ${invoiceNo}`,
          balanceAfter: customer?.balance || 0
        });
      }

      return {
        ...prev,
        sales: [newSale, ...prev.sales],
        products: updatedProducts,
        customers: updatedCustomers,
        ledgers: newLedgers
      };
    });
  };

  const deleteSale = (saleId: string) => {
    setData(prev => {
      const sale = prev.sales.find(s => s.id === saleId);
      if (!sale) return prev;
      const updatedProducts = prev.products.map(p => {
        const item = sale.items.find(i => i.productId === p.id);
        return item ? { ...p, stock: p.stock + item.quantity } : p;
      });
      const updatedCustomers = prev.customers.map(c => {
        if (c.id === sale.customerId) {
          return { ...c, balance: Math.max(0, c.balance - sale.dueAmount) };
        }
        return c;
      });
      const updatedLedgers = prev.ledgers.filter(l => !l.description.includes(sale.invoiceNo));
      return {
        ...prev,
        sales: prev.sales.filter(s => s.id !== saleId),
        products: updatedProducts,
        customers: updatedCustomers,
        ledgers: updatedLedgers
      };
    });
  };

  const addPurchase = (purchaseData: Omit<Purchase, 'id'>) => {
    const id = Date.now().toString();
    const newPurchase: Purchase = { ...purchaseData, id };
    setData(prev => {
      const updatedProducts = prev.products.map(p => {
        const item = purchaseData.items.find(i => i.productId === p.id);
        return item ? { ...p, stock: p.stock + item.quantity } : p;
      });
      const updatedSuppliers = prev.suppliers.map(s => {
        if (s.id === purchaseData.supplierId) {
          return { ...s, balance: s.balance + purchaseData.dueAmount };
        }
        return s;
      });
      const newLedgers = [...prev.ledgers];
      if (purchaseData.dueAmount > 0) {
        const supplier = updatedSuppliers.find(s => s.id === purchaseData.supplierId);
        newLedgers.push({
          id: `PL-${Date.now()}`,
          date: purchaseData.date,
          entityId: purchaseData.supplierId,
          entityType: 'Supplier',
          type: 'Debit',
          amount: purchaseData.dueAmount,
          description: `Purchase ID ${id}`,
          balanceAfter: supplier?.balance || 0
        });
      }
      return {
        ...prev,
        purchases: [newPurchase, ...prev.purchases],
        products: updatedProducts,
        suppliers: updatedSuppliers,
        ledgers: newLedgers
      };
    });
  };

  const addSaleReturn = (retData: Omit<SaleReturn, 'id'>) => {
    const id = `SR-${Date.now()}`;
    setData(prev => {
      const sale = prev.sales.find(s => s.id === retData.saleId);
      if (!sale) return prev;

      // Update Stock
      const updatedProducts = prev.products.map(p => {
        const item = retData.items.find(i => i.productId === p.id);
        return item ? { ...p, stock: p.stock + item.quantity } : p;
      });

      // Update Customer Balance (Reduce due first)
      const updatedCustomers = prev.customers.map(c => {
        if (c.id === sale.customerId) {
            return { ...c, balance: Math.max(0, c.balance - retData.total) };
        }
        return c;
      });

      const customer = updatedCustomers.find(c => c.id === sale.customerId);
      const newLedger: LedgerEntry = {
        id: `LSR-${Date.now()}`,
        date: retData.date,
        entityId: sale.customerId,
        entityType: 'Customer',
        type: 'Credit',
        amount: retData.total,
        description: `Sale Return (Ref: ${sale.invoiceNo})`,
        balanceAfter: customer?.balance || 0
      };

      return {
        ...prev,
        saleReturns: [ { ...retData, id }, ...prev.saleReturns ],
        products: updatedProducts,
        customers: updatedCustomers,
        ledgers: [newLedger, ...prev.ledgers]
      };
    });
  };

  const deleteSaleReturn = (retId: string) => {
    setData(prev => {
      const ret = prev.saleReturns.find(r => r.id === retId);
      if (!ret) return prev;
      const sale = prev.sales.find(s => s.id === ret.saleId);
      if (!sale) return prev;

      // Revert Stock
      const updatedProducts = prev.products.map(p => {
        const item = ret.items.find(i => i.productId === p.id);
        return item ? { ...p, stock: Math.max(0, p.stock - item.quantity) } : p;
      });

      // Revert Customer Balance (Increase due again)
      const updatedCustomers = prev.customers.map(c => {
        if (c.id === sale.customerId) {
            return { ...c, balance: c.balance + ret.total };
        }
        return c;
      });

      // Remove Ledger entries matching this return
      const updatedLedgers = prev.ledgers.filter(l => !(l.description.includes(sale.invoiceNo) && l.description.includes('Sale Return')));

      return {
        ...prev,
        saleReturns: prev.saleReturns.filter(r => r.id !== retId),
        products: updatedProducts,
        customers: updatedCustomers,
        ledgers: updatedLedgers
      };
    });
  };

  const addPurchaseReturn = (retData: Omit<PurchaseReturn, 'id'>) => {
    const id = `PR-${Date.now()}`;
    setData(prev => {
      const purchase = prev.purchases.find(p => p.id === retData.purchaseId);
      if (!purchase) return prev;

      // Update Stock
      const updatedProducts = prev.products.map(p => {
        const item = retData.items.find(i => i.productId === p.id);
        return item ? { ...p, stock: p.stock - item.quantity } : p;
      });

      // Update Supplier Balance (Reduce due)
      const updatedSuppliers = prev.suppliers.map(s => {
        if (s.id === purchase.supplierId) {
            return { ...s, balance: Math.max(0, s.balance - retData.total) };
        }
        return s;
      });

      const supplier = updatedSuppliers.find(s => s.id === purchase.supplierId);
      const newLedger: LedgerEntry = {
        id: `LPR-${Date.now()}`,
        date: retData.date,
        entityId: purchase.supplierId,
        entityType: 'Supplier',
        type: 'Credit',
        amount: retData.total,
        description: `Purchase Return (Ref: ${purchase.id.slice(-6)})`,
        balanceAfter: supplier?.balance || 0
      };

      return {
        ...prev,
        purchaseReturns: [ { ...retData, id }, ...prev.purchaseReturns ],
        products: updatedProducts,
        suppliers: updatedSuppliers,
        ledgers: [newLedger, ...prev.ledgers]
      };
    });
  };

  const deletePurchaseReturn = (retId: string) => {
    setData(prev => {
        const ret = prev.purchaseReturns.find(r => r.id === retId);
        if (!ret) return prev;
        const purchase = prev.purchases.find(p => p.id === ret.purchaseId);
        if (!purchase) return prev;

        // Revert Stock (Add back)
        const updatedProducts = prev.products.map(p => {
            const item = ret.items.find(i => i.productId === p.id);
            return item ? { ...p, stock: p.stock + item.quantity } : p;
        });

        // Revert Supplier Balance (Increase due again)
        const updatedSuppliers = prev.suppliers.map(s => {
            if (s.id === purchase.supplierId) {
                return { ...s, balance: s.balance + ret.total };
            }
            return s;
        });

        const updatedLedgers = prev.ledgers.filter(l => !(l.description.includes(purchase.id.slice(-6)) && l.description.includes('Purchase Return')));

        return {
            ...prev,
            purchaseReturns: prev.purchaseReturns.filter(r => r.id !== retId),
            products: updatedProducts,
            suppliers: updatedSuppliers,
            ledgers: updatedLedgers
        };
    });
  };

  const addWastage = (wasteData: Omit<Wastage, 'id'>) => {
    const id = `WST-${Date.now()}`;
    setData(prev => {
        const updatedProducts = prev.products.map(p => 
            p.id === wasteData.productId ? { ...p, stock: p.stock - wasteData.quantity } : p
        );
        return {
            ...prev,
            wastages: [ { ...wasteData, id }, ...prev.wastages ],
            products: updatedProducts
        };
    });
  };

  const deleteWastage = (wasteId: string) => {
    setData(prev => {
        const waste = prev.wastages.find(w => w.id === wasteId);
        if (!waste) return prev;
        const updatedProducts = prev.products.map(p => 
            p.id === waste.productId ? { ...p, stock: p.stock + waste.quantity } : p
        );
        return {
            ...prev,
            wastages: prev.wastages.filter(w => w.id !== wasteId),
            products: updatedProducts
        };
    });
  };

  const collectDue = (customerId: string, amount: number, note: string) => {
    setData(prev => {
      const updatedCustomers = prev.customers.map(c => 
        c.id === customerId ? { ...c, balance: c.balance - amount } : c
      );
      const customer = updatedCustomers.find(c => c.id === customerId);
      const newLedger: LedgerEntry = {
        id: `L-${Date.now()}`,
        date: new Date().toISOString(),
        entityId: customerId,
        entityType: 'Customer',
        type: 'Credit',
        amount: amount,
        description: `Due Collection: ${note}`,
        balanceAfter: customer?.balance || 0
      };
      return {
        ...prev,
        customers: updatedCustomers,
        ledgers: [newLedger, ...prev.ledgers]
      };
    });
  };

  const paySupplier = (supplierId: string, amount: number, note: string) => {
    setData(prev => {
      const updatedSuppliers = prev.suppliers.map(s => 
        s.id === supplierId ? { ...s, balance: s.balance - amount } : s
      );
      const supplier = updatedSuppliers.find(s => s.id === supplierId);
      const newLedger: LedgerEntry = {
        id: `SPL-${Date.now()}`,
        date: new Date().toISOString(),
        entityId: supplierId,
        entityType: 'Supplier',
        type: 'Credit',
        amount: amount,
        description: `Supplier Payment: ${note}`,
        balanceAfter: supplier?.balance || 0
      };
      return {
        ...prev,
        suppliers: updatedSuppliers,
        ledgers: [newLedger, ...prev.ledgers]
      };
    });
  };

  const addExpense = (e: Omit<Expense, 'id'>) => setData(prev => ({ ...prev, expenses: [{...e, id: Date.now().toString()}, ...prev.expenses]}));
  const updateExpense = (id: string, e: Partial<Expense>) => setData(prev => ({ ...prev, expenses: prev.expenses.map(item => item.id === id ? { ...item, ...e } : item) }));
  const deleteExpense = (id: string) => setData(prev => ({ ...prev, expenses: prev.expenses.filter(item => item.id !== id) }));

  const addReminder = (r: Omit<Reminder, 'id' | 'completed'>) => setData(prev => ({ ...prev, reminders: [{...r, id: Date.now().toString(), completed: false}, ...prev.reminders]}));
  const updateReminder = (id: string, r: Partial<Reminder>) => setData(prev => ({ ...prev, reminders: prev.reminders.map(item => item.id === id ? { ...item, ...r } : item) }));
  const deleteReminder = (id: string) => setData(prev => ({ ...prev, reminders: prev.reminders.filter(item => item.id !== id) }));
  const toggleReminder = (id: string) => setData(prev => ({ ...prev, reminders: prev.reminders.map(item => item.id === id ? { ...item, completed: !item.completed } : item) }));

  const addProduct = (p: Omit<Product, 'id'>) => setData(prev => ({ ...prev, products: [{...p, id: Date.now().toString()}, ...prev.products]}));
  const updateProduct = (id: string, p: Partial<Product>) => setData(prev => ({ ...prev, products: prev.products.map(item => item.id === id ? { ...item, ...p } : item) }));
  const deleteProduct = (id: string) => setData(prev => ({ ...prev, products: prev.products.filter(item => item.id !== id) }));
  const addCustomer = (c: Omit<Customer, 'id'>) => setData(prev => ({ ...prev, customers: [{...c, id: Date.now().toString()}, ...prev.customers]}));
  const addSupplier = (s: Omit<Supplier, 'id'>) => setData(prev => ({ ...prev, suppliers: [{...s, id: Date.now().toString()}, ...prev.suppliers]}));
  const updateSettings = (s: AppData['settings']) => setData(prev => ({ ...prev, settings: s }));

  return React.createElement(StoreContext.Provider, {
    value: { 
        data, 
        currentUser,
        login,
        logout,
        updateCurrentUser,
        addUser,
        updateUser,
        deleteUser,
        addSale, 
        deleteSale,
        addPurchase, 
        addSaleReturn,
        deleteSaleReturn,
        addPurchaseReturn,
        deletePurchaseReturn,
        addWastage,
        deleteWastage,
        addProduct, 
        updateProduct,
        deleteProduct,
        addCustomer, 
        addSupplier,
        addExpense,
        updateExpense,
        deleteExpense,
        addReminder,
        updateReminder,
        deleteReminder,
        toggleReminder,
        collectDue,
        paySupplier,
        updateSettings,
        importData,
        resetDatabase,
        language, 
        setLanguage 
    }
  }, children);
};

export const useStore = () => {
  const context = useContext(StoreContext);
  if (!context) throw new Error('useStore must be used within StoreProvider');
  return context;
};