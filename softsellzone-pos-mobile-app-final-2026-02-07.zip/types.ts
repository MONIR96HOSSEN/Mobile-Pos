
export type PaymentMode = 'Cash' | 'Due' | 'Partial';
export type UserRole = 'Owner' | 'Staff';
export type Priority = 'Low' | 'Medium' | 'High';

export interface User {
  id: string;
  username: string;
  password?: string;
  role: UserRole;
  name: string;
  avatarUrl?: string;
}

export interface Product {
  id: string;
  name: string;
  category: string;
  buyPrice: number;
  sellPrice: number;
  stock: number;
  lowStockAlert: number;
  lotNo?: string;
  expiryDate?: string;
}

export interface Customer {
  id: string;
  name: string;
  phone: string;
  address: string;
  balance: number; // Positive = Due from customer
}

export interface Supplier {
  id: string;
  name: string;
  phone: string;
  address: string;
  balance: number; // Positive = Payable to supplier
}

export interface SaleItem {
  productId: string;
  name: string;
  quantity: number;
  price: number;
  total: number;
}

export interface Sale {
  id: string;
  invoiceNo: string;
  date: string;
  customerId: string;
  items: SaleItem[];
  subTotal: number;
  discount: number;
  total: number;
  paidAmount: number;
  dueAmount: number;
  paymentMode: PaymentMode;
}

export interface Purchase {
  id: string;
  date: string;
  supplierId: string;
  items: SaleItem[];
  total: number;
  paidAmount: number;
  dueAmount: number;
}

export interface SaleReturn {
  id: string;
  date: string;
  saleId: string;
  items: SaleItem[];
  total: number;
  reason: string;
}

export interface PurchaseReturn {
  id: string;
  date: string;
  purchaseId: string;
  items: SaleItem[];
  total: number;
  reason: string;
}

export interface Wastage {
  id: string;
  date: string;
  productId: string;
  quantity: number;
  reason: string;
  lossValue: number;
}

export interface LedgerEntry {
  id: string;
  date: string;
  entityId: string; // Customer or Supplier ID
  entityType: 'Customer' | 'Supplier';
  type: 'Debit' | 'Credit';
  amount: number;
  description: string;
  balanceAfter: number;
}

export interface Expense {
  id: string;
  date: string;
  category: string;
  amount: number;
  description: string;
}

export interface Reminder {
  id: string;
  title: string;
  description: string;
  date: string; // YYYY-MM-DD
  time: string; // HH:mm
  completed: boolean;
  priority: Priority;
}

export interface BusinessSettings {
  name: string;
  address: string;
  phone: string;
  email?: string;
  logo: string;
  currency: string;
  invoiceFooter: string;
}

export interface AppData {
  products: Product[];
  customers: Customer[];
  suppliers: Supplier[];
  sales: Sale[];
  purchases: Purchase[];
  saleReturns: SaleReturn[];
  purchaseReturns: PurchaseReturn[];
  wastages: Wastage[];
  ledgers: LedgerEntry[];
  expenses: Expense[];
  reminders: Reminder[];
  settings: BusinessSettings;
  users: User[];
}
