
import React from 'react';
import { HashRouter, Routes, Route, Navigate } from 'react-router-dom';
import { StoreProvider, useStore } from './store';
import Layout from './components/Layout';
import Dashboard from './pages/Dashboard';
import POS from './pages/POS';
import Inventory from './pages/Inventory';
import Customers from './pages/Customers';
import Reports from './pages/Reports';
import Purchases from './pages/Purchases';
import Suppliers from './pages/Suppliers';
import Dues from './pages/Dues';
import Expenses from './pages/Expenses';
import Reminders from './pages/Reminders';
import Returns from './pages/Returns';
import SettingsPage from './pages/Settings';
import SalesList from './pages/SalesList';
import Login from './pages/Login';

const ProtectedRoute: React.FC<{ children: React.ReactNode, requiredRole?: 'Owner' | 'Staff' }> = ({ children, requiredRole }) => {
  const { currentUser } = useStore();
  
  if (!currentUser) {
    return <Navigate to="/login" replace />;
  }

  if (requiredRole === 'Owner' && currentUser.role !== 'Owner') {
    return <Navigate to="/" replace />;
  }

  return <>{children}</>;
};

const AppContent: React.FC = () => {
  const { currentUser } = useStore();

  return (
    <HashRouter>
      <Routes>
        <Route path="/login" element={currentUser ? <Navigate to="/" replace /> : <Login />} />
        
        <Route path="/" element={<ProtectedRoute><Layout /></ProtectedRoute>}>
          <Route index element={<Dashboard />} />
          <Route path="pos" element={<POS />} />
          <Route path="sales-list" element={<SalesList />} />
          <Route path="dues" element={<Dues />} />
          <Route path="expenses" element={<Expenses />} />
          <Route path="returns" element={<Returns />} />
          <Route path="reminders" element={<Reminders />} />
          <Route path="inventory" element={<Inventory />} />
          <Route path="customers" element={<Customers />} />
          
          {/* Owner Only Routes */}
          <Route path="purchases" element={<ProtectedRoute requiredRole="Owner"><Purchases /></ProtectedRoute>} />
          <Route path="suppliers" element={<ProtectedRoute requiredRole="Owner"><Suppliers /></ProtectedRoute>} />
          <Route path="reports" element={<ProtectedRoute requiredRole="Owner"><Reports /></ProtectedRoute>} />
          <Route path="settings" element={<ProtectedRoute requiredRole="Owner"><SettingsPage /></ProtectedRoute>} />
        </Route>

        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </HashRouter>
  );
};

const App: React.FC = () => {
  return (
    <StoreProvider>
      <AppContent />
    </StoreProvider>
  );
};

export default App;
