import React from 'react';
import { Sale, BusinessSettings, Customer } from '../types';

interface ReceiptProps {
  sale: Sale;
  settings: BusinessSettings;
  customer: Customer | undefined;
  layout?: 'thermal' | 'full';
  showInPreview?: boolean;
}

const Receipt: React.FC<ReceiptProps> = ({ sale, settings, customer, layout = 'thermal', showInPreview = false }) => {
  const containerClass = showInPreview ? "w-full" : "print-only";

  if (layout === 'full') {
    return (
      <div className={`${containerClass} max-w-[210mm] mx-auto p-12 bg-white text-slate-900 font-sans`}>
        <div className="flex justify-between items-start mb-12 border-b-2 border-slate-100 pb-8">
            <div>
                <h1 className="text-4xl font-black text-blue-600 mb-2 uppercase tracking-tighter">{settings.name}</h1>
                <p className="text-slate-500 whitespace-pre-wrap text-sm leading-relaxed max-w-xs font-medium">{settings.address}</p>
                <div className="mt-4 space-y-1">
                    <p className="text-slate-800 font-black text-sm uppercase tracking-widest">Phone: {settings.phone}</p>
                    {settings.email && <p className="text-slate-500 text-sm">{settings.email}</p>}
                </div>
            </div>
            <div className="text-right">
                <h2 className="text-4xl font-black text-slate-200 uppercase tracking-widest mb-6 leading-none">INVOICE</h2>
                <div className="space-y-2 text-sm">
                    <p className="flex justify-end gap-2"><span className="text-slate-400 font-black uppercase tracking-widest">Invoice:</span> <span className="font-black">#{sale.invoiceNo}</span></p>
                    <p className="flex justify-end gap-2"><span className="text-slate-400 font-black uppercase tracking-widest">Date:</span> <span className="font-bold">{new Date(sale.date).toLocaleDateString()}</span></p>
                </div>
            </div>
        </div>

        <div className="grid grid-cols-2 gap-12 mb-12">
            <div className="p-8 bg-slate-50 rounded-[2rem] border border-slate-100">
                <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-4">BILLING TO</h4>
                <p className="text-2xl font-black text-slate-900 uppercase tracking-tight">{customer?.name || 'Walk-in Customer'}</p>
                <p className="text-slate-600 font-bold mt-2">{customer?.phone}</p>
                {customer?.address && <p className="text-slate-400 text-xs mt-1">{customer.address}</p>}
            </div>
            <div className="p-8 bg-slate-900 text-white rounded-[2rem] flex flex-col justify-center shadow-xl">
                 <h4 className="text-[10px] font-black text-white/40 uppercase tracking-widest mb-1">TOTAL RECEIVABLE</h4>
                 <p className="text-5xl font-black">{sale.total.toLocaleString()} <span className="text-xl font-medium">{settings.currency}</span></p>
                 <div className="mt-6 pt-4 border-t border-white/10 flex justify-between items-center text-[10px] font-black uppercase tracking-widest">
                    <span>{sale.paymentMode} Payment</span>
                    <span className={sale.dueAmount > 0 ? "text-rose-400" : "text-emerald-400"}>{sale.dueAmount > 0 ? 'PARTIAL' : 'FULLY PAID'}</span>
                 </div>
            </div>
        </div>

        <table className="w-full text-left mb-12 border-collapse">
            <thead>
                <tr className="bg-slate-100 text-slate-600">
                    <th className="p-5 rounded-l-2xl font-black uppercase text-[10px] tracking-widest">Description</th>
                    <th className="p-5 text-center font-black uppercase text-[10px] tracking-widest">Qty</th>
                    <th className="p-5 text-right font-black uppercase text-[10px] tracking-widest">Unit Price</th>
                    <th className="p-5 text-right rounded-r-2xl font-black uppercase text-[10px] tracking-widest">Total</th>
                </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
                {sale.items.map((item, idx) => (
                    <tr key={idx}>
                        <td className="p-5 font-bold text-slate-800 uppercase text-xs">{item.name}</td>
                        <td className="p-5 text-center font-bold">{item.quantity}</td>
                        <td className="p-5 text-right text-slate-500">{item.price.toLocaleString()}</td>
                        <td className="p-5 text-right font-black text-slate-900">{item.total.toLocaleString()}</td>
                    </tr>
                ))}
            </tbody>
        </table>

        <div className="flex justify-end pt-6 border-t border-slate-100">
            <div className="w-80 space-y-4">
                <div className="flex justify-between text-slate-400 font-black text-[10px] uppercase tracking-widest">
                    <span>Subtotal</span>
                    <span>{sale.subTotal.toLocaleString()} {settings.currency}</span>
                </div>
                {sale.discount > 0 && (
                    <div className="flex justify-between text-rose-500 font-black text-[10px] uppercase tracking-widest bg-rose-50 p-2 rounded-lg">
                        <span>Discount (-)</span>
                        <span>{sale.discount.toLocaleString()} {settings.currency}</span>
                    </div>
                )}
                <div className="flex justify-between text-3xl font-black text-slate-900 pt-6 border-t-2 border-slate-900">
                    <span>Grand Total</span>
                    <span>{sale.total.toLocaleString()} {settings.currency}</span>
                </div>
                <div className="space-y-2 pt-4 border-t border-slate-50">
                    <div className="flex justify-between text-[10px] font-black text-slate-400 uppercase tracking-widest">
                        <span>Paid Amount</span>
                        <span>{sale.paidAmount.toLocaleString()}</span>
                    </div>
                    {sale.dueAmount > 0 && (
                        <div className="flex justify-between text-lg font-black text-rose-600 bg-rose-50 px-4 py-3 rounded-2xl border border-rose-100">
                            <span>Outstanding Balance</span>
                            <span>{sale.dueAmount.toLocaleString()} {settings.currency}</span>
                        </div>
                    )}
                </div>
            </div>
        </div>

        <div className="mt-24 pt-10 border-t-2 border-slate-50 text-center">
            <p className="text-slate-400 text-sm font-bold uppercase tracking-widest italic">{settings.invoiceFooter}</p>
        </div>
      </div>
    );
  }

  // THERMAL 58MM LAYOUT
  return (
    <div className={`${containerClass} w-[58mm] mx-auto p-4 bg-white text-black font-mono text-[10px] leading-tight pb-10`}>
      <div className="text-center mb-4 space-y-1">
        <h2 className="text-[14px] font-black uppercase leading-none">{settings.name}</h2>
        <p className="text-[8px] leading-tight font-bold">{settings.address}</p>
        <p className="text-[9px] font-black mt-1">Ph: {settings.phone}</p>
        <div className="border-b border-black border-double my-2"></div>
        <h3 className="font-black text-[10px] py-0.5 border border-black uppercase tracking-widest">Sales Receipt</h3>
      </div>

      <div className="mb-4 space-y-1 text-[8px] font-bold">
        <div className="flex justify-between"><span>Inv No:</span> <span>#{sale.invoiceNo}</span></div>
        <div className="flex justify-between"><span>Date:</span> <span>{new Date(sale.date).toLocaleDateString()}</span></div>
        <div className="flex justify-between border-t border-black border-dotted pt-1 mt-1 uppercase">
            <span>Customer:</span> 
            <span className="font-black truncate max-w-[30mm]">{customer?.name || 'Walk-in'}</span>
        </div>
      </div>

      <table className="w-full mb-4">
        <thead>
            <tr className="border-b border-black text-left text-[8px] font-black uppercase">
                <th className="py-1">Item</th>
                <th className="text-center py-1">Qty</th>
                <th className="text-right py-1">Total</th>
            </tr>
        </thead>
        <tbody className="divide-y divide-dotted divide-gray-300">
            {sale.items.map((item, idx) => (
                <tr key={idx} className="align-top">
                    <td className="py-1 uppercase text-[8px] font-black pr-1 leading-tight">{item.name}</td>
                    <td className="text-center py-1 font-bold">{item.quantity}</td>
                    <td className="text-right py-1 font-black">{item.total.toLocaleString()}</td>
                </tr>
            ))}
        </tbody>
      </table>

      <div className="space-y-1 font-black text-[9px]">
        <div className="flex justify-between border-t border-black pt-2">
          <span>Subtotal:</span>
          <span>{sale.subTotal.toLocaleString()}</span>
        </div>
        {sale.discount > 0 && (
          <div className="flex justify-between text-gray-600">
            <span>Discount:</span>
            <span>-{sale.discount.toLocaleString()}</span>
          </div>
        )}
        <div className="flex justify-between text-[11px] border-y border-black py-1 my-1">
          <span>TOTAL:</span>
          <span>{sale.total.toLocaleString()}</span>
        </div>
        <div className="flex justify-between font-bold opacity-70">
          <span>Received:</span>
          <span>{sale.paidAmount.toLocaleString()}</span>
        </div>
        {sale.dueAmount > 0 && (
            <div className="flex justify-between font-black border-t border-black border-dotted mt-1 pt-1 text-rose-700">
                <span>DUE BALANCE:</span>
                <span>{sale.dueAmount.toLocaleString()}</span>
            </div>
        )}
      </div>

      <div className="text-center mt-6 border-t border-black border-dotted pt-4">
        <p className="text-[7px] font-bold uppercase tracking-tighter leading-tight italic px-2">{settings.invoiceFooter}</p>
        <p className="mt-4 text-[8px] font-black uppercase tracking-widest opacity-30">Software: SoftSellZone</p>
      </div>
    </div>
  );
};

export default Receipt;