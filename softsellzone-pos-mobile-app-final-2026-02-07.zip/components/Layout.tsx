import React, { useState, useRef, useEffect } from 'react';
import { NavLink, Outlet, useNavigate, useLocation } from 'react-router-dom';
import { 
    LayoutDashboard, 
    ShoppingCart, 
    Wallet, 
    Package, 
    Users, 
    Truck, 
    BarChart3, 
    Settings, 
    Menu, 
    X, 
    Languages,
    Calculator,
    ArrowDownToLine,
    ListOrdered,
    LogOut,
    User as UserIcon,
    ChevronDown,
    Upload,
    MoreHorizontal,
    Lock,
    Camera,
    CheckCircle2,
    Image as ImageIcon,
    AtSign,
    Receipt,
    CalendarCheck,
    RotateCcw,
    Eye,
    EyeOff
} from 'lucide-react';
import { useStore } from '../store';
import { TRANSLATIONS } from '../constants';

const Layout: React.FC = () => {
    const [isSidebarOpen, setIsSidebarOpen] = useState(false);
    const [showProfileModal, setShowProfileModal] = useState(false);
    const [showPassword, setShowPassword] = useState(false);
    const { language, setLanguage, data, currentUser, logout, updateCurrentUser } = useStore();
    const t = TRANSLATIONS[language];
    const navigate = useNavigate();
    const location = useLocation();
    const fileInputRef = useRef<HTMLInputElement>(null);

    // Profile Edit State
    const [profileForm, setProfileForm] = useState({
        name: '',
        username: '',
        avatarUrl: '',
        password: ''
    });

    // Sync form with currentUser whenever modal opens
    useEffect(() => {
        if (showProfileModal && currentUser) {
            setProfileForm({
                name: currentUser.name || '',
                username: currentUser.username || '',
                avatarUrl: currentUser.avatarUrl || `https://picsum.photos/100/100?seed=${currentUser.username}`,
                password: currentUser.password || ''
            });
            setShowPassword(false);
        }
    }, [showProfileModal, currentUser]);

    const isOwner = currentUser?.role === 'Owner';

    const navItems = [
        { to: '/', icon: LayoutDashboard, label: t.dashboard, role: 'Staff' },
        { to: '/pos', icon: ShoppingCart, label: t.pos, role: 'Staff' },
        { to: '/sales-list', icon: ListOrdered, label: t.salesList, role: 'Staff' },
        { to: '/dues', icon: Wallet, label: t.due, role: 'Staff' },
        { to: '/expenses', icon: Receipt, label: t.expenses, role: 'Staff' },
        { to: '/returns', icon: RotateCcw, label: t.returns, role: 'Staff' },
        { to: '/reminders', icon: CalendarCheck, label: t.reminders, role: 'Staff' },
        { to: '/purchases', icon: ArrowDownToLine, label: t.purchases, role: 'Owner' },
        { to: '/inventory', icon: Package, label: t.inventory, role: 'Staff' },
        { to: '/customers', icon: Users, label: t.customers, role: 'Staff' },
        { to: '/suppliers', icon: Truck, label: t.suppliers, role: 'Owner' },
        { to: '/reports', icon: BarChart3, label: t.reports, role: 'Owner' },
        { to: '/settings', icon: Settings, label: t.settings, role: 'Owner' },
    ];

    const filteredItems = navItems.filter(item => isOwner || item.role === 'Staff');

    // MOBILE FOOTER ORDER: Home, POS, Note, Menu (3 dots)
    const bottomNavItems = [
        { to: '/', icon: LayoutDashboard, label: 'Home' },
        { to: '/pos', icon: ShoppingCart, label: 'POS' },
        { to: '/reminders', icon: CalendarCheck, label: 'Note' },
        { onClick: () => setIsSidebarOpen(true), icon: MoreHorizontal, label: 'Menu' }
    ];

    const handleLogout = () => {
        logout();
        navigate('/login');
    };

    const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (file) {
            const reader = new FileReader();
            reader.onloadend = () => {
                setProfileForm(prev => ({ ...prev, avatarUrl: reader.result as string }));
            };
            reader.readAsDataURL(file);
        }
    };

    const handleUpdateProfile = (e: React.FormEvent) => {
        e.preventDefault();
        updateCurrentUser({
            name: profileForm.name,
            username: profileForm.username,
            avatarUrl: profileForm.avatarUrl,
            password: profileForm.password
        });
        setShowProfileModal(false);
        alert(language === 'bn' ? 'প্রোফাইল আপডেট সফল হয়েছে!' : 'Profile updated successfully!');
    };

    return (
        <div className="min-h-screen mobile-app-container flex bg-slate-200 no-print transition-all duration-500">
            <div className="flex-1 flex flex-col md:flex-row bg-slate-50 mobile-app-inner relative transition-all">
                
                {isSidebarOpen && (
                    <div 
                        className="fixed inset-0 bg-black/60 backdrop-blur-sm z-[70] md:hidden no-print animate-in fade-in duration-300"
                        onClick={() => setIsSidebarOpen(false)}
                    />
                )}

                <aside className={`
                    fixed md:sticky top-0 left-0 h-full w-72 bg-slate-900 text-white z-[80] transition-transform duration-300 transform
                    ${isSidebarOpen ? 'translate-x-0' : '-translate-x-full md:translate-x-0'}
                    no-print flex flex-col shadow-2xl md:shadow-none
                `}>
                    <div className="p-8 flex items-center gap-4">
                        <div className="w-12 h-12 bg-blue-600 rounded-2xl flex items-center justify-center shadow-lg">
                            <Calculator className="text-white" size={24} />
                        </div>
                        <div>
                            <h1 className="font-black text-2xl leading-tight tracking-tighter text-white">softsellzone</h1>
                            <p className="text-[10px] font-black uppercase tracking-[0.2em] text-blue-400">POS Controller</p>
                        </div>
                    </div>

                    <nav className="mt-4 px-4 space-y-1.5 flex-1 overflow-y-auto scrollbar-hide">
                        {filteredItems.map((item) => (
                            <NavLink
                                key={item.to}
                                to={item.to}
                                className={({ isActive }) => `
                                    flex items-center gap-3 px-5 py-4 rounded-2xl transition-all
                                    ${isActive ? 'bg-blue-600 text-white shadow-xl' : 'text-slate-400 hover:bg-slate-800 hover:text-white'}
                                `}
                                onClick={() => setIsSidebarOpen(false)}
                            >
                                <item.icon size={20} />
                                <span className="font-bold text-sm tracking-tight">{item.label}</span>
                            </NavLink>
                        ))}
                    </nav>

                    <div className="p-6 border-t border-slate-800 space-y-3 mb-4">
                        <button 
                            onClick={() => setLanguage(language === 'en' ? 'bn' : 'en')}
                            className="w-full flex items-center gap-3 text-slate-400 hover:text-white transition-colors text-xs font-black uppercase tracking-widest p-3 rounded-xl hover:bg-slate-800"
                        >
                            <Languages size={18} />
                            {language === 'en' ? 'বাংলা সংস্করণ' : 'English Edition'}
                        </button>
                        <button 
                            onClick={handleLogout}
                            className="w-full flex items-center gap-3 text-rose-400 hover:text-white transition-colors text-xs font-black uppercase tracking-widest p-3 rounded-xl hover:bg-rose-500/10"
                        >
                            <LogOut size={18} />
                            {t.logout}
                        </button>
                    </div>
                </aside>

                <main className="flex-1 flex flex-col min-w-0 h-full overflow-hidden relative">
                    <header className="sticky top-0 bg-white/80 backdrop-blur-md border-b border-slate-200 h-16 md:h-20 flex items-center justify-between px-4 md:px-8 z-40 no-print">
                        <div className="flex items-center gap-4">
                            <button 
                                className="md:hidden p-2 text-slate-600 hover:bg-slate-100 rounded-lg"
                                onClick={() => setIsSidebarOpen(true)}
                            >
                                <Menu size={24} />
                            </button>
                            <div className="flex flex-col text-left">
                                <h2 className="text-sm md:text-xl font-black text-slate-900 tracking-tighter uppercase line-clamp-1">{data.settings.name}</h2>
                                <p className="text-[8px] font-black text-blue-600 uppercase tracking-widest hidden sm:block">Business Intelligence Hub</p>
                            </div>
                        </div>

                        <div className="flex items-center gap-2 md:gap-4">
                            <button 
                                onClick={() => setShowProfileModal(true)}
                                className="flex items-center gap-2 hover:bg-slate-50 p-1 pr-3 rounded-2xl transition-all active:scale-95 group"
                            >
                                <div className="text-right hidden sm:block">
                                    <p className="text-sm font-black text-slate-900 group-hover:text-blue-600 transition-colors">{currentUser?.name}</p>
                                    <p className="text-[10px] font-black uppercase text-blue-600 tracking-tighter">{currentUser?.role}</p>
                                </div>
                                <div className="w-8 h-8 md:w-11 md:h-11 rounded-xl bg-slate-200 overflow-hidden shadow-inner border-2 border-white ring-1 ring-slate-100 relative">
                                    <img 
                                        src={currentUser?.avatarUrl || `https://picsum.photos/40/40?seed=${currentUser?.username}`} 
                                        alt="User" 
                                        className="w-full h-full object-cover" 
                                    />
                                    <div className="absolute inset-0 bg-black/20 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                                        <Camera size={12} className="text-white"/>
                                    </div>
                                </div>
                            </button>
                        </div>
                    </header>

                    <div className="flex-1 overflow-y-auto p-4 md:p-8 pb-56 md:pb-8 scrollbar-hide">
                        <Outlet />
                    </div>

                    {/* Blue Bottom Nav - Mobile Only */}
                    <nav className="fixed bottom-4 left-5 right-5 md:hidden z-[60] no-print">
                        <div className="bg-blue-600/90 backdrop-blur-xl border border-white/20 px-4 py-1.5 rounded-[1.75rem] flex items-center justify-between shadow-2xl shadow-blue-900/30">
                            {bottomNavItems.map((item, idx) => {
                                const isActive = item.to ? location.pathname === item.to : false;
                                return (
                                    <NavLink 
                                        key={idx} 
                                        to={item.to || '#'} 
                                        onClick={item.onClick}
                                        className="flex-1 flex flex-col items-center gap-0.5 py-1"
                                    >
                                        <div className={`p-1.5 rounded-full transition-all duration-300 ${isActive ? 'bg-white text-blue-600 shadow-md scale-110' : 'text-blue-100/70'}`}>
                                            <item.icon size={18} strokeWidth={isActive ? 3 : 2} />
                                        </div>
                                        <span className={`text-[7px] font-black uppercase tracking-tighter ${isActive ? 'text-white' : 'text-blue-200/50'}`}>
                                            {item.label}
                                        </span>
                                    </NavLink>
                                );
                            })}
                        </div>
                    </nav>
                </main>
            </div>

            {/* PROFILE SETTINGS MODAL */}
            {showProfileModal && (
                <div className="fixed inset-0 bg-slate-900/95 backdrop-blur-2xl z-[200] flex items-center justify-center p-4 overflow-y-auto animate-in fade-in duration-300">
                    <div className="bg-white w-full max-w-md rounded-[3rem] shadow-2xl overflow-hidden animate-in zoom-in duration-300">
                        <div className="p-8 border-b border-slate-50 flex justify-between items-center bg-slate-50/50">
                            <div className="flex items-center gap-4">
                                <div className="w-12 h-12 bg-indigo-100 text-indigo-600 rounded-2xl flex items-center justify-center">
                                    <UserIcon size={24}/>
                                </div>
                                <div>
                                    <h3 className="text-xl font-black uppercase tracking-tighter">Profile Security</h3>
                                    <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Manage Photo & Credentials</p>
                                </div>
                            </div>
                            <button 
                                onClick={() => setShowProfileModal(false)}
                                className="p-3 bg-white rounded-full hover:bg-slate-100 transition-colors border border-slate-100 shadow-sm"
                            >
                                <X size={20}/>
                            </button>
                        </div>

                        <form onSubmit={handleUpdateProfile} className="p-8 space-y-6">
                            {/* Avatar Preview & Selection */}
                            <div className="flex flex-col items-center gap-4 py-4">
                                <div className="relative group">
                                    <div className="w-28 h-28 rounded-[2.5rem] border-4 border-slate-100 shadow-inner overflow-hidden relative">
                                        <img 
                                            src={profileForm.avatarUrl} 
                                            alt="Preview" 
                                            className="w-full h-full object-cover"
                                            onError={(e) => {
                                                (e.target as HTMLImageElement).src = `https://picsum.photos/100/100?seed=${currentUser?.username}`;
                                            }}
                                        />
                                    </div>
                                    <button 
                                        type="button"
                                        onClick={() => fileInputRef.current?.click()}
                                        className="absolute -bottom-2 -right-2 w-10 h-10 bg-indigo-600 text-white rounded-2xl flex items-center justify-center shadow-lg active:scale-90 transition-all border-2 border-white"
                                    >
                                        <Camera size={18}/>
                                    </button>
                                </div>
                                <input 
                                    type="file" 
                                    ref={fileInputRef} 
                                    className="hidden" 
                                    accept="image/*" 
                                    onChange={handleFileChange} 
                                />
                                <p className="text-[10px] font-black uppercase text-indigo-500 tracking-widest">Tap camera to change photo</p>
                            </div>

                            <div className="space-y-4">
                                <div className="space-y-1">
                                    <label className="text-[10px] font-black uppercase text-slate-400 ml-2 tracking-widest">Full Name</label>
                                    <div className="relative">
                                        <UserIcon className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-300" size={16}/>
                                        <input 
                                            type="text" 
                                            className="w-full pl-12 p-4 border border-slate-200 rounded-2xl bg-slate-50 font-bold outline-none focus:ring-2 focus:ring-indigo-600 transition-all"
                                            value={profileForm.name}
                                            onChange={(e) => setProfileForm({...profileForm, name: e.target.value})}
                                            required
                                        />
                                    </div>
                                </div>

                                <div className="space-y-1">
                                    <label className="text-[10px] font-black uppercase text-indigo-500 ml-2 tracking-widest">Login ID (Username)</label>
                                    <div className="relative">
                                        <AtSign className="absolute left-4 top-1/2 -translate-y-1/2 text-indigo-300" size={16}/>
                                        <input 
                                            type="text" 
                                            className="w-full pl-12 p-4 border border-indigo-100 rounded-2xl bg-indigo-50/30 font-bold outline-none focus:ring-2 focus:ring-indigo-600 transition-all"
                                            value={profileForm.username}
                                            onChange={(e) => setProfileForm({...profileForm, username: e.target.value})}
                                            required
                                        />
                                    </div>
                                </div>

                                <div className="space-y-1">
                                    <label className="text-[10px] font-black uppercase text-rose-500 ml-2 tracking-widest">Access Password</label>
                                    <div className="relative">
                                        <Lock className="absolute left-4 top-1/2 -translate-y-1/2 text-rose-300" size={16}/>
                                        <input 
                                            type={showPassword ? "text" : "password"} 
                                            className="w-full pl-12 pr-12 p-4 border border-rose-100 rounded-2xl bg-rose-50/30 font-bold outline-none focus:ring-2 focus:ring-rose-600 transition-all"
                                            value={profileForm.password}
                                            onChange={(e) => setProfileForm({...profileForm, password: e.target.value})}
                                            required
                                        />
                                        <button 
                                            type="button"
                                            onClick={() => setShowPassword(!showPassword)}
                                            className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-300 hover:text-rose-400"
                                        >
                                            {showPassword ? <EyeOff size={18}/> : <Eye size={18}/>}
                                        </button>
                                    </div>
                                </div>
                            </div>

                            <button 
                                type="submit"
                                className="w-full py-5 bg-indigo-600 text-white rounded-[1.75rem] font-black uppercase tracking-[0.2em] text-[11px] shadow-xl hover:bg-indigo-700 active:scale-95 transition-all flex items-center justify-center gap-3"
                            >
                                <CheckCircle2 size={20}/> Save Changes
                            </button>

                            <div className="pt-4 text-center">
                                <p className="text-[9px] font-black text-slate-300 uppercase tracking-widest italic">Identity secured by SoftSellZone Intelligence</p>
                            </div>
                        </form>
                    </div>
                </div>
            )}
        </div>
    );
};

export default Layout;