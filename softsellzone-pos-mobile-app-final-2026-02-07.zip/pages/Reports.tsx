
import React, { useMemo, useState } from 'react';
import { useStore } from '../store';
import { 
    Calendar, 
    FileText, 
    TrendingUp, 
    DollarSign, 
    Package, 
    UserCheck, 
    Filter, 
    Printer, 
    Download, 
    ArrowUpRight, 
    ArrowDownRight,
    MapPin,
    Phone,
    X,
    ChevronRight,
    ShoppingBag,
    ArrowRight
} from 'lucide-react';

type FilterRange = 'daily' | 'weekly' | 'monthly' | 'all';
type DetailType = 'revenue' | 'profit' | 'inventory' | 'purchases' | null;

const Reports: React.FC = () => {
  const { data, language } = useStore();
  const [filter, setFilter] = useState<FilterRange>('monthly');
  const [activeDetail, setActiveDetail] = useState<DetailType>(null);

  const filteredData = useMemo(() => {
    const now = new Date();
    const startOfToday = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const startOfWeek = new Date(now);
    startOfWeek.setDate(now.getDate() - 7);
    const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);

    const filterFn = (dateStr: string) => {
      const date = new Date(dateStr);
      if (filter === 'daily') return date >= startOfToday;
      if (filter === 'weekly') return date >= startOfWeek;
      if (filter === 'monthly') return date >= startOfMonth;
      return true;
    };

    return {
      sales: data.sales.filter(s => filterFn(s.date)),
      purchases: data.purchases.filter(p => filterFn(p.date)),
      ledgers: data.ledgers.filter(l => filterFn(l.date))
    };
  }, [data.sales, data.purchases, data.ledgers, filter]);

  const metrics = useMemo(() => {
    const totalSales = filteredData.sales.reduce((sum, s) => sum + s.total, 0);
    const totalPurchases = filteredData.purchases.reduce((sum, p) => sum + p.total, 0);
    
    const totalProfit = filteredData.sales.reduce((sum, s) => {
        const saleProfit = s.items.reduce((itemSum, item) => {
            const product = data.products.find(p => p.id === item.productId);
            const cost = product ? product.buyPrice : 0;
            return itemSum + ((item.price - cost) * item.quantity);
        }, 0);
        return sum + saleProfit;
    }, 0);

    const inventoryValue = data.products.reduce((sum, p) => sum + (p.stock * p.buyPrice), 0);

    return { totalSales, totalPurchases, totalProfit, inventoryValue };
  }, [filteredData, data.products]);

  const handlePrint = () => {
    setTimeout(() => {
      window.print();
    }, 300);
  };

  const getDetailTitle = () => {
    if (activeDetail === 'revenue') return 'Revenue Breakdown';
    if (activeDetail === 'profit') return 'Profit Analysis';
    if (activeDetail === 'inventory') return 'Inventory Assets';
    if (activeDetail === 'purchases') return 'Purchase History';
    return '';
  };

  return (
    <div className="space-y-6 pb-20">
      {/* Interactive Controls */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6 no-print">
        <div>
            <h2 className="text-3xl font-black text-slate-900 tracking-tighter">
                {language === 'bn' ? 'ব্যবসায়িক রিপোর্ট' : 'Business Reports'}
            </h2>
            <p className="text-[10px] font-black text-slate-400 uppercase tracking-[0.3em] mt-1">Advanced Performance Analytics</p>
        </div>
        <div className="flex flex-col sm:flex-row w-full md:w-auto gap-4">
            <div className="flex bg-white border border-slate-200 rounded-[1.5rem] p-1.5 shadow-sm overflow-x-auto scrollbar-hide">
                {(['daily', 'weekly', 'monthly', 'all'] as FilterRange[]).map((f) => (
                    <button
                        key={f}
                        onClick={() => setFilter(f)}
                        className={`whitespace-nowrap flex-1 sm:flex-none px-5 py-2.5 text-[10px] font-black rounded-xl transition-all uppercase tracking-widest ${filter === f ? 'bg-indigo-600 text-white shadow-lg' : 'text-slate-400 hover:bg-slate-50'}`}
                    >
                        {f}
                    </button>
                ))}
            </div>
            <button 
                onClick={handlePrint}
                className="flex items-center justify-center gap-3 px-8 py-4 bg-slate-900 text-white rounded-[1.5rem] text-[10px] font-black uppercase tracking-[0.2em] hover:bg-slate-800 transition-all shadow-xl active:scale-95"
            >
                <Download size={18} />
                Generate PDF Report
            </button>
        </div>
      </div>

      {/* Main Metric Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6 no-print">
        <ReportMetricCard 
          title="Total Revenue" 
          value={metrics.totalSales} 
          currency={data.settings.currency} 
          icon={TrendingUp} 
          color="text-indigo-600" 
          bg="bg-indigo-50" 
          onClick={() => setActiveDetail('revenue')}
        />
        <ReportMetricCard 
          title="Gross Profit" 
          value={metrics.totalProfit} 
          currency={data.settings.currency} 
          icon={DollarSign} 
          color="text-emerald-600" 
          bg="bg-emerald-50" 
          onClick={() => setActiveDetail('profit')}
        />
        <ReportMetricCard 
          title="Stock Asset Value" 
          value={metrics.inventoryValue} 
          currency={data.settings.currency} 
          icon={Package} 
          color="text-amber-600" 
          bg="bg-amber-50" 
          onClick={() => setActiveDetail('inventory')}
        />
        <ReportMetricCard 
          title="Purchasing Activity" 
          value={metrics.totalPurchases} 
          currency={data.settings.currency} 
          icon={UserCheck} 
          color="text-rose-600" 
          bg="bg-rose-50" 
          onClick={() => setActiveDetail('purchases')}
        />
      </div>

      {/* Data Visuals */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 md:gap-8 no-print">
        <div className="bg-white p-6 md:p-8 rounded-[2.5rem] border border-slate-200 shadow-sm overflow-hidden">
            <h3 className="font-black text-xs mb-6 flex items-center gap-3 text-slate-800 uppercase tracking-[0.3em]">
                <div className="w-8 h-8 rounded-lg bg-indigo-50 flex items-center justify-center text-indigo-600">
                    <FileText size={16}/>
                </div>
                Latest Transaction Audit
            </h3>
            <div className="overflow-x-auto scrollbar-hide">
                <table className="w-full text-left text-sm min-w-[300px]">
                    <thead>
                        <tr className="text-slate-300 border-b border-slate-100">
                            <th className="pb-4 font-black uppercase text-[10px] tracking-widest">ID</th>
                            <th className="pb-4 font-black uppercase text-[10px] tracking-widest">Client Name</th>
                            <th className="pb-4 text-right font-black uppercase text-[10px] tracking-widest">Net Value</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-50">
                        {filteredData.sales.slice(0, 10).map(sale => (
                            <tr key={sale.id} className="hover:bg-slate-50/50 transition-colors cursor-pointer" onClick={() => setActiveDetail('revenue')}>
                                <td className="py-4 font-black text-indigo-600 text-xs">#{sale.invoiceNo}</td>
                                <td className="py-4 text-slate-600 font-bold uppercase text-[10px]">{data.customers.find(c => c.id === sale.customerId)?.name}</td>
                                <td className="py-4 text-right font-black text-slate-900">{sale.total} {data.settings.currency}</td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </div>

        <div className="bg-white p-6 md:p-8 rounded-[2.5rem] border border-slate-200 shadow-sm overflow-hidden">
             <h3 className="font-black text-xs mb-6 flex items-center gap-3 text-slate-800 uppercase tracking-[0.3em]">
                <div className="w-8 h-8 rounded-lg bg-emerald-50 flex items-center justify-center text-emerald-600">
                    <DollarSign size={16}/>
                </div>
                Cashflow Dynamics
            </h3>
            <div className="space-y-3 max-h-[400px] overflow-y-auto scrollbar-hide">
                {filteredData.ledgers.slice(0, 12).map(l => (
                    <div key={l.id} className="flex items-center justify-between p-4 bg-slate-50/50 rounded-2xl border border-slate-100 hover:border-indigo-100 transition-all group">
                        <div className="flex items-center gap-4">
                            <div className={`w-10 h-10 rounded-xl flex items-center justify-center text-[10px] font-black ${l.type === 'Debit' ? 'bg-rose-100 text-rose-600' : 'bg-emerald-100 text-emerald-600'}`}>
                                {l.type === 'Debit' ? 'DR' : 'CR'}
                            </div>
                            <div>
                                <p className="text-[10px] font-black text-slate-800 uppercase leading-none truncate max-w-[120px] md:max-w-none">{l.description}</p>
                                <p className="text-[9px] text-slate-400 font-bold uppercase tracking-widest mt-1.5">{new Date(l.date).toLocaleDateString()}</p>
                            </div>
                        </div>
                        <div className="text-right">
                            <p className={`font-black text-sm ${l.type === 'Debit' ? 'text-rose-600' : 'text-emerald-600'}`}>
                                {l.amount} <span className="text-[10px] opacity-40">{data.settings.currency}</span>
                            </p>
                        </div>
                    </div>
                ))}
            </div>
        </div>
      </div>

      {/* DETAIL MODAL */}
      {activeDetail && (
        <div className="fixed inset-0 bg-slate-900/90 backdrop-blur-xl z-[200] flex items-end sm:items-center justify-center p-4">
            <div className="bg-white w-full max-w-4xl rounded-t-[3rem] sm:rounded-[3rem] shadow-2xl overflow-hidden animate-slide-up sm:animate-in sm:zoom-in h-[90vh] sm:h-[80vh] flex flex-col">
                <div className="p-6 md:p-8 bg-slate-900 text-white flex justify-between items-center">
                    <div className="flex items-center gap-4">
                        <div className="w-12 h-12 bg-white/10 rounded-2xl flex items-center justify-center">
                           {activeDetail === 'revenue' && <TrendingUp size={24}/>}
                           {activeDetail === 'profit' && <DollarSign size={24}/>}
                           {activeDetail === 'inventory' && <Package size={24}/>}
                           {activeDetail === 'purchases' && <UserCheck size={24}/>}
                        </div>
                        <div>
                            <h3 className="font-black text-xl uppercase tracking-tighter">{getDetailTitle()}</h3>
                            <p className="text-[10px] font-black text-white/40 uppercase tracking-widest">{filter} Overview</p>
                        </div>
                    </div>
                    <button onClick={() => setActiveDetail(null)} className="p-3 bg-white/10 rounded-full hover:bg-white/20 transition-all"><X size={24}/></button>
                </div>

                <div className="flex-1 overflow-y-auto p-6 md:p-10 space-y-6 scrollbar-hide">
                    {/* Detail Content Based on Type */}
                    {activeDetail === 'revenue' && (
                        <div className="space-y-4">
                            {filteredData.sales.map(sale => (
                                <div key={sale.id} className="flex items-center justify-between p-5 bg-slate-50 rounded-3xl border border-slate-100 hover:border-indigo-200 transition-all">
                                    <div className="flex items-center gap-4">
                                        <div className="w-10 h-10 bg-indigo-100 text-indigo-600 rounded-xl flex items-center justify-center font-black text-[10px]">INV</div>
                                        <div>
                                            <p className="font-black text-xs text-slate-900 uppercase">#{sale.invoiceNo}</p>
                                            <p className="text-[10px] font-bold text-slate-400 mt-1">{data.customers.find(c => c.id === sale.customerId)?.name}</p>
                                        </div>
                                    </div>
                                    <div className="text-right">
                                        <p className="font-black text-lg text-indigo-600">{sale.total} <span className="text-[10px] font-medium">{data.settings.currency}</span></p>
                                        <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest">{new Date(sale.date).toLocaleDateString()}</p>
                                    </div>
                                </div>
                            ))}
                        </div>
                    )}

                    {activeDetail === 'profit' && (
                        <div className="space-y-4">
                            {filteredData.sales.map(sale => {
                                const saleProfit = sale.items.reduce((sum, item) => {
                                    const prod = data.products.find(p => p.id === item.productId);
                                    return sum + ((item.price - (prod?.buyPrice || 0)) * item.quantity);
                                }, 0);
                                return (
                                    <div key={sale.id} className="flex items-center justify-between p-5 bg-slate-50 rounded-3xl border border-slate-100 hover:border-emerald-200 transition-all">
                                        <div>
                                            <p className="font-black text-xs text-slate-900 uppercase">#{sale.invoiceNo}</p>
                                            <p className="text-[10px] font-bold text-slate-400 mt-1 uppercase">Revenue: {sale.total} {data.settings.currency}</p>
                                        </div>
                                        <div className="text-right">
                                            <p className="font-black text-lg text-emerald-600">+{saleProfit} <span className="text-[10px] font-medium">{data.settings.currency}</span></p>
                                            <p className="text-[9px] font-black text-emerald-400 uppercase tracking-widest">Profit Margin</p>
                                        </div>
                                    </div>
                                );
                            })}
                        </div>
                    )}

                    {activeDetail === 'inventory' && (
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            {data.products.map(p => (
                                <div key={p.id} className="p-5 bg-slate-50 rounded-3xl border border-slate-100 hover:border-amber-200 transition-all flex justify-between items-center">
                                    <div className="flex items-center gap-3">
                                        <div className="w-10 h-10 bg-amber-100 text-amber-600 rounded-xl flex items-center justify-center font-black text-[10px] uppercase">STK</div>
                                        <div>
                                            <p className="font-black text-xs text-slate-900 uppercase leading-none mb-1">{p.name}</p>
                                            <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">{p.stock} Units</p>
                                        </div>
                                    </div>
                                    <div className="text-right">
                                        <p className="font-black text-sm text-slate-900">{(p.stock * p.buyPrice).toLocaleString()}</p>
                                        <p className="text-[8px] font-black text-slate-300 uppercase">Asset Value</p>
                                    </div>
                                </div>
                            ))}
                        </div>
                    )}

                    {activeDetail === 'purchases' && (
                        <div className="space-y-4">
                            {filteredData.purchases.map(p => (
                                <div key={p.id} className="flex items-center justify-between p-5 bg-slate-50 rounded-3xl border border-slate-100 hover:border-rose-200 transition-all">
                                    <div className="flex items-center gap-4">
                                        <div className="w-10 h-10 bg-rose-100 text-rose-600 rounded-xl flex items-center justify-center font-black text-[10px]">PRC</div>
                                        <div>
                                            <p className="font-black text-xs text-slate-900 uppercase">#{p.id.slice(-6)}</p>
                                            <p className="text-[10px] font-bold text-slate-400 mt-1 uppercase">{data.suppliers.find(s => s.id === p.supplierId)?.name}</p>
                                        </div>
                                    </div>
                                    <div className="text-right">
                                        <p className="font-black text-lg text-rose-600">-{p.total} <span className="text-[10px] font-medium">{data.settings.currency}</span></p>
                                        <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest">{new Date(p.date).toLocaleDateString()}</p>
                                    </div>
                                </div>
                            ))}
                        </div>
                    )}

                    {((activeDetail === 'revenue' || activeDetail === 'profit' || activeDetail === 'purchases') && filteredData.sales.length === 0 && filteredData.purchases.length === 0) && (
                        <div className="flex flex-col items-center justify-center py-20 text-slate-200">
                             <ShoppingBag size={80} strokeWidth={1} className="mb-4 opacity-30" />
                             <p className="text-sm font-black uppercase tracking-[0.2em] text-slate-300">No Data Available</p>
                        </div>
                    )}
                </div>
                
                <div className="p-8 border-t border-slate-50 flex justify-center">
                    <button onClick={() => setActiveDetail(null)} className="px-10 py-4 bg-slate-900 text-white rounded-2xl font-black text-[10px] uppercase tracking-widest shadow-xl">Close Detailed View</button>
                </div>
            </div>
        </div>
      )}

      {/* PRINT LAYOUT */}
      <div className="print-only bg-white text-slate-900 font-sans p-0">
        <div className="flex justify-between items-start border-b-8 border-indigo-600 pb-10 mb-10">
            <div>
                <h1 className="text-5xl font-black text-slate-900 uppercase tracking-tighter leading-none mb-4">{data.settings.name}</h1>
                <p className="text-xs font-black text-indigo-600 uppercase tracking-[0.4em] mb-6">Financial Intelligence Report</p>
                <div className="space-y-1 text-slate-500 font-bold text-sm">
                    <p className="flex items-center gap-2"><MapPin size={14}/> {data.settings.address}</p>
                    <p className="flex items-center gap-2"><Phone size={14}/> {data.settings.phone}</p>
                </div>
            </div>
            <div className="text-right flex flex-col items-end">
                <div className="w-20 h-20 bg-indigo-600 rounded-3xl flex items-center justify-center text-white mb-4 shadow-xl">
                    <TrendingUp size={40} />
                </div>
                <h2 className="text-xs font-black uppercase text-slate-400 tracking-[0.2em]">Statement Period</h2>
                <p className="text-lg font-black text-slate-900 uppercase">{filter} STATS</p>
            </div>
        </div>

        <div className="grid grid-cols-2 gap-6 mb-12">
            <div className="p-8 border-2 border-slate-100 rounded-[2rem] bg-slate-50">
                <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] mb-6 border-b-2 border-slate-200 pb-2">Revenue Insight</h4>
                <div className="space-y-5">
                    <div className="flex justify-between items-center">
                        <span className="text-slate-600 font-bold">Total Sales Volume:</span>
                        <span className="font-black text-2xl">{metrics.totalSales} {data.settings.currency}</span>
                    </div>
                    <div className="flex justify-between items-center">
                        <span className="text-slate-600 font-bold">Estimated Profit:</span>
                        <span className="font-black text-2xl text-emerald-600">+{metrics.totalProfit} {data.settings.currency}</span>
                    </div>
                </div>
            </div>
            <div className="p-8 border-2 border-slate-100 rounded-[2rem] bg-slate-50">
                <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] mb-6 border-b-2 border-slate-200 pb-2">Operational Assets</h4>
                <div className="space-y-5">
                    <div className="flex justify-between items-center">
                        <span className="text-slate-600 font-bold">Live Inventory Value:</span>
                        <span className="font-black text-2xl">{metrics.inventoryValue} {data.settings.currency}</span>
                    </div>
                    <div className="flex justify-between items-center">
                        <span className="text-slate-600 font-bold">Capital Outflow:</span>
                        <span className="font-black text-2xl text-rose-600">-{metrics.totalPurchases} {data.settings.currency}</span>
                    </div>
                </div>
            </div>
        </div>

        <div className="mb-12">
            <h4 className="text-[10px] font-black text-slate-900 mb-6 border-l-4 border-indigo-600 pl-4 uppercase tracking-[0.3em]">Comprehensive Audit Trail</h4>
            <table className="w-full text-sm">
                <thead>
                    <tr className="bg-slate-900 text-white">
                        <th className="p-5 text-left rounded-l-2xl font-black uppercase text-[10px] tracking-widest">Post Date</th>
                        <th className="p-5 text-left font-black uppercase text-[10px] tracking-widest">Allocation / Narration</th>
                        <th className="p-5 text-left font-black uppercase text-[10px] tracking-widest">Type</th>
                        <th className="p-5 text-right rounded-r-2xl font-black uppercase text-[10px] tracking-widest">Transaction Amount</th>
                    </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                    {filteredData.ledgers.map(l => (
                        <tr key={l.id}>
                            <td className="p-5 text-slate-400 font-bold text-xs uppercase tracking-tighter">{new Date(l.date).toLocaleDateString()}</td>
                            <td className="p-5 font-black text-slate-800 uppercase text-xs">{l.description}</td>
                            <td className="p-5 text-[9px] font-black uppercase text-slate-400 tracking-widest">{l.entityType} ({l.type})</td>
                            <td className={`p-5 text-right font-black text-base ${l.type === 'Debit' ? 'text-rose-600' : 'text-emerald-600'}`}>
                                {l.amount} {data.settings.currency}
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>

        <div className="mt-20 pt-10 border-t border-slate-200 flex justify-between items-end">
            <div>
                <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest">System Authenticated Signature</p>
                <p className="text-base font-black text-indigo-600 uppercase tracking-tighter mt-2">Certified by SoftSellZone Intelligence</p>
            </div>
            <div className="text-right">
                <p className="text-[9px] font-black text-slate-300 uppercase tracking-widest mb-10">Verification Seal</p>
                <div className="w-48 h-px bg-slate-900 ml-auto"></div>
                <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest mt-4">Authorized Business Auditor</p>
            </div>
        </div>
      </div>
    </div>
  );
};

interface ReportMetricCardProps {
    title: string;
    value: number;
    currency: string;
    icon: React.ElementType;
    color: string;
    bg: string;
    onClick: () => void;
}

const ReportMetricCard: React.FC<ReportMetricCardProps> = ({ title, value, currency, icon: Icon, color, bg, onClick }) => (
    <button 
        onClick={onClick}
        className="text-left bg-white p-6 md:p-8 rounded-[2.5rem] border border-slate-200 shadow-sm transition-all hover:shadow-xl hover:border-indigo-100 hover:scale-[1.02] active:scale-[0.98] group relative"
    >
        <div className="flex justify-between items-start mb-8">
            <div className={`p-4 rounded-2xl ${bg} ${color} transition-transform group-hover:scale-110 shadow-sm`}>
                <Icon size={24} />
            </div>
            <div className="text-slate-300 group-hover:text-indigo-600 transition-colors flex items-center gap-1">
                <p className="text-[8px] font-black uppercase opacity-0 group-hover:opacity-100 transition-opacity">View Detail</p>
                <ArrowRight size={14} />
            </div>
        </div>
        <p className="text-[10px] font-black text-slate-400 uppercase tracking-[0.3em] mb-1.5 leading-none">{title}</p>
        <h4 className="text-2xl md:text-3xl font-black text-slate-900 tracking-tighter leading-none">{value.toLocaleString()} <span className="text-xs font-medium text-slate-300">{currency}</span></h4>
    </button>
);

export default Reports;
