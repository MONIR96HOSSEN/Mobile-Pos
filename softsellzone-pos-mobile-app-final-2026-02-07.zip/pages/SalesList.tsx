
import React, { useState, useMemo } from 'react';
import { useStore } from '../store';
import { 
  Search, 
  Printer, 
  FileText, 
  X, 
  Trash2, 
  ChevronRight, 
  TrendingUp, 
  Download,
  Eye,
  Calendar,
  User,
  ShoppingBag
} from 'lucide-react';
import Receipt from '../components/Receipt';
import { Sale } from '../types';

declare var html2pdf: any;

const SalesList: React.FC = () => {
  const { data, language, currentUser, deleteSale } = useStore();
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedSale, setSelectedSale] = useState<Sale | null>(null);
  const [printLayout, setPrintLayout] = useState<'thermal' | 'full'>('thermal');
  const [isGeneratingPDF, setIsGeneratingPDF] = useState(false);

  const isOwner = currentUser?.role === 'Owner';

  const filteredSales = useMemo(() => {
    return data.sales.filter(s => {
      const customer = data.customers.find(c => c.id === s.customerId);
      const customerName = customer?.name.toLowerCase() || 'walk-in customer';
      const searchLower = searchTerm.toLowerCase();
      
      return (
        s.invoiceNo.toLowerCase().includes(searchLower) ||
        customerName.includes(searchLower)
      );
    });
  }, [data.sales, data.customers, searchTerm]);

  const triggerPDFDownload = async () => {
    if (!selectedSale) return;
    setIsGeneratingPDF(true);
    
    const element = document.getElementById('sales-list-receipt-container');
    if (!element) {
        setIsGeneratingPDF(false);
        return window.print();
    }

    const opt = {
      margin: 0,
      filename: `SoftSell_${selectedSale.invoiceNo}.pdf`,
      image: { type: 'jpeg', quality: 0.98 },
      html2canvas: { scale: 3, useCORS: true, logging: false },
      jsPDF: { 
        unit: 'mm', 
        format: printLayout === 'thermal' ? [58, 200] : 'a4', 
        orientation: 'portrait' 
      }
    };

    try {
        await html2pdf().set(opt).from(element).save();
    } catch (err) {
        console.error("PDF Gen Error:", err);
        window.print();
    } finally {
        setIsGeneratingPDF(false);
    }
  };

  const handleDeleteSale = (e: React.MouseEvent, saleId: string, invoiceNo: string) => {
    e.stopPropagation(); // Prevent opening the detail view
    if (!isOwner) return;
    const confirmed = window.confirm(`DANGER: Delete Sale ${invoiceNo}? This reverses stock and balance changes.`);
    if (confirmed) {
        deleteSale(saleId);
    }
  };

  return (
    <div className="space-y-6 pb-20">
      {/* Header Section */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6 no-print">
        <div>
            <h2 className="text-3xl font-black text-slate-800 tracking-tighter uppercase leading-none">
                {language === 'bn' ? 'বিক্রয় তালিকা' : 'Sales History'}
            </h2>
            <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mt-2">Audit your transactions</p>
        </div>
        
        <div className="relative w-full md:w-96 group">
           <Search className="absolute left-5 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-blue-600 transition-colors" size={20} />
           <input 
              type="text" 
              placeholder={language === 'bn' ? 'চালান বা ক্রেতা খুঁজুন...' : 'Search Invoice or Client...'} 
              className="w-full pl-14 pr-6 py-4.5 rounded-[1.5rem] border border-slate-200 focus:ring-4 focus:ring-blue-600/10 focus:border-blue-600 outline-none shadow-sm transition-all font-bold text-sm bg-white"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
           />
        </div>
      </div>

      {/* Stats Summary - Mini */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 no-print">
         <div className="bg-white p-4 rounded-2xl border border-slate-100 shadow-sm">
            <p className="text-[8px] font-black text-slate-400 uppercase tracking-widest">Orders Found</p>
            <p className="text-xl font-black text-slate-900">{filteredSales.length}</p>
         </div>
         <div className="bg-blue-600 p-4 rounded-2xl shadow-lg shadow-blue-200 text-white">
            <p className="text-[8px] font-black text-blue-100 uppercase tracking-widest">Total Value</p>
            <p className="text-xl font-black">{filteredSales.reduce((s,v) => s + v.total, 0).toLocaleString()} <span className="text-[10px] opacity-60">{data.settings.currency}</span></p>
         </div>
      </div>

      {/* Responsive List / Table */}
      <div className="no-print">
        {/* Desktop Table View */}
        <div className="hidden lg:block bg-white rounded-[2.5rem] border border-slate-200 shadow-sm overflow-hidden">
            <table className="w-full text-left">
               <thead className="bg-slate-50 border-b border-slate-100 text-[10px] font-black text-slate-400 uppercase tracking-widest">
                 <tr>
                   <th className="px-8 py-6">ID & Date</th>
                   <th className="px-8 py-6">Client</th>
                   <th className="px-8 py-6 text-right">Net Value</th>
                   <th className="px-8 py-6 text-center">Payment Status</th>
                   <th className="px-8 py-6 text-right">Actions</th>
                 </tr>
               </thead>
               <tbody className="divide-y divide-slate-50">
                 {filteredSales.map(sale => (
                    <tr 
                      key={sale.id} 
                      onClick={() => setSelectedSale(sale)}
                      className="hover:bg-blue-50/40 cursor-pointer transition-colors group"
                    >
                        <td className="px-8 py-6">
                            <p className="font-black text-slate-900 text-sm">#{sale.invoiceNo}</p>
                            <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest mt-1">{new Date(sale.date).toLocaleDateString()}</p>
                        </td>
                        <td className="px-8 py-6">
                            <p className="text-slate-800 font-black text-[11px] uppercase truncate max-w-[200px]">{data.customers.find(c => c.id === sale.customerId)?.name || 'Walk-in'}</p>
                        </td>
                        <td className="px-8 py-6 text-right">
                            <p className="font-black text-slate-900 text-base">{sale.total.toLocaleString()} {data.settings.currency}</p>
                        </td>
                        <td className="px-8 py-6 text-center">
                            <span className={`px-4 py-1.5 rounded-full text-[9px] font-black uppercase tracking-widest border ${sale.dueAmount > 0 ? 'bg-rose-50 text-rose-500 border-rose-100' : 'bg-emerald-50 text-emerald-500 border-emerald-100'}`}>
                              {sale.dueAmount > 0 ? 'Partial/Due' : 'Paid'}
                            </span>
                        </td>
                        <td className="px-8 py-6 text-right">
                            <div className="flex justify-end gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                                <div className="p-3 bg-white text-blue-600 rounded-xl shadow-sm border border-slate-100"><Eye size={16}/></div>
                                {isOwner && (
                                    <button onClick={(e) => handleDeleteSale(e, sale.id, sale.invoiceNo)} className="p-3 bg-white text-rose-500 rounded-xl border border-rose-50 transition-all"><Trash2 size={16} /></button>
                                )}
                            </div>
                        </td>
                    </tr>
                 ))}
               </tbody>
            </table>
        </div>

        {/* Mobile Card View */}
        <div className="lg:hidden space-y-3">
          {filteredSales.map(sale => (
            <div 
              key={sale.id} 
              onClick={() => setSelectedSale(sale)}
              className="bg-white p-5 rounded-[2rem] border border-slate-200 shadow-sm active:scale-95 transition-all flex flex-col gap-4"
            >
               <div className="flex justify-between items-start">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-slate-50 text-slate-400 rounded-2xl flex items-center justify-center">
                      <ShoppingBag size={20}/>
                    </div>
                    <div>
                      <p className="font-black text-sm text-slate-900">#{sale.invoiceNo}</p>
                      <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest">{new Date(sale.date).toLocaleDateString()}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="font-black text-lg text-slate-900">{sale.total.toLocaleString()}</p>
                    <p className={`text-[8px] font-black uppercase tracking-widest ${sale.dueAmount > 0 ? 'text-rose-500' : 'text-emerald-500'}`}>
                      {sale.dueAmount > 0 ? 'Balance Due' : 'Paid Full'}
                    </p>
                  </div>
               </div>
               <div className="flex items-center justify-between border-t border-slate-50 pt-4">
                  <div className="flex items-center gap-2">
                    <User size={12} className="text-blue-500"/>
                    <span className="text-[10px] font-black uppercase text-slate-600 truncate max-w-[150px]">{data.customers.find(c => c.id === sale.customerId)?.name || 'Walk-in'}</span>
                  </div>
                  <ChevronRight size={16} className="text-slate-300"/>
               </div>
            </div>
          ))}
        </div>
      </div>

      {/* Detailed View Modal */}
      {selectedSale && (
        <div className="fixed inset-0 bg-slate-900/95 backdrop-blur-2xl z-[120] flex items-center justify-center p-4 overflow-y-auto no-print">
           <div className="bg-white rounded-[3rem] shadow-2xl p-6 md:p-10 w-full max-w-2xl flex flex-col animate-in zoom-in duration-300 max-h-[95vh]">
                <div className="flex justify-between items-center mb-6 border-b pb-6">
                    <div className="flex items-center gap-4">
                        <div className="w-14 h-14 bg-blue-100 text-blue-600 rounded-[1.5rem] flex items-center justify-center">
                            <FileText size={32}/>
                        </div>
                        <div>
                          <h3 className="text-2xl font-black uppercase tracking-tighter">Sale Record</h3>
                          <p className="text-[11px] font-black text-slate-400 uppercase tracking-widest mt-1">Invoice: #{selectedSale.invoiceNo}</p>
                        </div>
                    </div>
                    <button onClick={() => setSelectedSale(null)} className="p-4 bg-slate-100 rounded-full hover:bg-slate-200 transition-colors"><X size={24}/></button>
                </div>
                
                <div className="flex-1 overflow-y-auto bg-slate-50 rounded-[2.5rem] flex justify-center p-6 border border-slate-200 mb-8 scrollbar-hide shadow-inner overflow-x-hidden">
                    <div className="origin-top scale-90 sm:scale-100 w-full">
                        <Receipt 
                          sale={selectedSale} 
                          settings={data.settings} 
                          customer={data.customers.find(c => c.id === selectedSale.customerId)} 
                          layout={printLayout} 
                          showInPreview={true} 
                        />
                    </div>
                </div>
                
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 no-print">
                    <button onClick={() => setPrintLayout(printLayout === 'thermal' ? 'full' : 'thermal')} className="py-5 border-2 border-slate-100 rounded-2xl flex items-center justify-center gap-3 font-black text-[10px] uppercase tracking-widest text-slate-500 hover:border-blue-600 hover:text-blue-600 transition-all">
                      <Printer size={20}/> {printLayout === 'thermal' ? 'Full A4 Format' : 'Thermal 58mm'}
                    </button>
                    <button onClick={triggerPDFDownload} disabled={isGeneratingPDF} className={`py-5 bg-blue-600 text-white rounded-2xl font-black uppercase text-[10px] tracking-widest shadow-xl flex items-center justify-center gap-3 active:scale-95 transition-all ${isGeneratingPDF ? 'opacity-50' : ''}`}>
                      {isGeneratingPDF ? "Building PDF..." : <><Download size={22}/> Save & Download</>}
                    </button>
                </div>
                
                <div className="mt-4 flex flex-col sm:flex-row gap-2 no-print">
                    {isOwner && (
                      <button onClick={(e) => { handleDeleteSale(e, selectedSale.id, selectedSale.invoiceNo); setSelectedSale(null); }} className="flex-1 py-3 text-rose-500 font-black text-[9px] uppercase tracking-[0.2em] border border-rose-50 rounded-xl hover:bg-rose-50">Reverse Transaction</button>
                    )}
                    <button onClick={() => setSelectedSale(null)} className="flex-1 py-3 text-slate-400 font-black text-[9px] uppercase tracking-[0.2em] hover:text-slate-900 transition-colors">Return to List</button>
                </div>
           </div>
        </div>
      )}

      {/* HIDDEN PRINT-ONLY CONTAINER */}
      <div id="sales-list-receipt-container" className="print-only">
          {selectedSale && (
            <Receipt 
                sale={selectedSale} 
                settings={data.settings} 
                customer={data.customers.find(c => c.id === selectedSale.customerId)} 
                layout={printLayout}
            />
          )}
      </div>
    </div>
  );
};

export default SalesList;
