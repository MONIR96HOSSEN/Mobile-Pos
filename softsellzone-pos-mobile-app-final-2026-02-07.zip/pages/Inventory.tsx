
import React, { useState } from 'react';
import { useStore } from '../store';
import { Plus, Search, AlertCircle, Edit3, Trash2, X, Lock, Package, Layers, Calendar, Hash } from 'lucide-react';
import { Product } from '../types';

const Inventory: React.FC = () => {
  const { data, addProduct, updateProduct, deleteProduct, language, currentUser } = useStore();
  const [searchTerm, setSearchTerm] = useState('');
  const [showForm, setShowForm] = useState<'add' | 'edit' | null>(null);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [formData, setFormData] = useState({ 
    name: '', 
    category: '', 
    buyPrice: 0, 
    sellPrice: 0, 
    stock: 0, 
    lowStockAlert: 5,
    lotNo: '',
    expiryDate: ''
  });

  const isOwner = currentUser?.role === 'Owner';

  const filteredProducts = data.products.filter(p => 
    p.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
    p.category.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const openAdd = () => {
    if (!isOwner) return alert('Access Denied: Only Owners can add items.');
    setFormData({ 
      name: '', 
      category: '', 
      buyPrice: 0, 
      sellPrice: 0, 
      stock: 0, 
      lowStockAlert: 5,
      lotNo: '',
      expiryDate: ''
    });
    setShowForm('add');
  };

  const openEdit = (p: Product) => {
    setSelectedProduct(p);
    setFormData({ 
      name: p.name, 
      category: p.category, 
      buyPrice: p.buyPrice, 
      sellPrice: p.sellPrice, 
      stock: p.stock, 
      lowStockAlert: p.lowStockAlert,
      lotNo: p.lotNo || '',
      expiryDate: p.expiryDate || ''
    });
    setShowForm('edit');
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (showForm === 'add') {
      addProduct(formData);
    } else if (showForm === 'edit' && selectedProduct) {
      updateProduct(selectedProduct.id, formData);
    }
    setShowForm(null);
  };

  const handleDelete = (id: string) => {
    if (!isOwner) return;
    if (confirm('Delete this product permanently?')) {
      deleteProduct(id);
    }
  };

  return (
    <div className="space-y-6 pb-24">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
            <h2 className="text-3xl font-black text-slate-800 tracking-tighter uppercase leading-none">Stock Control</h2>
            <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mt-1">Live Inventory Warehouse</p>
        </div>
        {isOwner && (
            <button 
                onClick={openAdd}
                className="w-full md:w-auto bg-indigo-600 text-white px-8 py-4 rounded-2xl flex items-center justify-center gap-2 hover:bg-indigo-700 transition-all font-black text-[10px] uppercase tracking-widest shadow-xl shadow-indigo-100"
            >
                <Plus size={18} /> New Item
            </button>
        )}
      </div>

      <div className="relative">
        <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
        <input 
          type="text" 
          placeholder="Search inventory..."
          className="w-full pl-12 pr-4 py-4 border border-slate-200 rounded-2xl focus:ring-4 focus:ring-indigo-600/10 outline-none transition-all shadow-sm font-bold text-sm bg-white"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
        {filteredProducts.length === 0 ? (
            <div className="col-span-full py-20 text-center opacity-30">
                <Package size={60} className="mx-auto mb-4" strokeWidth={1}/>
                <p className="text-xs font-black uppercase tracking-widest">Stock is empty</p>
            </div>
        ) : (
            filteredProducts.map(p => {
                const isLow = p.stock <= p.lowStockAlert;
                return (
                    <div key={p.id} className={`bg-white p-5 rounded-[2rem] border transition-all shadow-sm flex flex-col justify-between group ${isLow ? 'border-rose-100' : 'border-slate-200 hover:border-indigo-200'}`}>
                        <div>
                            <div className="flex justify-between items-start mb-4">
                                <div className="p-3 bg-slate-50 text-slate-400 rounded-2xl group-hover:bg-indigo-50 group-hover:text-indigo-600 transition-colors">
                                    <Layers size={20} />
                                </div>
                                <span className={`px-4 py-1.5 rounded-xl text-[9px] font-black uppercase tracking-widest ${isLow ? 'bg-rose-100 text-rose-600' : 'bg-emerald-100 text-emerald-600'}`}>
                                    {p.stock} Units
                                </span>
                            </div>
                            <h3 className="font-black text-slate-900 uppercase text-xs tracking-tight leading-tight mb-1">{p.name}</h3>
                            <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-3">{p.category}</p>
                            
                            {/* Lot and Expiry details */}
                            {(p.lotNo || p.expiryDate) && (
                              <div className="flex gap-3 mb-4 p-2 bg-slate-50 rounded-xl border border-slate-100 border-dashed">
                                  {p.lotNo && (
                                    <div className="flex items-center gap-1">
                                      <Hash size={10} className="text-slate-400"/>
                                      <span className="text-[9px] font-black text-slate-500 uppercase">{p.lotNo}</span>
                                    </div>
                                  )}
                                  {p.expiryDate && (
                                    <div className="flex items-center gap-1">
                                      <Calendar size={10} className="text-rose-400"/>
                                      <span className="text-[9px] font-black text-rose-500 uppercase">{p.expiryDate}</span>
                                    </div>
                                  )}
                              </div>
                            )}

                            <div className="grid grid-cols-2 gap-2 mb-4">
                                <div className="p-3 bg-slate-50 rounded-2xl border border-slate-100">
                                    <p className="text-[8px] font-black text-slate-400 uppercase tracking-widest">Buy</p>
                                    <p className="font-black text-xs text-slate-800">
                                        {isOwner ? `${p.buyPrice}` : '***'}
                                    </p>
                                </div>
                                <div className="p-3 bg-indigo-50/50 rounded-2xl border border-indigo-100/50">
                                    <p className="text-[8px] font-black text-indigo-400 uppercase tracking-widest">Sell</p>
                                    <p className="font-black text-xs text-indigo-600">{p.sellPrice}</p>
                                </div>
                            </div>
                        </div>

                        <div className="flex gap-2 border-t pt-4 border-slate-50">
                            <button onClick={() => openEdit(p)} className="flex-1 py-3 bg-slate-50 text-slate-600 rounded-xl font-black text-[10px] uppercase tracking-widest hover:bg-slate-100 transition-all flex items-center justify-center gap-2">
                                <Edit3 size={14}/> Edit
                            </button>
                            {isOwner && (
                                <button onClick={() => handleDelete(p.id)} className="w-12 h-12 bg-rose-50 text-rose-400 rounded-xl flex items-center justify-center hover:bg-rose-600 hover:text-white transition-all">
                                    <Trash2 size={16}/>
                                </button>
                            )}
                        </div>
                    </div>
                );
            })
        )}
      </div>

      {showForm && (
        <div className="fixed inset-0 bg-slate-900/80 backdrop-blur-md z-[100] flex items-end sm:items-center justify-center p-4">
          <div className="bg-white w-full max-w-lg rounded-t-[3rem] sm:rounded-[3rem] shadow-2xl overflow-hidden animate-slide-up sm:animate-in sm:zoom-in">
            <div className="px-8 py-6 bg-slate-900 text-white flex justify-between items-center">
              <h3 className="font-black text-xs uppercase tracking-widest">{showForm === 'add' ? 'New Asset' : 'Modify Asset'}</h3>
              <button onClick={() => setShowForm(null)} className="p-2 hover:bg-white/10 rounded-full transition-colors"><X size={24}/></button>
            </div>
            <form onSubmit={handleSubmit} className="p-8 space-y-6">
              <div className="grid grid-cols-2 gap-4">
                <div className="col-span-2">
                  <label className="block text-[9px] font-black text-slate-400 uppercase ml-2 tracking-widest">Product Name</label>
                  <input type="text" required className="w-full p-4 border border-slate-200 rounded-xl font-bold bg-slate-50 outline-none focus:ring-2 focus:ring-indigo-600" value={formData.name} onChange={(e) => setFormData({ ...formData, name: e.target.value })} />
                </div>
                <div>
                  <label className="block text-[9px] font-black text-slate-400 uppercase ml-2 tracking-widest">Category</label>
                  <input type="text" className="w-full p-4 border border-slate-200 rounded-xl font-bold bg-slate-50 outline-none focus:ring-2 focus:ring-indigo-600" value={formData.category} onChange={(e) => setFormData({ ...formData, category: e.target.value })} />
                </div>
                <div>
                  <label className="block text-[9px] font-black text-slate-400 uppercase ml-2 tracking-widest">Initial Stock</label>
                  <input type="number" className="w-full p-4 border border-slate-200 rounded-xl font-bold bg-slate-50 outline-none focus:ring-2 focus:ring-indigo-600" value={formData.stock} onChange={(e) => setFormData({ ...formData, stock: Number(e.target.value) })} />
                </div>
                
                {/* New Lot and Expiry Fields */}
                <div>
                  <label className="block text-[9px] font-black text-slate-400 uppercase ml-2 tracking-widest">Lot No / Batch</label>
                  <input type="text" placeholder="e.g. BN-2024" className="w-full p-4 border border-slate-200 rounded-xl font-bold bg-slate-50 outline-none focus:ring-2 focus:ring-indigo-600" value={formData.lotNo} onChange={(e) => setFormData({ ...formData, lotNo: e.target.value })} />
                </div>
                <div>
                  <label className="block text-[9px] font-black text-slate-400 uppercase ml-2 tracking-widest">Expiry Date</label>
                  <input type="date" className="w-full p-4 border border-slate-200 rounded-xl font-bold bg-slate-50 outline-none focus:ring-2 focus:ring-indigo-600" value={formData.expiryDate} onChange={(e) => setFormData({ ...formData, expiryDate: e.target.value })} />
                </div>

                <div>
                  <label className="block text-[9px] font-black text-slate-400 uppercase ml-2 tracking-widest">Buy Price {isOwner ? '' : '(Locked)'}</label>
                  <input type="number" disabled={!isOwner} className="w-full p-4 border border-slate-200 rounded-xl font-bold bg-slate-50 outline-none focus:ring-2 focus:ring-indigo-600 disabled:opacity-40" value={formData.buyPrice} onChange={(e) => setFormData({ ...formData, buyPrice: Number(e.target.value) })} />
                </div>
                <div>
                  <label className="block text-[9px] font-black text-slate-400 uppercase ml-2 tracking-widest">Sell Price</label>
                  <input type="number" className="w-full p-4 border border-slate-200 rounded-xl font-bold bg-slate-50 outline-none focus:ring-2 focus:ring-indigo-600" value={formData.sellPrice} onChange={(e) => setFormData({ ...formData, sellPrice: Number(e.target.value) })} />
                </div>
              </div>
              <button type="submit" className="w-full py-5 bg-indigo-600 text-white rounded-2xl font-black uppercase text-[10px] tracking-widest shadow-xl active:scale-95 transition-all">Apply Records</button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default Inventory;