
import React, { useState, useMemo } from 'react';
import { useStore } from '../store';
import { 
  Plus, 
  Search, 
  Receipt, 
  Trash2, 
  Edit3, 
  X, 
  Calendar, 
  DollarSign, 
  Filter, 
  TrendingDown, 
  ArrowUpRight,
  Clock,
  Tag,
  ChevronRight
} from 'lucide-react';
import { Expense } from '../types';

const Expenses: React.FC = () => {
  const { data, addExpense, updateExpense, deleteExpense, language, currentUser } = useStore();
  const [searchTerm, setSearchTerm] = useState('');
  const [showForm, setShowForm] = useState<'add' | 'edit' | null>(null);
  const [selectedExpense, setSelectedExpense] = useState<Expense | null>(null);
  const [reportFilter, setReportFilter] = useState<'daily' | 'weekly' | 'monthly'>('daily');
  
  const [formData, setFormData] = useState({
    date: new Date().toISOString().split('T')[0],
    category: '',
    amount: 0,
    description: ''
  });

  const isOwner = currentUser?.role === 'Owner';

  const filteredExpenses = useMemo(() => {
    return data.expenses.filter(e => 
      e.category.toLowerCase().includes(searchTerm.toLowerCase()) || 
      e.description.toLowerCase().includes(searchTerm.toLowerCase())
    );
  }, [data.expenses, searchTerm]);

  const reportMetrics = useMemo(() => {
    const now = new Date();
    const today = now.toISOString().split('T')[0];
    const startOfWeek = new Date(now);
    startOfWeek.setDate(now.getDate() - 7);
    const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);

    const expensesForPeriod = data.expenses.filter(e => {
        const d = new Date(e.date);
        if (reportFilter === 'daily') return e.date.startsWith(today);
        if (reportFilter === 'weekly') return d >= startOfWeek;
        if (reportFilter === 'monthly') return d >= startOfMonth;
        return true;
    });

    return {
        total: expensesForPeriod.reduce((sum, e) => sum + e.amount, 0),
        count: expensesForPeriod.length,
        items: expensesForPeriod
    };
  }, [data.expenses, reportFilter]);

  const openAdd = () => {
    setFormData({
      date: new Date().toISOString().split('T')[0],
      category: '',
      amount: 0,
      description: ''
    });
    setShowForm('add');
  };

  const openEdit = (e: Expense) => {
    if (!isOwner) return alert('Only owners can edit expenses.');
    setSelectedExpense(e);
    setFormData({
      date: e.date.split('T')[0],
      category: e.category,
      amount: e.amount,
      description: e.description
    });
    setShowForm('edit');
  };

  const handleSubmit = (ev: React.FormEvent) => {
    ev.preventDefault();
    if (showForm === 'add') {
      addExpense({ ...formData, date: new Date(formData.date).toISOString() });
    } else if (showForm === 'edit' && selectedExpense) {
      updateExpense(selectedExpense.id, { ...formData, date: new Date(formData.date).toISOString() });
    }
    setShowForm(null);
  };

  const handleDelete = (id: string) => {
    if (!isOwner) return alert('Only owners can delete expenses.');
    if (confirm('Are you sure you want to delete this expense?')) {
      deleteExpense(id);
    }
  };

  return (
    <div className="space-y-6 pb-24">
      {/* Header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
        <div>
            <h2 className="text-3xl font-black text-slate-900 tracking-tighter uppercase leading-none">Expense Tracker</h2>
            <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mt-1">Manage Business Outflows</p>
        </div>
        <button 
          onClick={openAdd}
          className="w-full md:w-auto bg-rose-600 text-white px-8 py-4 rounded-2xl flex items-center justify-center gap-3 hover:bg-rose-700 transition-all font-black text-[10px] uppercase tracking-widest shadow-xl shadow-rose-100"
        >
          <Plus size={18} /> Record New Expense
        </button>
      </div>

      {/* Reports Section */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="md:col-span-1 space-y-4">
            <div className="bg-white p-6 rounded-[2rem] border border-slate-200 shadow-sm flex flex-col justify-between h-40 md:h-44 group hover:border-rose-100 transition-all">
                <div className="flex justify-between items-start">
                    <div className="w-12 h-12 bg-rose-50 text-rose-600 rounded-2xl flex items-center justify-center shadow-inner group-hover:scale-110 transition-transform">
                        <TrendingDown size={24}/>
                    </div>
                    <div className="flex bg-slate-50 p-1 rounded-xl gap-1">
                        {(['daily', 'weekly', 'monthly'] as const).map(f => (
                            <button 
                                key={f} 
                                onClick={() => setReportFilter(f)}
                                className={`px-2 py-1 text-[8px] font-black uppercase rounded-lg transition-all ${reportFilter === f ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-400'}`}
                            >
                                {f}
                            </button>
                        ))}
                    </div>
                </div>
                <div>
                    <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest mb-1">{reportFilter.toUpperCase()} OUTFLOW</p>
                    <h4 className="text-3xl font-black text-slate-900">{reportMetrics.total.toLocaleString()} <span className="text-xs font-medium text-slate-300">{data.settings.currency}</span></h4>
                </div>
            </div>
        </div>

        <div className="md:col-span-2 bg-white p-6 rounded-[2rem] border border-slate-200 shadow-sm">
            <div className="flex justify-between items-center mb-6">
                <h3 className="text-xs font-black uppercase tracking-widest flex items-center gap-2">
                    <Clock size={16} className="text-rose-600" /> Recent Period History
                </h3>
            </div>
            <div className="space-y-3 max-h-48 overflow-y-auto scrollbar-hide">
                {reportMetrics.items.length === 0 ? (
                    <p className="text-center py-10 text-[10px] font-black text-slate-300 uppercase tracking-widest">No expenses found for this period</p>
                ) : (
                    reportMetrics.items.map(e => (
                        <div key={e.id} className="flex items-center justify-between p-3 bg-slate-50 rounded-xl hover:bg-rose-50/50 transition-colors">
                            <div className="flex items-center gap-3">
                                <div className="text-[9px] font-black bg-white px-2 py-1 rounded-lg text-rose-500 shadow-sm">{new Date(e.date).toLocaleDateString([], {day:'2-digit', month:'short'})}</div>
                                <div>
                                    <p className="text-[10px] font-black text-slate-900 uppercase leading-none">{e.category}</p>
                                    <p className="text-[8px] font-bold text-slate-400 uppercase mt-1 line-clamp-1">{e.description}</p>
                                </div>
                            </div>
                            <span className="font-black text-xs text-rose-600">-{e.amount}</span>
                        </div>
                    ))
                )}
            </div>
        </div>
      </div>

      {/* Main List */}
      <div className="space-y-4">
        <div className="relative group">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-rose-600 transition-colors" size={18} />
            <input 
              type="text" 
              placeholder="Search by category or details..."
              className="w-full pl-12 pr-4 py-4 border border-slate-200 rounded-2xl focus:ring-4 focus:ring-rose-600/10 outline-none transition-all shadow-sm font-bold text-sm bg-white"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
        </div>

        {/* Desktop View Table */}
        <div className="hidden md:block bg-white rounded-[2.5rem] border border-slate-200 shadow-sm overflow-hidden">
            <table className="w-full text-left">
                <thead className="bg-slate-50 border-b border-slate-100 text-[10px] font-black text-slate-400 uppercase tracking-widest">
                    <tr>
                        <th className="px-8 py-5">Date & Category</th>
                        <th className="px-8 py-5">Description</th>
                        <th className="px-8 py-5 text-right">Amount</th>
                        <th className="px-8 py-5 text-right">Actions</th>
                    </tr>
                </thead>
                <tbody className="divide-y divide-slate-50">
                    {filteredExpenses.length === 0 ? (
                        <tr>
                            <td colSpan={4} className="py-20 text-center">
                                <Receipt size={48} className="mx-auto mb-4 text-slate-200" strokeWidth={1} />
                                <p className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-300">Clean Slate: No Expenses</p>
                            </td>
                        </tr>
                    ) : (
                        filteredExpenses.map(e => (
                            <tr key={e.id} className="hover:bg-slate-50/50 transition-colors group">
                                <td className="px-8 py-5">
                                    <p className="font-black text-slate-900 text-[11px] uppercase">{e.category}</p>
                                    <p className="text-[9px] font-bold text-slate-400 mt-1 uppercase tracking-widest">{new Date(e.date).toLocaleDateString()}</p>
                                </td>
                                <td className="px-8 py-5">
                                    <p className="text-[10px] font-bold text-slate-500 uppercase leading-relaxed max-w-xs">{e.description}</p>
                                </td>
                                <td className="px-8 py-5 text-right">
                                    <span className="font-black text-rose-600 text-sm">-{e.amount}</span>
                                </td>
                                <td className="px-8 py-5 text-right">
                                    <div className="flex justify-end gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                                        <button onClick={() => openEdit(e)} className="p-3 bg-white border border-slate-100 text-slate-400 hover:text-indigo-600 hover:border-indigo-100 rounded-xl transition-all shadow-sm">
                                            <Edit3 size={16} />
                                        </button>
                                        <button onClick={() => handleDelete(e.id)} className="p-3 bg-white border border-slate-100 text-slate-400 hover:text-rose-600 hover:border-rose-100 rounded-xl transition-all shadow-sm">
                                            <Trash2 size={16} />
                                        </button>
                                    </div>
                                </td>
                            </tr>
                        ))
                    )}
                </tbody>
            </table>
        </div>

        {/* Mobile View Cards */}
        <div className="md:hidden space-y-3">
            {filteredExpenses.length === 0 ? (
                <div className="bg-white p-12 text-center rounded-[2rem] border-2 border-dashed border-slate-100">
                    <Receipt size={40} className="mx-auto mb-3 text-slate-200" />
                    <p className="text-[10px] font-black uppercase text-slate-300">No Expenses Recorded</p>
                </div>
            ) : (
                filteredExpenses.map(e => (
                    <div key={e.id} className="bg-white p-5 rounded-[2rem] border border-slate-200 shadow-sm flex flex-col gap-4 relative group">
                        <div className="flex justify-between items-start">
                            <div className="flex items-center gap-3">
                                <div className="w-10 h-10 bg-rose-50 text-rose-500 rounded-2xl flex items-center justify-center font-black text-xs">
                                    <Receipt size={18}/>
                                </div>
                                <div>
                                    <p className="font-black text-[11px] text-slate-900 uppercase leading-none">{e.category}</p>
                                    <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest mt-1.5">{new Date(e.date).toLocaleDateString()}</p>
                                </div>
                            </div>
                            <div className="text-right">
                                <p className="font-black text-base text-rose-600">-{e.amount}</p>
                                <p className="text-[8px] font-black text-slate-300 uppercase">Amount</p>
                            </div>
                        </div>
                        
                        <div className="bg-slate-50 p-3 rounded-xl">
                            <p className="text-[10px] font-medium text-slate-600 leading-relaxed uppercase">{e.description || 'No description provided'}</p>
                        </div>

                        <div className="flex gap-2 pt-2 border-t border-slate-50">
                            <button onClick={() => openEdit(e)} className="flex-1 py-3 bg-indigo-50 text-indigo-600 rounded-xl font-black text-[9px] uppercase tracking-widest flex items-center justify-center gap-2 active:scale-95 transition-all">
                                <Edit3 size={14}/> Edit Record
                            </button>
                            <button onClick={() => handleDelete(e.id)} className="w-12 h-12 bg-rose-50 text-rose-600 rounded-xl flex items-center justify-center active:scale-95 transition-all">
                                <Trash2 size={16}/>
                            </button>
                        </div>
                    </div>
                ))
            )}
        </div>
      </div>

      {/* Expense Modal */}
      {showForm && (
        <div className="fixed inset-0 bg-slate-900/80 backdrop-blur-md z-[100] flex items-end sm:items-center justify-center p-4">
          <div className="bg-white w-full max-w-md rounded-t-[3rem] sm:rounded-[3rem] shadow-2xl overflow-hidden animate-slide-up sm:animate-in sm:zoom-in">
            <div className="px-8 py-6 bg-rose-600 text-white flex justify-between items-center">
              <h3 className="font-black text-xs uppercase tracking-widest">{showForm === 'add' ? 'Record Expense' : 'Modify Record'}</h3>
              <button onClick={() => setShowForm(null)} className="p-2 hover:bg-white/10 rounded-full transition-colors"><X size={24}/></button>
            </div>
            <form onSubmit={handleSubmit} className="p-8 space-y-6">
              <div className="space-y-4">
                <div>
                  <label className="block text-[9px] font-black text-slate-400 uppercase ml-2 tracking-widest">Date</label>
                  <input type="date" required className="w-full p-4 border border-slate-200 rounded-xl font-bold bg-slate-50 outline-none focus:ring-2 focus:ring-rose-600" value={formData.date} onChange={(e) => setFormData({ ...formData, date: e.target.value })} />
                </div>
                <div>
                  <label className="block text-[9px] font-black text-slate-400 uppercase ml-2 tracking-widest">Category</label>
                  <div className="relative">
                    <input 
                      list="expense-categories"
                      className="w-full p-4 border border-slate-200 rounded-xl font-bold bg-slate-50 outline-none focus:ring-2 focus:ring-rose-600 uppercase text-[10px] tracking-widest pr-10"
                      placeholder="Enter or Select Category"
                      value={formData.category}
                      onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                      required
                    />
                    <Tag className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-300" size={16} />
                    <datalist id="expense-categories">
                      <option value="Shop Rent" />
                      <option value="Electricity Bill" />
                      <option value="Staff Salary" />
                      <option value="Conveyance / Travel" />
                      <option value="Tea / Refreshment" />
                      <option value="Internet / Wifi" />
                      <option value="Marketing / Ads" />
                      <option value="Maintenance" />
                      <option value="Miscellaneous" />
                    </datalist>
                  </div>
                </div>
                <div>
                  <label className="block text-[9px] font-black text-slate-400 uppercase ml-2 tracking-widest">Amount Spent</label>
                  <input type="number" required className="w-full p-4 border border-slate-200 rounded-xl font-black bg-slate-50 text-xl text-center outline-none focus:ring-2 focus:ring-rose-600" value={formData.amount || ''} onChange={(e) => setFormData({ ...formData, amount: Number(e.target.value) })} />
                </div>
                <div>
                  <label className="block text-[9px] font-black text-slate-400 uppercase ml-2 tracking-widest">Description</label>
                  <textarea rows={3} className="w-full p-4 border border-slate-200 rounded-xl font-bold bg-slate-50 outline-none focus:ring-2 focus:ring-rose-600" value={formData.description} onChange={(e) => setFormData({ ...formData, description: e.target.value })} />
                </div>
              </div>
              <button type="submit" className="w-full py-5 bg-rose-600 text-white rounded-2xl font-black uppercase text-[10px] tracking-widest shadow-xl active:scale-95 transition-all">
                {showForm === 'add' ? 'Assign Entry' : 'Commit Changes'}
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default Expenses;
