import React, { useState } from 'react';
import { useStore } from '../store';
import { UserPlus, Search, Phone, Calculator, ChevronRight, User } from 'lucide-react';

const Customers: React.FC = () => {
  const { data, addCustomer, collectDue, language } = useStore();
  const [showAddForm, setShowAddForm] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  
  const [newCust, setNewCust] = useState({ name: '', phone: '', address: '', balance: 0 });
  const [collectAmount, setCollectAmount] = useState({ customerId: '', amount: 0, note: '' });

  const filteredCustomers = data.customers.filter(c => 
    c.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
    c.phone.includes(searchTerm)
  );

  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCust.name) return;
    addCustomer({ ...newCust });
    setNewCust({ name: '', phone: '', address: '', balance: 0 });
    setShowAddForm(false);
  };

  const handleCollection = (e: React.FormEvent) => {
    e.preventDefault();
    if (collectAmount.amount <= 0) return;
    collectDue(collectAmount.customerId, collectAmount.amount, collectAmount.note);
    setCollectAmount({ customerId: '', amount: 0, note: '' });
    alert('Payment collected successfully!');
  };

  return (
    <div className="space-y-6 pb-24">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
            <h2 className="text-3xl font-black text-slate-800 tracking-tighter uppercase leading-none">
                {language === 'bn' ? 'ক্রেতা তালিকা' : 'Client Registry'}
            </h2>
            <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mt-1">Manage Receivables & History</p>
        </div>
        <button 
          onClick={() => setShowAddForm(true)}
          className="w-full md:w-auto bg-blue-600 text-white px-8 py-4 rounded-2xl flex items-center justify-center gap-3 hover:bg-blue-700 transition-all font-black text-[10px] uppercase tracking-widest shadow-xl"
        >
          <UserPlus size={18} />
          {language === 'bn' ? 'নতুন ক্রেতা' : 'Add New Client'}
        </button>
      </div>

      <div className="relative">
        <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
        <input 
          type="text" 
          placeholder="Search name or phone..."
          className="w-full pl-12 pr-4 py-4 border border-slate-200 rounded-2xl outline-none shadow-sm font-bold text-sm bg-white focus:ring-4 focus:ring-blue-600/10"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredCustomers.map(c => (
            <div key={c.id} className="bg-white p-5 rounded-[2.5rem] border border-slate-200 shadow-sm flex flex-col justify-between group hover:border-blue-100 transition-all">
                <div className="flex justify-between items-start mb-4">
                    <div className="flex items-center gap-3">
                        <div className="w-12 h-12 bg-slate-50 text-slate-400 rounded-2xl flex items-center justify-center font-black text-xl border border-slate-100 group-hover:bg-blue-50 group-hover:text-blue-600 transition-all">
                            {c.name.charAt(0)}
                        </div>
                        <div>
                            <h3 className="font-black text-slate-900 uppercase text-xs tracking-tight leading-none">{c.name}</h3>
                            <p className="text-[10px] font-bold text-slate-400 mt-1 uppercase flex items-center gap-1">
                                <Phone size={10} /> {c.phone}
                            </p>
                        </div>
                    </div>
                    <div className="text-right">
                        <p className="text-[8px] font-black text-slate-400 uppercase tracking-widest mb-1">Due Amount</p>
                        <p className={`text-xl font-black leading-none ${c.balance > 0 ? 'text-rose-600' : 'text-emerald-600'}`}>
                            {c.balance} <span className="text-[10px]">{data.settings.currency}</span>
                        </p>
                    </div>
                </div>
                
                <div className="flex gap-2 border-t pt-4 border-slate-50">
                    <button 
                        onClick={() => setCollectAmount({ ...collectAmount, customerId: c.id })}
                        className="flex-1 py-3 bg-blue-50 text-blue-600 rounded-xl font-black text-[10px] uppercase tracking-widest hover:bg-blue-600 hover:text-white transition-all flex items-center justify-center gap-2"
                    >
                        <Calculator size={14}/> Receive Payment
                    </button>
                </div>
            </div>
        ))}
      </div>

      {showAddForm && (
        <div className="fixed inset-0 bg-slate-900/80 backdrop-blur-md z-[100] flex items-end sm:items-center justify-center p-4">
          <div className="bg-white w-full max-w-md rounded-t-[3rem] sm:rounded-[3rem] p-8 shadow-2xl animate-in slide-in-from-bottom-10">
            <div className="flex justify-between items-center mb-8">
              <h3 className="text-xl font-black uppercase tracking-tighter">Client Registration</h3>
              <button onClick={() => setShowAddForm(false)} className="p-2 bg-slate-100 rounded-full transition-colors"><ChevronRight size={24} className="rotate-90"/></button>
            </div>
            <form onSubmit={handleAdd} className="space-y-5">
              <div className="space-y-1">
                <label className="text-[10px] font-black uppercase text-slate-400 ml-2 tracking-widest">Full Name</label>
                <input type="text" required className="w-full p-4 border border-slate-200 rounded-2xl font-bold bg-slate-50 outline-none focus:ring-2 focus:ring-blue-600" value={newCust.name} onChange={(e) => setNewCust({ ...newCust, name: e.target.value })} />
              </div>
              <div className="space-y-1">
                <label className="text-[10px] font-black uppercase text-slate-400 ml-2 tracking-widest">Phone Number</label>
                <input type="text" className="w-full p-4 border border-slate-200 rounded-2xl font-bold bg-slate-50 outline-none focus:ring-2 focus:ring-blue-600" value={newCust.phone} onChange={(e) => setNewCust({ ...newCust, phone: e.target.value })} />
              </div>
              <div className="space-y-1">
                <label className="text-[10px] font-black uppercase text-rose-500 ml-2 tracking-widest">Opening Balance (Old Due)</label>
                <input type="number" className="w-full p-4 border border-rose-100 rounded-2xl font-bold bg-rose-50 outline-none focus:ring-2 focus:ring-rose-600" value={newCust.balance || ''} onChange={(e) => setNewCust({ ...newCust, balance: Number(e.target.value) })} placeholder="0" />
              </div>
              <div className="space-y-1">
                <label className="text-[10px] font-black uppercase text-slate-400 ml-2 tracking-widest">Shop Address</label>
                <textarea className="w-full p-4 border border-slate-200 rounded-2xl font-bold bg-slate-50 outline-none focus:ring-2 focus:ring-blue-600" rows={2} value={newCust.address} onChange={(e) => setNewCust({ ...newCust, address: e.target.value })} />
              </div>
              <button type="submit" className="w-full bg-blue-600 text-white py-5 rounded-2xl font-black uppercase text-[10px] tracking-widest shadow-xl mt-4">
                Finalize Registry
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default Customers;