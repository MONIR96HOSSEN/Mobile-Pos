import React, { useState } from 'react';
import { useStore } from '../store';
import { Truck, Plus, Phone, Wallet, X } from 'lucide-react';

const Suppliers: React.FC = () => {
  const { data, addSupplier, paySupplier, language } = useStore();
  const [showAdd, setShowAdd] = useState(false);
  const [payAmount, setPayAmount] = useState({ supplierId: '', amount: 0 });

  const handleAdd = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    addSupplier({
      name: formData.get('name') as string,
      phone: formData.get('phone') as string,
      address: formData.get('address') as string,
      balance: Number(formData.get('balance')) || 0
    });
    setShowAdd(false);
  };

  const handlePayment = () => {
    if (payAmount.amount <= 0) return;
    paySupplier(payAmount.supplierId, payAmount.amount, "Direct Payment");
    setPayAmount({ supplierId: '', amount: 0 });
    alert('Payment recorded.');
  };

  return (
    <div className="space-y-6 pb-24">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-3xl font-black text-slate-800 tracking-tighter uppercase leading-none">
            {language === 'bn' ? 'সরবরাহকারী' : 'Suppliers'}
          </h2>
          <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mt-1">Vendor Network Management</p>
        </div>
        <button onClick={() => setShowAdd(true)} className="bg-blue-600 text-white px-6 py-3 rounded-2xl flex items-center gap-2 font-black text-[10px] uppercase tracking-widest shadow-xl">
          <Plus size={20}/> {language === 'bn' ? 'নতুন সরবরাহকারী' : 'Add Supplier'}
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-4">
           <div className="bg-white rounded-[2.5rem] border border-slate-200 overflow-x-auto shadow-sm">
             <table className="w-full text-left min-w-[500px]">
               <thead>
                 <tr className="bg-slate-50 border-b text-[10px] font-black text-slate-400 uppercase tracking-widest">
                    <th className="px-8 py-6">Supplier Details</th>
                    <th className="px-8 py-6 text-right">Payable Balance</th>
                    <th className="px-8 py-6 text-right">Action</th>
                 </tr>
               </thead>
               <tbody className="divide-y divide-slate-100">
                 {data.suppliers.map(s => (
                   <tr key={s.id} className="hover:bg-slate-50 text-sm">
                     <td className="px-8 py-6">
                        <p className="font-black text-slate-900 uppercase text-xs">{s.name}</p>
                        <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest mt-1 flex items-center gap-1"><Phone size={12}/> {s.phone}</p>
                     </td>
                     <td className="px-8 py-6 text-right text-rose-600 font-black text-lg">{s.balance} <span className="text-xs">{data.settings.currency}</span></td>
                     <td className="px-8 py-6 text-right">
                       <button onClick={() => setPayAmount({ supplierId: s.id, amount: 0 })} className="px-4 py-2 bg-blue-50 text-blue-600 font-black text-[10px] uppercase rounded-xl hover:bg-blue-600 hover:text-white transition-all">Record Pay</button>
                     </td>
                   </tr>
                 ))}
               </tbody>
             </table>
           </div>
        </div>

        <div className="space-y-6">
           {payAmount.supplierId && (
             <div className="bg-blue-50 p-6 rounded-[2rem] border border-blue-100 shadow-sm animate-in fade-in slide-in-from-top-4">
               <h3 className="font-black flex items-center gap-2 mb-4 text-blue-900 uppercase text-xs tracking-tighter"><Wallet size={18}/> Record Payment</h3>
               <div className="space-y-4">
                  <div>
                    <label className="text-[9px] font-black text-blue-700 block mb-1 uppercase tracking-widest ml-2">Amount to Pay</label>
                    <input type="number" className="w-full p-4 border border-blue-200 rounded-xl bg-white font-black outline-none focus:ring-2 focus:ring-blue-600" value={payAmount.amount || ''} onChange={e => setPayAmount({ ...payAmount, amount: Number(e.target.value) })} />
                  </div>
                  <div className="flex gap-2">
                    <button onClick={handlePayment} className="flex-1 bg-blue-600 text-white py-4 rounded-xl font-black uppercase text-[10px] tracking-widest shadow-lg">Confirm Pay</button>
                    <button onClick={() => setPayAmount({ supplierId: '', amount: 0 })} className="p-4 bg-white border border-blue-200 rounded-xl text-blue-400"><X size={18}/></button>
                  </div>
               </div>
             </div>
           )}
        </div>
      </div>

      {showAdd && (
        <div className="fixed inset-0 bg-slate-900/80 backdrop-blur-md z-[100] flex items-end sm:items-center justify-center p-4">
          <form onSubmit={handleAdd} className="bg-white w-full max-w-md rounded-t-[3rem] sm:rounded-[3rem] p-8 shadow-2xl space-y-5 animate-in slide-in-from-bottom-10">
             <div className="flex justify-between items-center mb-4">
               <h3 className="text-xl font-black uppercase tracking-tighter">Supplier Registration</h3>
               <button type="button" onClick={() => setShowAdd(false)} className="p-2 bg-slate-100 rounded-full transition-colors"><X size={24}/></button>
             </div>
             <div>
               <label className="block text-[10px] font-black uppercase text-slate-400 ml-2 tracking-widest mb-1">Company Name</label>
               <input name="name" required className="w-full p-4 border border-slate-200 rounded-2xl font-bold bg-slate-50 outline-none focus:ring-2 focus:ring-blue-600" />
             </div>
             <div>
               <label className="block text-[10px] font-black uppercase text-slate-400 ml-2 tracking-widest mb-1">Contact Phone</label>
               <input name="phone" className="w-full p-4 border border-slate-200 rounded-2xl font-bold bg-slate-50 outline-none focus:ring-2 focus:ring-blue-600" />
             </div>
             <div>
               <label className="block text-[10px] font-black uppercase text-rose-500 ml-2 tracking-widest mb-1">Opening Balance (Old Payable)</label>
               <input name="balance" type="number" placeholder="0" className="w-full p-4 border border-rose-100 rounded-2xl font-bold bg-rose-50 outline-none focus:ring-2 focus:ring-rose-600" />
             </div>
             <div>
               <label className="block text-[10px] font-black uppercase text-slate-400 ml-2 tracking-widest mb-1">Office Address</label>
               <textarea name="address" rows={2} className="w-full p-4 border border-slate-200 rounded-2xl font-bold bg-slate-50 outline-none focus:ring-2 focus:ring-blue-600" />
             </div>
             <button type="submit" className="w-full py-5 bg-blue-600 text-white font-black uppercase text-[10px] tracking-widest rounded-2xl shadow-xl">Assign Vendor ID</button>
          </form>
        </div>
      )}
    </div>
  );
};

export default Suppliers;