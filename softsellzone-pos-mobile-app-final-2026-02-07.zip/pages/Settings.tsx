import React, { useState, useRef } from 'react';
import { useStore } from '../store';
import { 
    Save, 
    Building, 
    Trash2, 
    Database, 
    DownloadCloud, 
    RefreshCcw, 
    RotateCcw, 
    ShieldAlert, 
    Lock,
    Share2,
    Copy,
    CheckCircle2,
    Cloud,
    ClipboardPaste,
    FileUp,
    HardDrive,
    Mail,
    Coins,
    TextQuote,
    MapPin
} from 'lucide-react';
import { UserRole, AppData } from '../types';

const SettingsPage: React.FC = () => {
  const { data, updateSettings, currentUser, importData, resetDatabase, language } = useStore();
  const [formData, setFormData] = useState(data.settings);
  const [showResetModal, setShowResetModal] = useState(false);
  const [showRestoreTextModal, setShowRestoreTextModal] = useState(false);
  const [restoreText, setRestoreText] = useState('');
  const [resetPassword, setResetPassword] = useState('');
  const [copySuccess, setCopySuccess] = useState(false);

  const isOwner = currentUser?.role === 'Owner';
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    updateSettings(formData);
    alert('Global settings updated successfully.');
  };

  /**
   * BASE64 EXPORT (Android Compatible Interception)
   */
  const handleBackup = async (mode: 'share' | 'download') => {
    const jsonData = JSON.stringify(data);
    const timestamp = new Date().toISOString().slice(0, 10);
    const fileName = `softsell_master_backup_${timestamp}.json`;

    if (mode === 'share' && navigator.share) {
        try {
            await navigator.share({
                title: 'SoftSell Master Backup',
                text: jsonData
            });
            return;
        } catch (e) { console.log("Share action ignored or cancelled"); }
    }

    // Force Base64 for Android Native interception via MainActivity.kt
    const base64Data = btoa(unescape(encodeURIComponent(jsonData)));
    const dataUri = `data:application/json;base64,${base64Data}`;
    
    const link = document.createElement('a');
    link.href = dataUri;
    link.download = fileName;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleCopyData = () => {
    navigator.clipboard.writeText(JSON.stringify(data)).then(() => {
        setCopySuccess(true);
        setTimeout(() => setCopySuccess(false), 2000);
    });
  };

  const handleTextRestore = () => {
    try {
        const importedData = JSON.parse(restoreText) as AppData;
        if (!importedData.products || !importedData.settings) throw new Error();
        importData(importedData);
        alert("Database Restored Successfully!");
        window.location.reload();
    } catch (err) { alert("Invalid data format. Please paste a valid JSON string."); }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-12 pb-24">
      {isOwner && (
        <>
          <div className="space-y-6">
            <h2 className="text-2xl font-black text-slate-800 tracking-tight uppercase">Business Information</h2>
            <form onSubmit={handleSubmit} className="bg-white rounded-[2.5rem] border border-slate-200 shadow-sm overflow-hidden">
                <div className="p-8 space-y-8">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div className="space-y-1">
                            <label className="text-[10px] font-black uppercase text-slate-400 ml-2 tracking-widest">Shop Name</label>
                            <div className="relative">
                                <Building size={16} className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-300" />
                                <input type="text" className="w-full pl-12 p-4 border border-slate-200 rounded-xl bg-slate-50 font-bold outline-none focus:ring-2 focus:ring-indigo-600 transition-all" value={formData.name} onChange={e => setFormData({ ...formData, name: e.target.value })} />
                            </div>
                        </div>
                        <div className="space-y-1">
                            <label className="text-[10px] font-black uppercase text-slate-400 ml-2 tracking-widest">Business Phone</label>
                            <input type="text" className="w-full p-4 border border-slate-200 rounded-xl bg-slate-50 font-bold outline-none focus:ring-2 focus:ring-indigo-600 transition-all" value={formData.phone} onChange={e => setFormData({ ...formData, phone: e.target.value })} />
                        </div>
                        <div className="space-y-1">
                            <label className="text-[10px] font-black uppercase text-slate-400 ml-2 tracking-widest">Business Email</label>
                            <div className="relative">
                                <Mail size={16} className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-300" />
                                <input type="email" className="w-full pl-12 p-4 border border-slate-200 rounded-xl bg-slate-50 font-bold outline-none focus:ring-2 focus:ring-indigo-600 transition-all" value={formData.email || ''} onChange={e => setFormData({ ...formData, email: e.target.value })} />
                            </div>
                        </div>
                        <div className="space-y-1">
                            <label className="text-[10px] font-black uppercase text-slate-400 ml-2 tracking-widest">Currency Symbol</label>
                            <div className="relative">
                                <Coins size={16} className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-300" />
                                <input type="text" className="w-full pl-12 p-4 border border-slate-200 rounded-xl bg-slate-50 font-bold outline-none focus:ring-2 focus:ring-indigo-600 transition-all" placeholder="৳" value={formData.currency} onChange={e => setFormData({ ...formData, currency: e.target.value })} />
                            </div>
                        </div>
                        <div className="md:col-span-2 space-y-1">
                            <label className="text-[10px] font-black uppercase text-slate-400 ml-2 tracking-widest">Full Business Address</label>
                            <div className="relative">
                                <MapPin size={16} className="absolute left-4 top-4 text-slate-300" />
                                <textarea rows={3} className="w-full pl-12 p-4 border border-slate-200 rounded-xl bg-slate-50 font-bold outline-none focus:ring-2 focus:ring-indigo-600 transition-all" value={formData.address} onChange={e => setFormData({ ...formData, address: e.target.value })} />
                            </div>
                        </div>
                        <div className="md:col-span-2 space-y-1">
                            <label className="text-[10px] font-black uppercase text-slate-400 ml-2 tracking-widest">Receipt Footer message</label>
                            <div className="relative">
                                <TextQuote size={16} className="absolute left-4 top-4 text-slate-300" />
                                <textarea rows={2} className="w-full pl-12 p-4 border border-slate-200 rounded-xl bg-slate-50 font-bold outline-none focus:ring-2 focus:ring-indigo-600 transition-all" placeholder="e.g. Thanks for shopping!" value={formData.invoiceFooter} onChange={e => setFormData({ ...formData, invoiceFooter: e.target.value })} />
                            </div>
                        </div>
                    </div>
                    <button type="submit" className="w-full bg-slate-900 text-white py-5 rounded-2xl font-black uppercase text-[11px] tracking-widest shadow-2xl hover:bg-black transition-all flex items-center justify-center gap-3">
                        <Save size={20}/> Update System Config
                    </button>
                </div>
            </form>
          </div>

          <div className="space-y-6">
            <h2 className="text-2xl font-black text-slate-800 flex items-center gap-3 uppercase">
                <Database className="text-amber-500" /> Database & Storage
            </h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="bg-white p-8 rounded-[2.5rem] border border-slate-200 shadow-sm flex flex-col justify-between group">
                    <div>
                        <div className="flex items-center gap-3 mb-4">
                            <div className="p-3 bg-indigo-100 text-indigo-600 rounded-2xl">
                                <HardDrive size={24}/>
                            </div>
                            <h4 className="font-black text-slate-900 uppercase text-xs tracking-widest">Export All Data</h4>
                        </div>
                        <p className="text-[10px] text-slate-400 font-medium leading-relaxed mb-6 italic">
                            Saves a .json backup to your device's <b>Downloads</b> folder for safety.
                        </p>
                    </div>
                    <div className="space-y-3">
                        <button onClick={() => handleBackup('download')} className="w-full py-5 bg-indigo-600 text-white rounded-xl font-black text-[10px] uppercase tracking-widest flex items-center justify-center gap-3 active:scale-95 transition-transform shadow-lg">
                            <DownloadCloud size={20}/> Download To Local
                        </button>
                        <button onClick={() => handleBackup('share')} className="w-full py-4 bg-slate-50 border border-slate-100 text-slate-500 rounded-xl font-black text-[10px] uppercase tracking-widest flex items-center justify-center gap-3">
                            <Share2 size={18}/> Share To Cloud
                        </button>
                        <button onClick={handleCopyData} className="w-full py-3 bg-slate-50 text-slate-400 rounded-xl font-black text-[9px] uppercase hover:bg-slate-100">
                            {copySuccess ? "Data String Copied!" : "Copy Raw String"}
                        </button>
                    </div>
                </div>

                <div className="bg-white p-8 rounded-[2.5rem] border border-slate-200 shadow-sm flex flex-col justify-between">
                    <div>
                        <div className="flex items-center gap-3 mb-4">
                            <div className="p-3 bg-emerald-100 text-emerald-600 rounded-2xl">
                                <RefreshCcw size={24}/>
                            </div>
                            <h4 className="font-black text-slate-900 uppercase text-xs tracking-widest">Restore System</h4>
                        </div>
                        <p className="text-[10px] text-slate-400 font-medium leading-relaxed mb-6 italic">
                            Upload your backup file or paste the raw data string to recover business state.
                        </p>
                    </div>
                    <div className="space-y-3">
                        <input type="file" ref={fileInputRef} className="hidden" accept=".json" onChange={e => {
                            const file = e.target.files?.[0];
                            if (file) {
                                const reader = new FileReader();
                                reader.onload = (ev) => {
                                    try {
                                        importData(JSON.parse(ev.target?.result as string));
                                        alert("Restoration Complete!");
                                        window.location.reload();
                                    } catch (err) { alert("Format Error: Corrupted file."); }
                                };
                                reader.readAsText(file);
                            }
                        }} />
                        <button onClick={() => fileInputRef.current?.click()} className="w-full py-5 bg-emerald-600 text-white rounded-xl font-black text-[10px] uppercase tracking-widest flex items-center justify-center gap-3 shadow-lg">
                            <FileUp size={20}/> Upload JSON File
                        </button>
                        <button onClick={() => setShowRestoreTextModal(true)} className="w-full py-4 bg-slate-50 border border-slate-100 text-slate-500 rounded-xl font-black text-[10px] uppercase">
                            Paste Raw String
                        </button>
                    </div>
                </div>
            </div>
          </div>

          <div className="bg-rose-50 p-8 rounded-[2.5rem] border border-rose-100 flex flex-col md:flex-row items-center justify-between gap-6">
                <div className="flex items-center gap-4">
                    <div className="w-14 h-14 bg-white text-rose-600 rounded-2xl flex items-center justify-center shadow-sm">
                        <RotateCcw size={28} />
                    </div>
                    <div>
                        <p className="text-xs font-black text-rose-900 uppercase tracking-tighter">Factory Reset</p>
                        <p className="text-[10px] font-bold text-rose-400 uppercase tracking-widest">Wipe all history and start fresh</p>
                    </div>
                </div>
                <button onClick={() => setShowResetModal(true)} className="w-full md:w-auto bg-rose-600 text-white px-10 py-4 rounded-2xl font-black text-[10px] uppercase tracking-widest shadow-xl active:scale-95 transition-all">Destroy All Records</button>
          </div>
        </>
      )}

      {showRestoreTextModal && (
        <div className="fixed inset-0 bg-slate-900/90 backdrop-blur-xl z-[200] flex items-center justify-center p-4">
            <div className="bg-white w-full max-w-lg rounded-[3rem] p-10 space-y-8 animate-in zoom-in">
                <div className="text-center">
                    <ClipboardPaste size={60} className="mx-auto text-indigo-600 mb-2" />
                    <h3 className="text-xl font-black uppercase">Restore Hub</h3>
                </div>
                <textarea rows={8} placeholder="Paste JSON string here..." className="w-full p-5 border-2 border-slate-100 rounded-2xl font-mono text-[10px] outline-none bg-slate-50 focus:border-indigo-600" value={restoreText} onChange={(e) => setRestoreText(e.target.value)} />
                <button onClick={handleTextRestore} className="w-full py-5 bg-indigo-600 text-white rounded-2xl font-black uppercase text-[10px] tracking-widest">Restore Now</button>
                <button onClick={() => setShowRestoreTextModal(false)} className="w-full text-slate-400 font-black uppercase text-[9px]">Cancel</button>
            </div>
        </div>
      )}

      {showResetModal && (
        <div className="fixed inset-0 bg-slate-900/90 backdrop-blur-xl z-[200] flex items-center justify-center p-4">
            <div className="bg-white w-full max-w-sm rounded-[3rem] p-10 space-y-8 animate-in zoom-in text-center">
                <ShieldAlert size={60} className="text-rose-600 mx-auto" />
                <h3 className="text-2xl font-black uppercase">Confirm Wipe?</h3>
                <input type="password" placeholder="ADMIN PASSCODE" className="w-full p-5 border-2 border-slate-100 rounded-2xl text-center outline-none focus:border-rose-600 bg-slate-50 font-black text-xl" value={resetPassword} onChange={(e) => setResetPassword(e.target.value)} />
                <button onClick={() => {
                         if (resetPassword === (currentUser?.password || '123')) { resetDatabase(); window.location.reload(); }
                         else { alert('Incorrect Code'); }
                    }} className="w-full py-5 bg-rose-600 text-white rounded-2xl font-black uppercase text-[10px] tracking-widest shadow-2xl">Confirm Nuclear Reset</button>
                <button onClick={() => setShowResetModal(false)} className="w-full text-slate-400 font-black uppercase text-[9px]">Cancel</button>
            </div>
        </div>
      )}
    </div>
  );
};

export default SettingsPage;