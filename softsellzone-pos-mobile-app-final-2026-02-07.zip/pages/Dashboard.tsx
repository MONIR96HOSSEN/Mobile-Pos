
import React, { useMemo } from 'react';
import { 
    TrendingUp, 
    Wallet, 
    CreditCard, 
    ArrowUpCircle, 
    AlertTriangle,
    History,
    ChevronRight,
    ArrowUpRight,
    ArrowDownRight,
    Package,
    Lock,
    Receipt,
    CalendarCheck,
    Clock
} from 'lucide-react';
import { useStore } from '../store';
import { TRANSLATIONS } from '../constants';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from 'recharts';
import { useNavigate } from 'react-router-dom';

const Dashboard: React.FC = () => {
  const { data, language, currentUser } = useStore();
  const t = TRANSLATIONS[language];
  const isOwner = currentUser?.role === 'Owner';
  const navigate = useNavigate();

  const stats = useMemo(() => {
    const today = new Date().toISOString().split('T')[0];
    
    const todaySales = data.sales
        .filter(s => s.date.startsWith(today))
        .reduce((sum, s) => sum + s.total, 0);

    const todayExpenses = data.expenses
        .filter(e => e.date.startsWith(today))
        .reduce((sum, e) => sum + e.amount, 0);

    const todayCollection = data.ledgers
        .filter(l => l.date.startsWith(today) && l.entityType === 'Customer' && l.type === 'Credit')
        .reduce((sum, l) => sum + l.amount, 0);

    const totalCustomerDue = data.customers.reduce((sum, c) => sum + c.balance, 0);

    const totalSalesCash = data.sales.reduce((sum, s) => sum + s.paidAmount, 0);
    const totalDueCollected = data.ledgers
        .filter(l => l.entityType === 'Customer' && l.type === 'Credit')
        .reduce((sum, l) => sum + l.amount, 0);
    const totalPurchasesPaid = data.purchases.reduce((sum, p) => sum + p.paidAmount, 0);
    const totalExpenses = data.expenses.reduce((sum, e) => sum + e.amount, 0);
    
    const cashInHand = totalSalesCash + totalDueCollected - totalPurchasesPaid - totalExpenses;

    const todayReminders = data.reminders.filter(r => r.date === today && !r.completed);

    return { todaySales, todayExpenses, todayCollection, totalCustomerDue, cashInHand, todayReminders };
  }, [data]);

  const recentActivity = useMemo(() => {
    return data.sales.slice(0, 5).map(s => ({
        id: s.id,
        title: `Sale to ${data.customers.find(c => c.id === s.customerId)?.name || 'Walk-in'}`,
        amount: s.total,
        type: 'sale',
        time: s.date
    }));
  }, [data.sales, data.customers]);

  const lowStockItems = data.products.filter(p => p.stock <= p.lowStockAlert);

  const chartData = useMemo(() => {
      const days = [...Array(7)].map((_, i) => {
          const d = new Date();
          d.setDate(d.getDate() - i);
          return d.toISOString().split('T')[0];
      }).reverse();

      return days.map(day => ({
          name: new Date(day).toLocaleDateString(language === 'bn' ? 'bn-BD' : 'en-US', { weekday: 'short' }),
          sales: data.sales.filter(s => s.date.startsWith(day)).reduce((sum, s) => sum + s.total, 0)
      }));
  }, [data.sales, language]);

  return (
    <div className="space-y-6 md:space-y-10 pb-10">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
              <h1 className="text-3xl md:text-4xl font-black text-slate-900 tracking-tighter uppercase leading-none">Intelligence</h1>
              <p className="text-slate-400 font-black uppercase tracking-[0.3em] text-[10px] mt-1">Real-time Performance Metrics</p>
          </div>
          {isOwner && (
            <div className="bg-white px-5 py-4 rounded-[1.5rem] border border-slate-200 flex items-center gap-4 shadow-sm w-full md:w-auto animate-in slide-in-from-right-4 transition-all hover:border-indigo-100">
                <div className="text-right flex-1 md:flex-none">
                    <p className="text-[9px] font-black uppercase text-slate-400 tracking-widest">Total Liquid Cash</p>
                    <p className="text-xl font-black text-indigo-600">{stats.cashInHand} <span className="text-[10px] font-medium text-slate-300">{data.settings.currency}</span></p>
                </div>
                <div className="w-12 h-12 bg-indigo-50 text-indigo-600 rounded-2xl flex items-center justify-center shadow-inner">
                    <CreditCard size={22} />
                </div>
            </div>
          )}
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 md:gap-6">
        <SummaryCard 
            title={t.todaySales} 
            value={stats.todaySales} 
            currency={data.settings.currency}
            icon={TrendingUp} 
            color="bg-indigo-600" 
            trend="+12%"
        />
        <SummaryCard 
            title={language === 'bn' ? 'আজকের খরচ' : "Today's Expense"} 
            value={stats.todayExpenses} 
            currency={data.settings.currency}
            icon={Receipt} 
            color="bg-rose-600" 
            trend="Out"
        />
        {isOwner ? (
            <>
                <SummaryCard 
                    title={t.todayDue} 
                    value={stats.todayCollection} 
                    currency={data.settings.currency}
                    icon={ArrowUpCircle} 
                    color="bg-emerald-600" 
                    trend="+5%"
                />
                <SummaryCard 
                    title={t.totalDue} 
                    value={stats.totalCustomerDue} 
                    currency={data.settings.currency}
                    icon={Wallet} 
                    color="bg-amber-600" 
                    trend="Debt"
                />
            </>
        ) : (
            <div className="col-span-2 bg-white p-4 rounded-[2rem] border-2 border-dashed border-slate-100 flex flex-col items-center justify-center text-center">
                <Lock className="text-slate-200 mb-2" size={24} />
                <p className="text-[9px] font-black text-slate-300 uppercase tracking-widest">Restricted Owner Stats</p>
            </div>
        )}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 md:gap-8">
        <div className="lg:col-span-2 space-y-6 md:space-y-8">
            <div className="bg-white p-6 md:p-10 rounded-[2.5rem] border border-slate-200 shadow-sm relative overflow-hidden group">
                <div className="absolute top-0 right-0 p-8 opacity-[0.03] group-hover:scale-110 transition-transform">
                    <TrendingUp size={160} />
                </div>
                <h3 className="text-lg md:text-xl font-black mb-8 flex items-center gap-3 text-slate-800 uppercase tracking-tighter">
                    <div className="w-10 h-10 bg-indigo-50 text-indigo-600 rounded-xl flex items-center justify-center">
                        <TrendingUp size={20} />
                    </div>
                    Revenue performance
                </h3>
                {isOwner ? (
                    <div className="h-[240px] md:h-[350px]">
                        <ResponsiveContainer width="100%" height="100%">
                            <BarChart data={chartData} margin={{ top: 0, right: 0, left: -25, bottom: 0 }}>
                                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                                <XAxis 
                                    dataKey="name" 
                                    axisLine={false} 
                                    tickLine={false} 
                                    tick={{ fill: '#94a3b8', fontSize: 10, fontWeight: 700 }}
                                />
                                <YAxis 
                                    axisLine={false} 
                                    tickLine={false} 
                                    tick={{ fill: '#94a3b8', fontSize: 10, fontWeight: 700 }}
                                />
                                <Tooltip 
                                    contentStyle={{ borderRadius: '20px', border: 'none', boxShadow: '0 25px 50px -12px rgb(0 0 0 / 0.15)', padding: '15px' }}
                                    cursor={{ fill: '#f8fafc' }}
                                />
                                <Bar dataKey="sales" radius={[10, 10, 10, 10]} barSize={20}>
                                    {chartData.map((entry, index) => (
                                        <Cell key={`cell-${index}`} fill={index === 6 ? '#4f46e5' : '#e2e8f0'} className="hover:fill-indigo-400 transition-all duration-500" />
                                    ))}
                                </Bar>
                            </BarChart>
                        </ResponsiveContainer>
                    </div>
                ) : (
                    <div className="h-[240px] md:h-[350px] bg-slate-50 rounded-3xl flex flex-col items-center justify-center text-center p-6 border border-slate-100">
                        <Lock className="text-slate-200 mb-4" size={48} />
                        <p className="text-xs font-black text-slate-400 uppercase tracking-widest max-w-xs">Restricted Access</p>
                    </div>
                )}
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 md:gap-8">
                {/* Reminders Widget */}
                <div className="bg-white p-6 md:p-8 rounded-[2rem] border border-slate-200 shadow-sm flex flex-col">
                    <h3 className="text-base font-black mb-6 flex items-center justify-between uppercase tracking-tighter">
                        <span className="flex items-center gap-2">
                            <CalendarCheck size={18} className="text-rose-600" />
                            {language === 'bn' ? 'আজকের রিমাইন্ডার' : "Today's Tasks"}
                        </span>
                        <button onClick={() => navigate('/reminders')} className="text-blue-600 text-[10px] font-black uppercase tracking-widest hover:underline">View All</button>
                    </h3>
                    <div className="space-y-3 flex-1">
                        {stats.todayReminders.length === 0 ? (
                            <div className="flex flex-col items-center justify-center py-10 opacity-30">
                                <Clock size={32} className="mb-2" />
                                <p className="text-[10px] font-black uppercase tracking-widest">No tasks for today</p>
                            </div>
                        ) : (
                            stats.todayReminders.slice(0, 4).map(rem => (
                                <div key={rem.id} className="flex items-start gap-3 p-3 bg-slate-50 rounded-2xl border border-slate-100">
                                    <div className={`w-2 h-2 mt-1.5 rounded-full shrink-0 ${rem.priority === 'High' ? 'bg-rose-500' : rem.priority === 'Medium' ? 'bg-amber-500' : 'bg-indigo-500'}`} />
                                    <div className="min-w-0">
                                        <p className="text-[11px] font-black text-slate-800 uppercase tracking-tight line-clamp-1">{rem.title}</p>
                                        <p className="text-[9px] font-bold text-slate-400 uppercase tracking-widest mt-0.5">{rem.time}</p>
                                    </div>
                                </div>
                            ))
                        )}
                    </div>
                </div>

                <div className="bg-slate-900 p-6 md:p-8 rounded-[2rem] shadow-2xl text-white relative overflow-hidden group">
                    <div className="absolute -bottom-10 -right-10 opacity-10 rotate-12 scale-150 group-hover:scale-[1.7] transition-transform duration-700">
                        <Wallet size={160} />
                    </div>
                    <h3 className="text-[9px] font-black mb-6 uppercase tracking-[0.3em] text-white/30">Receivables Ledger</h3>
                    <div className="space-y-6 relative z-10">
                        <div>
                            <p className="text-white/40 text-[9px] font-black uppercase mb-2 tracking-widest">Outstanding Credits</p>
                            <div className="flex items-end gap-2">
                                <h4 className="text-3xl md:text-4xl font-black">{isOwner ? stats.totalCustomerDue : '***'}</h4>
                                {isOwner && (
                                    <p className="text-[9px] font-black text-rose-400 bg-rose-400/10 px-2 py-1 rounded-lg flex items-center gap-1 mb-1 tracking-tighter uppercase"><ArrowDownRight size={12}/> Alert</p>
                                )}
                            </div>
                        </div>
                        <div className="pt-6 border-t border-white/10">
                            <p className="text-white/40 text-[9px] font-black uppercase mb-3 tracking-widest">Efficiency index</p>
                            <div className="w-full bg-white/5 h-2 rounded-full overflow-hidden">
                                <div className="bg-indigo-500 h-full rounded-full shadow-[0_0_20px_rgba(79,70,229,0.5)]" style={{ width: '65%' }}></div>
                            </div>
                            <div className="flex justify-between mt-2">
                                <p className="text-[8px] text-white/40 font-black uppercase tracking-widest">65% Collections</p>
                                <p className="text-[8px] text-indigo-400 font-black uppercase tracking-widest">Target 90%</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div className="space-y-6 md:space-y-8">
            <div className="bg-white p-6 md:p-8 rounded-[2.5rem] border border-slate-200 shadow-sm h-full">
                <div className="flex justify-between items-center mb-6">
                    <h3 className="text-base md:text-lg font-black flex items-center gap-3 uppercase tracking-tighter">
                        <AlertTriangle size={20} className="text-amber-500" />
                        Stock Status
                    </h3>
                    <span className="bg-rose-50 text-rose-500 px-3 py-1.5 rounded-xl text-[9px] font-black uppercase tracking-widest">
                        {lowStockItems.length} Warnings
                    </span>
                </div>
                <div className="space-y-2">
                    {lowStockItems.length === 0 ? (
                        <div className="flex flex-col items-center justify-center py-16 text-slate-200">
                             <Package size={50} strokeWidth={1} className="mb-4 opacity-50" />
                             <p className="text-[10px] font-black uppercase tracking-widest text-slate-400">Inventory Secure</p>
                        </div>
                    ) : (
                        lowStockItems.slice(0, 6).map(item => (
                            <div key={item.id} className="flex justify-between items-center p-4 bg-slate-50 rounded-[1.5rem] border border-slate-100 hover:border-rose-100 transition-all">
                                <div>
                                    <p className="text-[11px] font-black text-slate-800 uppercase tracking-tight leading-none mb-1">{item.name}</p>
                                    <p className="text-[8px] text-slate-400 font-black uppercase tracking-widest">{item.category}</p>
                                </div>
                                <div className="text-right">
                                    <p className="text-xs font-black text-rose-600">{item.stock}</p>
                                    <p className="text-[8px] text-slate-400 font-black uppercase">Units Left</p>
                                </div>
                            </div>
                        ))
                    )}
                </div>
                {lowStockItems.length > 0 && (
                    <button className="w-full mt-8 py-4 bg-slate-50 border-2 border-dashed border-slate-200 rounded-2xl text-[9px] font-black text-slate-400 hover:bg-white hover:border-indigo-400 hover:text-indigo-600 transition-all uppercase tracking-[0.2em]">
                        Inspect Full Inventory
                    </button>
                )}
            </div>
        </div>
      </div>
    </div>
  );
};

interface SummaryCardProps {
  title: string;
  value: number;
  currency: string;
  icon: React.ElementType;
  color: string;
  trend: string;
  className?: string;
}

const SummaryCard: React.FC<SummaryCardProps> = ({ title, value, currency, icon: Icon, color, trend, className = "" }) => (
    <div className={`bg-white p-4 md:p-6 rounded-[2rem] border border-slate-200 shadow-sm flex flex-col justify-between h-36 md:h-44 group hover:border-indigo-100 hover:shadow-xl transition-all duration-300 ${className}`}>
        <div className="flex justify-between items-start">
            <div className={`w-10 h-10 md:w-14 md:h-14 ${color} rounded-2xl flex items-center justify-center text-white shadow-xl shadow-indigo-100 group-hover:scale-110 transition-transform`}>
                <Icon size={20} className="md:size-28" />
            </div>
            <span className={`text-[7px] md:text-[9px] font-black px-2 py-1 md:px-3 md:py-1.5 rounded-xl uppercase tracking-widest ${trend.startsWith('+') ? 'bg-emerald-50 text-emerald-600' : trend.startsWith('-') ? 'bg-rose-50 text-rose-600' : 'bg-slate-50 text-slate-600'}`}>
                {trend}
            </span>
        </div>
        <div>
            <p className="text-[7px] md:text-[9px] font-black text-slate-400 uppercase tracking-[0.2em] mb-1 leading-none truncate">{title}</p>
            <h4 className="text-lg md:text-3xl font-black text-slate-900 tracking-tighter leading-none">{value.toLocaleString()} <span className="text-[9px] md:text-xs font-medium text-slate-300">{currency}</span></h4>
        </div>
    </div>
);

export default Dashboard;
