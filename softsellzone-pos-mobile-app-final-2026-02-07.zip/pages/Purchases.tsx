
import React, { useState } from 'react';
import { useStore } from '../store';
import { Plus, Search, ShoppingBag, Truck, History } from 'lucide-react';
import { Product, Purchase } from '../types';

const Purchases: React.FC = () => {
  const { data, addPurchase, language } = useStore();
  const [showAdd, setShowAdd] = useState(false);
  const [cart, setCart] = useState<{ productId: string, name: string, quantity: number, price: number }[]>([]);
  const [supplierId, setSupplierId] = useState(data.suppliers[0]?.id || '');
  const [paidAmount, setPaidAmount] = useState(0);

  const total = cart.reduce((sum, i) => sum + (i.price * i.quantity), 0);

  const handleAddToCart = (p: Product) => {
    setCart(prev => {
      const exists = prev.find(i => i.productId === p.id);
      if (exists) return prev.map(i => i.productId === p.id ? { ...i, quantity: i.quantity + 1 } : i);
      return [...prev, { productId: p.id, name: p.name, quantity: 1, price: p.buyPrice }];
    });
  };

  const handleSave = () => {
    if (cart.length === 0 || !supplierId) return;
    addPurchase({
      date: new Date().toISOString(),
      supplierId,
      items: cart.map(i => ({ ...i, total: i.price * i.quantity })),
      total,
      paidAmount,
      dueAmount: total - paidAmount
    });
    setCart([]);
    setPaidAmount(0);
    setShowAdd(false);
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">{language === 'bn' ? 'ক্রয় ব্যবস্থাপনা' : 'Purchase Management'}</h2>
        <button onClick={() => setShowAdd(true)} className="bg-indigo-600 text-white px-4 py-2 rounded-lg flex items-center gap-2">
          <Plus size={20} /> {language === 'bn' ? 'নতুন স্টক ক্রয়' : 'New Purchase'}
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 bg-white rounded-xl border border-slate-200 overflow-hidden shadow-sm">
          <div className="p-4 border-b bg-slate-50 font-bold flex items-center gap-2">
            <History size={18} /> {language === 'bn' ? 'সাম্প্রতিক ক্রয়' : 'Recent Purchases'}
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-left">
              <thead>
                <tr className="bg-slate-50 border-b text-xs text-slate-500 uppercase tracking-wider">
                  <th className="px-6 py-3">Date</th>
                  <th className="px-6 py-3">Supplier</th>
                  <th className="px-6 py-3 text-right">Total</th>
                  <th className="px-6 py-3 text-right">Paid</th>
                  <th className="px-6 py-3 text-right">Due</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {data.purchases.map(p => (
                  <tr key={p.id} className="text-sm">
                    <td className="px-6 py-3">{new Date(p.date).toLocaleDateString()}</td>
                    <td className="px-6 py-3 font-medium">{data.suppliers.find(s => s.id === p.supplierId)?.name}</td>
                    <td className="px-6 py-3 text-right">{p.total}</td>
                    <td className="px-6 py-3 text-right text-green-600">{p.paidAmount}</td>
                    <td className="px-6 py-3 text-right text-red-600 font-bold">{p.dueAmount}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm h-fit">
          <h3 className="font-bold mb-4 flex items-center gap-2 text-indigo-600"><Truck size={20}/> Quick Supplier View</h3>
          <div className="space-y-3">
            {data.suppliers.map(s => (
              <div key={s.id} className="flex justify-between items-center p-3 bg-slate-50 rounded-lg">
                <span className="text-sm font-medium">{s.name}</span>
                <span className="text-sm font-bold text-red-600">{s.balance} {data.settings.currency}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {showAdd && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-4xl rounded-2xl overflow-hidden shadow-2xl flex flex-col max-h-[90vh]">
            <div className="p-4 bg-slate-900 text-white flex justify-between">
              <h3 className="font-bold">Add Purchase Entry</h3>
              <button onClick={() => setShowAdd(false)}>✕</button>
            </div>
            <div className="flex-1 flex flex-col md:flex-row overflow-hidden">
              <div className="flex-1 p-6 overflow-y-auto">
                <div className="mb-6">
                  <label className="block text-sm font-bold mb-2 uppercase text-slate-500">Select Supplier</label>
                  <select className="w-full p-2 border rounded-lg" value={supplierId} onChange={e => setSupplierId(e.target.value)}>
                    {data.suppliers.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
                  </select>
                </div>
                <div className="space-y-4">
                   <h4 className="font-bold text-sm">Select Products to Add</h4>
                   <div className="grid grid-cols-2 gap-3">
                     {data.products.map(p => (
                       <button key={p.id} onClick={() => handleAddToCart(p)} className="p-3 border rounded-lg text-left hover:border-indigo-600 transition-colors">
                         <div className="font-bold text-sm">{p.name}</div>
                         <div className="text-xs text-slate-400">Current: {p.stock} | Buy: {p.buyPrice}</div>
                       </button>
                     ))}
                   </div>
                </div>
              </div>
              <div className="w-full md:w-80 bg-slate-50 border-l p-6 flex flex-col">
                 <h4 className="font-bold mb-4">Cart Summary</h4>
                 <div className="flex-1 overflow-y-auto space-y-3">
                    {cart.map(i => (
                      <div key={i.productId} className="text-xs flex justify-between border-b pb-2">
                        <span>{i.name} (x{i.quantity})</span>
                        <span className="font-bold">{i.price * i.quantity}</span>
                      </div>
                    ))}
                 </div>
                 <div className="mt-4 pt-4 border-t space-y-3">
                    <div className="flex justify-between font-bold text-lg">
                      <span>Total:</span>
                      <span>{total}</span>
                    </div>
                    <div>
                      <label className="block text-[10px] font-bold uppercase mb-1">Paid Amount</label>
                      <input type="number" className="w-full p-2 border rounded" value={paidAmount} onChange={e => setPaidAmount(Number(e.target.value))} />
                    </div>
                    <button onClick={handleSave} className="w-full bg-indigo-600 text-white py-3 rounded-xl font-bold shadow-lg shadow-indigo-100">
                      Record Purchase
                    </button>
                 </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Purchases;
