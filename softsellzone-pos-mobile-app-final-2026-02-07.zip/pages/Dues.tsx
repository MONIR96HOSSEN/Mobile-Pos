import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useStore } from '../store';
import { UserCheck, Truck, ArrowUpRight, ArrowDownRight, Calculator, X, Search, ChevronRight } from 'lucide-react';

const Dues: React.FC = () => {
  const { data, collectDue, language } = useStore();
  const navigate = useNavigate();
  const [collectionForm, setCollectionForm] = useState<{customerId: string, name: string} | null>(null);
  const [amount, setAmount] = useState(0);
  const [searchTerm, setSearchTerm] = useState('');

  const custDue = data.customers.reduce((sum, c) => sum + c.balance, 0);
  const suppDue = data.suppliers.reduce((sum, s) => sum + s.balance, 0);

  const filteredCustomers = data.customers.filter(c => 
    c.balance > 0 && c.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleCollect = () => {
    if (!collectionForm || amount <= 0) return;
    collectDue(collectionForm.customerId, amount, "Fast Collection");
    setCollectionForm(null);
    setAmount(0);
    alert('Payment collected successfully!');
  };

  return (
    <div className="space-y-6 pb-20">
      <h2 className="text-2xl font-black uppercase tracking-tight">{language === 'bn' ? 'বকেয়া হিসাব' : 'Debt Registry'}</h2>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Customer Dues Card - Clickable */}
        <button 
          onClick={() => navigate('/customers')}
          className="bg-rose-50 border border-rose-100 p-6 rounded-3xl flex items-center justify-between shadow-sm hover:shadow-md hover:bg-rose-100/50 transition-all text-left active:scale-[0.98] group"
        >
          <div>
            <div className="flex items-center gap-2 mb-1">
              <p className="text-[10px] font-black text-rose-500 uppercase tracking-widest">Customer Dues (We Receive)</p>
              <ChevronRight size={10} className="text-rose-300 group-hover:translate-x-1 transition-transform" />
            </div>
            <h3 className="text-3xl font-black text-rose-900">{custDue} <span className="text-sm font-medium">{data.settings.currency}</span></h3>
          </div>
          <div className="w-12 h-12 bg-white text-rose-500 rounded-2xl flex items-center justify-center shadow-sm group-hover:scale-110 transition-transform">
            <ArrowDownRight size={24} />
          </div>
        </button>

        {/* Supplier Dues Card - Clickable */}
        <button 
          onClick={() => navigate('/suppliers')}
          className="bg-amber-50 border border-amber-100 p-6 rounded-3xl flex items-center justify-between shadow-sm hover:shadow-md hover:bg-amber-100/50 transition-all text-left active:scale-[0.98] group"
        >
          <div>
            <div className="flex items-center gap-2 mb-1">
              <p className="text-[10px] font-black text-amber-500 uppercase tracking-widest">Supplier Dues (We Pay)</p>
              <ChevronRight size={10} className="text-amber-300 group-hover:translate-x-1 transition-transform" />
            </div>
            <h3 className="text-3xl font-black text-amber-900">{suppDue} <span className="text-sm font-medium">{data.settings.currency}</span></h3>
          </div>
          <div className="w-12 h-12 bg-white text-amber-500 rounded-2xl flex items-center justify-center shadow-sm group-hover:scale-110 transition-transform">
            <ArrowUpRight size={24} />
          </div>
        </button>
      </div>

      <div className="space-y-4">
          <div className="relative">
             <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={16} />
             <input type="text" placeholder="Search debtor name..." className="w-full pl-11 pr-4 py-4 rounded-2xl border border-slate-200 text-sm font-bold bg-white outline-none focus:ring-4 focus:ring-indigo-600/10 transition-all" value={searchTerm} onChange={e => setSearchTerm(e.target.value)} />
          </div>

          <div className="bg-white rounded-[2rem] border border-slate-200 overflow-hidden shadow-sm">
            <div className="p-4 border-b bg-slate-50 font-black text-[10px] uppercase tracking-widest flex items-center gap-2">
              <UserCheck size={16} className="text-indigo-600" /> Customer Receivables
            </div>
            <div className="divide-y divide-slate-50">
                {filteredCustomers.length === 0 ? (
                    <p className="p-10 text-center text-[10px] font-black uppercase text-slate-300">No Outstanding Debts</p>
                ) : (
                    filteredCustomers.map(c => (
                        <div key={c.id} className="flex justify-between items-center p-5 hover:bg-slate-50">
                            <div>
                                <p className="font-black text-slate-800 uppercase text-xs">{c.name}</p>
                                <p className="text-[9px] text-slate-400 font-bold mt-1">Pending Balance</p>
                            </div>
                            <div className="flex items-center gap-4">
                                <span className="text-rose-600 font-black text-lg">{c.balance}</span>
                                <button onClick={() => setCollectionForm({ customerId: c.id, name: c.name })} className="p-3 bg-indigo-50 text-indigo-600 rounded-xl hover:bg-indigo-600 hover:text-white transition-all shadow-sm">
                                    <Calculator size={18}/>
                                </button>
                            </div>
                        </div>
                    ))
                )}
            </div>
         </div>
      </div>

      {collectionForm && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <div className="bg-white w-full max-w-sm rounded-[2.5rem] shadow-2xl animate-in zoom-in">
                <div className="p-6 border-b flex justify-between items-center bg-slate-50 rounded-t-[2.5rem]">
                    <h3 className="font-black text-xs uppercase">Collect Payment</h3>
                    <button onClick={() => setCollectionForm(null)} className="p-2 bg-white rounded-full"><X size={18}/></button>
                </div>
                <div className="p-8 space-y-6">
                    <div className="text-center">
                        <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Receiving from</p>
                        <p className="text-xl font-black text-indigo-600 mt-1 uppercase">{collectionForm.name}</p>
                    </div>
                    <div className="space-y-1">
                        <label className="text-[9px] font-black text-slate-400 uppercase tracking-widest ml-2">Amount Collected</label>
                        <input type="number" autoFocus className="w-full p-5 border-2 border-indigo-100 rounded-2xl text-2xl font-black text-center outline-none focus:border-indigo-600" value={amount || ''} onChange={(e) => setAmount(Number(e.target.value))} />
                    </div>
                    <button onClick={handleCollect} className="w-full py-5 bg-indigo-600 text-white rounded-2xl font-black uppercase text-[10px] tracking-[0.2em] shadow-xl">Secure Collection</button>
                </div>
            </div>
        </div>
      )}
    </div>
  );
};

export default Dues;