import React, { useState, useMemo, useEffect } from 'react';
import { 
  Search, 
  ShoppingCart, 
  Trash2, 
  Save, 
  Minus, 
  Plus, 
  X, 
  Banknote, 
  Wallet, 
  CreditCard, 
  Percent, 
  Download,
  LayoutGrid,
  CheckCircle2,
  ChevronRight,
  Receipt as ReceiptIcon,
  ArrowRight,
  ShoppingBag,
  Printer
} from 'lucide-react';
import { useStore } from '../store';
import { TRANSLATIONS } from '../constants';
import { SaleItem, Product, PaymentMode, Sale } from '../types';
import Receipt from '../components/Receipt';

declare var html2pdf: any;

const POS: React.FC = () => {
  const { data, addSale, language } = useStore();
  const t = TRANSLATIONS[language];

  const [viewMode, setViewMode] = useState<'products' | 'cart'>('products');
  const [searchQuery, setSearchQuery] = useState('');
  const [cart, setCart] = useState<SaleItem[]>([]);
  const [customerId, setCustomerId] = useState(data.customers[0]?.id || '');
  const [discount, setDiscount] = useState(0);
  const [paidAmount, setPaidAmount] = useState(0);
  const [paymentMode, setPaymentMode] = useState<PaymentMode>('Cash');
  const [lastSale, setLastSale] = useState<Sale | null>(null);
  const [printLayout, setPrintLayout] = useState<'thermal' | 'full'>('thermal');
  const [showWebPreview, setShowWebPreview] = useState(false);
  const [isGeneratingPDF, setIsGeneratingPDF] = useState(false);

  const filteredProducts = useMemo(() => {
    if (!searchQuery) return data.products;
    return data.products.filter(p => 
      p.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
      p.category.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.lotNo?.toLowerCase().includes(searchQuery.toLowerCase())
    );
  }, [data.products, searchQuery]);

  const subTotal = cart.reduce((sum, item) => sum + item.total, 0);
  const total = Math.max(0, subTotal - discount);

  useEffect(() => {
    if (paymentMode === 'Cash') setPaidAmount(total);
    else if (paymentMode === 'Due') setPaidAmount(0);
  }, [paymentMode, total]);

  const addToCart = (product: Product) => {
    setCart(prev => {
      const existing = prev.find(item => item.productId === product.id);
      if (existing) {
        return prev.map(item => 
          item.productId === product.id 
            ? { ...item, quantity: item.quantity + 1, total: (item.quantity + 1) * item.price }
            : item
        );
      }
      return [...prev, {
        productId: product.id,
        name: product.name,
        quantity: 1,
        price: product.sellPrice,
        total: product.sellPrice
      }];
    });
  };

  const updateQuantity = (productId: string, delta: number) => {
    setCart(prev => prev.map(item => {
      if (item.productId === productId) {
        const newQty = Math.max(1, item.quantity + delta);
        return { ...item, quantity: newQty, total: newQty * item.price };
      }
      return item;
    }));
  };

  const removeFromCart = (productId: string) => {
    setCart(prev => prev.filter(item => item.productId !== productId));
  };

  const handleCheckout = () => {
    if (cart.length === 0) {
      alert(language === 'bn' ? 'কার্ট খালি!' : 'Cart is empty');
      return;
    }
    if (paymentMode !== 'Cash' && customerId === 'c1') {
      alert(language === 'bn' ? 'বাকি বিক্রয়ের জন্য কাস্টমার নির্বাচন করুন।' : 'Select a customer for Dues/Partial payments.');
      return;
    }
    if (paidAmount > total) {
      alert(language === 'bn' ? 'পরিশোধিত টাকা মোট টাকার চেয়ে বেশি হতে পারে না।' : 'Paid amount exceeds total.');
      return;
    }

    try {
      const saleObj: Omit<Sale, 'id' | 'invoiceNo'> = {
        date: new Date().toISOString(),
        customerId,
        items: cart,
        subTotal,
        discount,
        total,
        paidAmount,
        dueAmount: Math.max(0, total - paidAmount),
        paymentMode
      };

      addSale(saleObj);

      const invoiceNo = `INV-${data.sales.length + 1001}`;
      setLastSale({ ...saleObj, id: Date.now().toString(), invoiceNo });
      setShowWebPreview(true);

      // Reset
      setCart([]);
      setDiscount(0);
      setPaidAmount(0);
      setPaymentMode('Cash');
      setViewMode('products');
    } catch (err) {
      alert('Error saving sale.');
    }
  };

  const triggerPDFDownload = async () => {
    if (!lastSale) return;
    setIsGeneratingPDF(true);
    const element = document.getElementById('receipt-print-area');
    if (!element) return setIsGeneratingPDF(false);

    if (typeof html2pdf !== 'undefined') {
      const isThermal = printLayout === 'thermal';
      const opt = {
        margin: [0, 0, 0, 0],
        filename: `SoftSell_${lastSale.invoiceNo}.pdf`,
        image: { type: 'jpeg', quality: 1 },
        html2canvas: { scale: 4, useCORS: true, logging: false },
        jsPDF: { 
          unit: 'mm', 
          format: isThermal ? [58, 200] : 'a4', 
          orientation: 'portrait' 
        }
      };
      try {
        await html2pdf().set(opt).from(element).save();
      } catch (err) {
        console.error("PDF Export Error:", err);
        window.print();
      }
    } else {
      window.print();
    }
    setIsGeneratingPDF(false);
  };

  return (
    <div className="h-full flex flex-col lg:flex-row gap-6 relative">
      
      {/* 1. PRODUCT SECTION */}
      <div className={`flex-1 flex flex-col min-w-0 pb-24 lg:pb-0 ${viewMode === 'cart' ? 'hidden lg:flex' : 'flex'}`}>
        {/* Search Header */}
        <div className="sticky top-0 bg-slate-50/90 backdrop-blur-md z-30 pt-2 pb-4">
          <div className="relative group">
            <Search className="absolute left-5 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-blue-600 transition-colors" size={20} />
            <input 
              type="text"
              placeholder={t.searchProduct}
              className="w-full pl-14 pr-6 py-4 rounded-[1.25rem] border border-slate-200 focus:ring-4 focus:ring-blue-600/10 outline-none text-sm font-bold bg-white shadow-sm transition-all"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
        </div>

        {/* Product Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 xl:grid-cols-4 2xl:grid-cols-5 gap-3 md:gap-4 overflow-y-auto scrollbar-hide pb-10">
          {filteredProducts.length === 0 ? (
            <div className="col-span-full py-20 text-center opacity-30">
              <LayoutGrid size={64} className="mx-auto mb-4" strokeWidth={1}/>
              <p className="text-xs font-black uppercase tracking-widest">No products found</p>
            </div>
          ) : (
            filteredProducts.map(product => {
              const outOfStock = product.stock <= 0;
              return (
                <button
                  key={product.id}
                  onClick={() => addToCart(product)}
                  disabled={outOfStock}
                  className={`relative flex flex-col justify-between p-4 rounded-[1.5rem] border transition-all active:scale-95 text-left h-40 md:h-52 group
                    ${outOfStock ? 'bg-slate-100 border-slate-200 opacity-60' : 'bg-white border-slate-200 hover:border-blue-400 hover:shadow-xl'}
                  `}
                >
                  <div className="space-y-1">
                    <h4 className="font-black text-slate-900 text-[10px] md:text-xs leading-tight uppercase tracking-tighter line-clamp-2">{product.name}</h4>
                    <p className="text-[8px] font-black text-slate-400 uppercase tracking-widest">{product.category}</p>
                  </div>
                  
                  <div className="mt-auto">
                    <div className={`text-[8px] font-black uppercase px-2 py-0.5 rounded-lg mb-2 inline-block ${outOfStock ? 'bg-rose-100 text-rose-600' : 'bg-blue-50 text-blue-600'}`}>
                      {outOfStock ? 'Out' : `Stock: ${product.stock}`}
                    </div>
                    <div className="flex justify-between items-end">
                      <p className="text-sm md:text-lg font-black text-slate-900 leading-none">
                        {product.sellPrice.toLocaleString()} 
                        <span className="text-[9px] ml-0.5 opacity-40 font-bold">{data.settings.currency}</span>
                      </p>
                      <div className="p-2 bg-blue-50 rounded-xl text-blue-600 group-hover:bg-blue-600 group-hover:text-white transition-all shadow-sm">
                        <Plus size={14} strokeWidth={3} />
                      </div>
                    </div>
                  </div>
                </button>
              );
            })
          )}
        </div>

        {/* Mobile View Cart Bar */}
        {cart.length > 0 && (
          <div className="lg:hidden fixed bottom-20 left-4 right-4 z-40 animate-in slide-in-from-bottom-10">
            <button 
              onClick={() => setViewMode('cart')}
              className="w-full bg-slate-900 text-white p-4 rounded-2xl flex items-center justify-between shadow-2xl border border-white/10"
            >
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-blue-600 rounded-xl flex items-center justify-center relative">
                  <ShoppingCart size={20} />
                  <span className="absolute -top-2 -right-2 bg-rose-500 text-white text-[10px] font-black w-5 h-5 rounded-full flex items-center justify-center border-2 border-slate-900">{cart.length}</span>
                </div>
                <div className="text-left">
                  <p className="text-[10px] font-black uppercase tracking-widest leading-none text-white/50">Proceed to Cart</p>
                  <p className="text-sm font-black">{total.toLocaleString()} {data.settings.currency}</p>
                </div>
              </div>
              <ArrowRight size={20} className="text-blue-500" />
            </button>
          </div>
        )}
      </div>

      {/* 2. CHECKOUT SECTION */}
      <div className={`lg:w-[400px] xl:w-[450px] shrink-0 flex flex-col pb-24 lg:pb-0 ${viewMode === 'products' ? 'hidden lg:flex' : 'flex'}`}>
        <div className="bg-white rounded-[2rem] lg:rounded-[2.5rem] border border-slate-200 shadow-xl lg:shadow-md flex flex-col sticky top-24 max-h-[calc(100vh-140px)]">
          
          <div className="p-6 border-b border-slate-50 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="lg:hidden p-2 bg-slate-100 rounded-xl" onClick={() => setViewMode('products')}>
                <X size={20} className="text-slate-600" />
              </div>
              <ShoppingBag className="text-blue-600" size={22} />
              <h3 className="font-black text-xs uppercase tracking-[0.2em]">{t.pos}</h3>
            </div>
            <span className="bg-blue-50 text-blue-600 px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest">{cart.length} items</span>
          </div>

          <div className="flex-1 overflow-y-auto p-5 space-y-3 scrollbar-hide min-h-[150px]">
            {cart.length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center opacity-20 py-20 text-center">
                <ShoppingCart size={48} className="mb-4" />
                <p className="text-[10px] font-black uppercase tracking-widest">Cart is empty</p>
              </div>
            ) : (
              cart.map(item => (
                <div key={item.productId} className="flex flex-col gap-2 p-4 bg-slate-50 rounded-[1.5rem] border border-slate-100">
                  <div className="flex justify-between items-start gap-3">
                    <span className="font-black text-[10px] md:text-xs uppercase text-slate-800 leading-tight flex-1">{item.name}</span>
                    <button onClick={() => removeFromCart(item.productId)} className="text-slate-300 hover:text-rose-500 transition-colors p-1"><Trash2 size={16} /></button>
                  </div>
                  <div className="flex justify-between items-center">
                    <div className="flex items-center bg-white rounded-xl p-1 shadow-sm border border-slate-100">
                      <button onClick={() => updateQuantity(item.productId, -1)} className="w-8 h-8 flex items-center justify-center text-slate-400 hover:text-blue-600"><Minus size={14} /></button>
                      <span className="w-8 text-center text-xs font-black">{item.quantity}</span>
                      <button onClick={() => updateQuantity(item.productId, 1)} className="w-8 h-8 flex items-center justify-center text-slate-400 hover:text-blue-600"><Plus size={14} /></button>
                    </div>
                    <span className="font-black text-xs text-blue-600">{item.total.toLocaleString()} {data.settings.currency}</span>
                  </div>
                </div>
              ))
            )}
          </div>

          <div className="p-6 bg-white border-t border-slate-100 space-y-4">
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1">
                <label className="text-[9px] font-black uppercase text-slate-400 ml-2 tracking-widest">Customer</label>
                <select className="w-full p-4 rounded-xl border border-slate-200 text-[10px] font-black uppercase bg-slate-50 outline-none" value={customerId} onChange={(e) => setCustomerId(e.target.value)}>
                  {data.customers.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                </select>
              </div>
              <div className="space-y-1">
                <label className="text-[9px] font-black uppercase text-rose-500 ml-2 tracking-widest">Discount</label>
                <input type="number" inputMode="decimal" className="w-full p-4 rounded-xl border border-rose-100 text-[10px] font-black bg-rose-50/30 outline-none" placeholder="0" value={discount || ''} onChange={(e) => setDiscount(Number(e.target.value))} />
              </div>
            </div>

            <div className="flex gap-1 p-1 bg-slate-100 rounded-xl">
              {[
                { id: 'Cash', icon: Banknote },
                { id: 'Due', icon: Wallet },
                { id: 'Partial', icon: CreditCard }
              ].map(mode => (
                <button key={mode.id} onClick={() => setPaymentMode(mode.id as PaymentMode)} className={`flex-1 py-3 rounded-lg flex flex-col items-center gap-1.5 transition-all ${paymentMode === mode.id ? 'bg-white text-blue-600 shadow-sm scale-[1.02]' : 'text-slate-400'}`}>
                  <mode.icon size={16} />
                  <span className="text-[8px] font-black uppercase">{mode.id}</span>
                </button>
              ))}
            </div>

            {paymentMode === 'Partial' && (
              <div className="space-y-1">
                <label className="text-[9px] font-black uppercase text-indigo-600 ml-2 tracking-widest">Cash Received</label>
                <input type="number" inputMode="decimal" className="w-full p-4 rounded-xl border-2 border-indigo-100 bg-indigo-50/50 text-xl font-black text-center outline-none" value={paidAmount || ''} onChange={(e) => setPaidAmount(Number(e.target.value))} />
              </div>
            )}

            <div className="p-5 bg-slate-900 rounded-[2rem] flex justify-between items-center text-white">
              <div className="flex flex-col">
                <span className="text-[9px] font-black uppercase opacity-40">Grand Total</span>
                <span className="text-xs font-bold text-blue-400">{paymentMode}</span>
              </div>
              <span className="text-2xl font-black">{total.toLocaleString()} {data.settings.currency}</span>
            </div>

            <button 
              onClick={handleCheckout} 
              className="w-full py-5 bg-blue-600 text-white rounded-[1.75rem] font-black text-sm uppercase tracking-[0.3em] shadow-xl hover:bg-blue-700 active:scale-95 transition-all flex items-center justify-center gap-3"
            >
              <Save size={20} /> {t.savePrint}
            </button>
          </div>
        </div>
      </div>

      {/* 3. RECEIPT PREVIEW MODAL */}
      {showWebPreview && lastSale && (
        <div className="fixed inset-0 bg-slate-900/95 backdrop-blur-2xl z-[100] flex items-center justify-center p-4 overflow-y-auto no-print">
           <div className="bg-white rounded-[2.5rem] lg:rounded-[3rem] shadow-2xl p-6 md:p-10 w-full max-w-2xl flex flex-col animate-in zoom-in duration-300 max-h-[95vh]">
                <div className="flex justify-between items-center mb-6 border-b pb-6">
                    <div className="flex items-center gap-4">
                        <div className="w-12 h-12 md:w-14 md:h-14 bg-emerald-100 text-emerald-600 rounded-2xl flex items-center justify-center">
                            <CheckCircle2 size={32}/>
                        </div>
                        <div>
                          <h3 className="text-xl md:text-2xl font-black uppercase tracking-tighter">Sale Confirmed</h3>
                          <p className="text-[10px] md:text-[11px] font-black text-slate-400 uppercase tracking-widest mt-1">
                             Invoice: #{lastSale.invoiceNo}
                          </p>
                        </div>
                    </div>
                    <button onClick={() => setShowWebPreview(false)} className="p-4 bg-slate-100 rounded-full"><X size={20}/></button>
                </div>
                
                <div className="flex-1 overflow-y-auto bg-white rounded-[2rem] flex justify-center p-4 md:p-10 border border-slate-100 mb-8 scrollbar-hide shadow-inner overflow-x-hidden">
                    <div id="receipt-print-area" className="w-full flex justify-center">
                        <Receipt 
                          sale={lastSale} 
                          settings={data.settings} 
                          customer={data.customers.find(c => c.id === lastSale.customerId)} 
                          layout={printLayout} 
                          showInPreview={true} 
                        />
                    </div>
                </div>
                
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <button 
                      onClick={() => setPrintLayout(printLayout === 'thermal' ? 'full' : 'thermal')} 
                      className="py-4 border-2 border-slate-100 rounded-2xl flex items-center justify-center gap-3 font-black text-[10px] uppercase tracking-widest text-slate-500 hover:border-blue-600 hover:text-blue-600 transition-all"
                    >
                      <ReceiptIcon size={18}/> Switch to {printLayout === 'thermal' ? 'A4 Size' : '58mm Thermal'}
                    </button>
                    <button 
                      onClick={triggerPDFDownload} 
                      disabled={isGeneratingPDF} 
                      className={`py-4 bg-blue-600 text-white rounded-2xl font-black uppercase text-[10px] tracking-widest shadow-xl flex items-center justify-center gap-3 active:scale-95 transition-all ${isGeneratingPDF ? 'opacity-50' : ''}`}
                    >
                      {isGeneratingPDF ? "Generating..." : <><Download size={20}/> Download {printLayout === 'thermal' ? '58mm PDF' : 'A4 PDF'}</>}
                    </button>
                </div>
                
                <div className="mt-6 flex flex-col sm:flex-row gap-4 no-print">
                   <button 
                     onClick={() => { window.print(); }}
                     className="flex-1 py-4 bg-slate-900 text-white rounded-2xl font-black uppercase text-[10px] tracking-widest flex items-center justify-center gap-2"
                   >
                     <Printer size={18}/> Direct Browser Print
                   </button>
                   <button 
                      onClick={() => setShowWebPreview(false)} 
                      className="flex-1 py-4 text-slate-400 font-black text-[10px] uppercase tracking-widest hover:text-slate-900 transition-colors"
                    >
                      Start New Sale <ChevronRight size={14} className="inline ml-1"/>
                    </button>
                </div>
           </div>
        </div>
      )}

      {/* HIDDEN PRINT AREA */}
      <div id="receipt-download-container" className="print-only">
          {lastSale && (
              <Receipt 
                sale={lastSale} 
                settings={data.settings} 
                customer={data.customers.find(c => c.id === lastSale.customerId)} 
                layout={printLayout} 
              />
          )}
      </div>
    </div>
  );
};

export default POS;