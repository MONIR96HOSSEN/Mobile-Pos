
import React, { useState, useMemo } from 'react';
import { useStore } from '../store';
import { 
    Plus, 
    Calendar, 
    Clock, 
    Trash2, 
    CheckCircle2, 
    Circle, 
    X, 
    Filter,
    ArrowLeft,
    ArrowRight,
    Search,
    AlertCircle,
    Bell,
    CheckSquare
} from 'lucide-react';
import { Reminder, Priority } from '../types';

const Reminders: React.FC = () => {
    const { data, addReminder, updateReminder, deleteReminder, toggleReminder, language } = useStore();
    const [selectedDate, setSelectedDate] = useState<string>(new Date().toISOString().split('T')[0]);
    const [viewMonth, setViewMonth] = useState<Date>(new Date());
    const [showForm, setShowForm] = useState(false);
    const [filterStatus, setFilterStatus] = useState<'All' | 'Pending' | 'Completed'>('All');
    const [searchTerm, setSearchTerm] = useState('');

    const [formData, setFormData] = useState({
        title: '',
        description: '',
        date: new Date().toISOString().split('T')[0],
        time: new Date().toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' }),
        priority: 'Medium' as Priority
    });

    const remindersForDay = useMemo(() => {
        return data.reminders.filter(r => {
            const matchesDate = r.date === selectedDate;
            const matchesSearch = r.title.toLowerCase().includes(searchTerm.toLowerCase()) || 
                                r.description.toLowerCase().includes(searchTerm.toLowerCase());
            const matchesFilter = filterStatus === 'All' ? true : 
                                filterStatus === 'Completed' ? r.completed : !r.completed;
            return matchesDate && matchesSearch && matchesFilter;
        }).sort((a, b) => a.time.localeCompare(b.time));
    }, [data.reminders, selectedDate, searchTerm, filterStatus]);

    const calendarDays = useMemo(() => {
        const year = viewMonth.getFullYear();
        const month = viewMonth.getMonth();
        const firstDay = new Date(year, month, 1);
        const lastDay = new Date(year, month + 1, 0);
        const days = [];
        
        // Pad start
        const startPadding = firstDay.getDay();
        for (let i = 0; i < startPadding; i++) {
            days.push(null);
        }

        // Days in month
        for (let i = 1; i <= lastDay.getDate(); i++) {
            const dateStr = `${year}-${String(month + 1).padStart(2, '0')}-${String(i).padStart(2, '0')}`;
            days.push({
                day: i,
                dateStr,
                hasReminders: data.reminders.some(r => r.date === dateStr && !r.completed),
                hasCompleted: data.reminders.some(r => r.date === dateStr && r.completed)
            });
        }
        return days;
    }, [viewMonth, data.reminders]);

    const handleAdd = (e: React.FormEvent) => {
        e.preventDefault();
        addReminder(formData);
        setShowForm(false);
        setFormData({
            title: '',
            description: '',
            date: selectedDate,
            time: '12:00',
            priority: 'Medium'
        });
    };

    const changeMonth = (delta: number) => {
        const next = new Date(viewMonth);
        next.setMonth(viewMonth.getMonth() + delta);
        setViewMonth(next);
    };

    return (
        <div className="space-y-6 pb-24">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
                <div>
                    <h2 className="text-3xl font-black text-slate-900 tracking-tighter uppercase leading-none">Smart Reminders</h2>
                    <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mt-1">Calendar & Note Engine</p>
                </div>
                <button 
                    onClick={() => {
                        setFormData({...formData, date: selectedDate});
                        setShowForm(true);
                    }}
                    className="w-full md:w-auto bg-indigo-600 text-white px-8 py-4 rounded-2xl flex items-center justify-center gap-3 hover:bg-indigo-700 transition-all font-black text-[10px] uppercase tracking-widest shadow-xl shadow-indigo-100"
                >
                    <Plus size={18} /> New Note / Reminder
                </button>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
                {/* Calendar Panel */}
                <div className="lg:col-span-5 bg-white p-6 rounded-[2.5rem] border border-slate-200 shadow-sm space-y-6">
                    <div className="flex justify-between items-center px-2">
                        <button onClick={() => changeMonth(-1)} className="p-2 hover:bg-slate-100 rounded-xl transition-colors"><ArrowLeft size={18}/></button>
                        <h3 className="font-black text-xs uppercase tracking-[0.2em] text-slate-800">
                            {viewMonth.toLocaleString('default', { month: 'long', year: 'numeric' })}
                        </h3>
                        <button onClick={() => changeMonth(1)} className="p-2 hover:bg-slate-100 rounded-xl transition-colors"><ArrowRight size={18}/></button>
                    </div>

                    <div className="grid grid-cols-7 text-center">
                        {['S', 'M', 'T', 'W', 'T', 'F', 'S'].map(d => (
                            <div key={d} className="text-[9px] font-black text-slate-400 py-2">{d}</div>
                        ))}
                        {calendarDays.map((d, idx) => {
                            if (!d) return <div key={`pad-${idx}`} className="h-12" />;
                            const isSelected = d.dateStr === selectedDate;
                            const isToday = d.dateStr === new Date().toISOString().split('T')[0];
                            return (
                                <button
                                    key={d.dateStr}
                                    onClick={() => setSelectedDate(d.dateStr)}
                                    className={`
                                        h-12 relative flex flex-col items-center justify-center rounded-2xl transition-all font-bold text-xs
                                        ${isSelected ? 'bg-indigo-600 text-white shadow-lg scale-110 z-10' : 'hover:bg-slate-50 text-slate-700'}
                                        ${isToday && !isSelected ? 'border-2 border-indigo-100' : ''}
                                    `}
                                >
                                    {d.day}
                                    <div className="flex gap-0.5 absolute bottom-1.5">
                                        {d.hasReminders && <div className={`w-1 h-1 rounded-full ${isSelected ? 'bg-white' : 'bg-rose-500'}`} />}
                                        {d.hasCompleted && <div className={`w-1 h-1 rounded-full ${isSelected ? 'bg-indigo-200' : 'bg-emerald-400'}`} />}
                                    </div>
                                </button>
                            );
                        })}
                    </div>

                    <div className="pt-4 border-t border-slate-50 flex gap-4">
                        <div className="flex items-center gap-1.5">
                            <div className="w-1.5 h-1.5 rounded-full bg-rose-500" />
                            <span className="text-[8px] font-black uppercase text-slate-400 tracking-widest">Pending</span>
                        </div>
                        <div className="flex items-center gap-1.5">
                            <div className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
                            <span className="text-[8px] font-black uppercase text-slate-400 tracking-widest">Done</span>
                        </div>
                    </div>
                </div>

                {/* Timeline Panel */}
                <div className="lg:col-span-7 space-y-4">
                    <div className="bg-white p-4 rounded-[1.75rem] border border-slate-200 flex flex-col md:flex-row gap-4 items-center no-print">
                        <div className="relative flex-1 w-full">
                            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={16} />
                            <input 
                                type="text" 
                                placeholder="Search note content..." 
                                className="w-full pl-11 pr-4 py-3 bg-slate-50 border-none rounded-xl text-xs font-bold outline-none focus:ring-2 focus:ring-indigo-600 transition-all"
                                value={searchTerm}
                                onChange={(e) => setSearchTerm(e.target.value)}
                            />
                        </div>
                        <div className="flex gap-1 p-1 bg-slate-50 rounded-xl w-full md:w-auto overflow-x-auto scrollbar-hide">
                            {['All', 'Pending', 'Completed'].map((s) => (
                                <button
                                    key={s}
                                    onClick={() => setFilterStatus(s as any)}
                                    className={`px-4 py-2 text-[8px] font-black uppercase rounded-lg transition-all whitespace-nowrap ${filterStatus === s ? 'bg-white text-indigo-600 shadow-sm' : 'text-slate-400 hover:text-slate-600'}`}
                                >
                                    {s}
                                </button>
                            ))}
                        </div>
                    </div>

                    <div className="space-y-4">
                        <div className="flex items-center gap-3 px-2">
                            <Calendar className="text-indigo-600" size={18}/>
                            <h3 className="font-black text-[11px] uppercase tracking-[0.2em] text-slate-900">
                                {new Date(selectedDate).toLocaleDateString('default', { weekday: 'long', day: 'numeric', month: 'long' })}
                            </h3>
                        </div>

                        {remindersForDay.length === 0 ? (
                            <div className="bg-white py-20 rounded-[2.5rem] border border-slate-200 border-dashed flex flex-col items-center justify-center opacity-40">
                                <Bell size={48} className="mb-4 text-slate-300" strokeWidth={1} />
                                <p className="text-[10px] font-black uppercase tracking-[0.3em]">No notes for this date</p>
                            </div>
                        ) : (
                            <div className="grid gap-3">
                                {remindersForDay.map(rem => (
                                    <div 
                                        key={rem.id} 
                                        className={`
                                            group bg-white p-5 rounded-[2rem] border transition-all shadow-sm flex items-start gap-4
                                            ${rem.completed ? 'opacity-60 border-slate-100 grayscale' : 'border-slate-200 hover:border-indigo-100 hover:shadow-xl'}
                                        `}
                                    >
                                        <button 
                                            onClick={() => toggleReminder(rem.id)}
                                            className={`p-2 rounded-xl transition-all ${rem.completed ? 'bg-emerald-50 text-emerald-600' : 'bg-slate-50 text-slate-300 group-hover:text-indigo-600'}`}
                                        >
                                            {rem.completed ? <CheckCircle2 size={24}/> : <Circle size={24}/>}
                                        </button>
                                        
                                        <div className="flex-1 min-w-0">
                                            <div className="flex justify-between items-start mb-1">
                                                <h4 className={`text-sm font-black uppercase tracking-tight leading-none ${rem.completed ? 'line-through text-slate-400' : 'text-slate-900'}`}>{rem.title}</h4>
                                                <span className={`px-2 py-0.5 rounded-lg text-[8px] font-black uppercase tracking-widest ${rem.priority === 'High' ? 'bg-rose-50 text-rose-500' : rem.priority === 'Medium' ? 'bg-amber-50 text-amber-500' : 'bg-indigo-50 text-indigo-500'}`}>
                                                    {rem.priority}
                                                </span>
                                            </div>
                                            <p className="text-[10px] font-medium text-slate-500 line-clamp-2 leading-relaxed uppercase mb-3">{rem.description}</p>
                                            
                                            <div className="flex items-center justify-between">
                                                <div className="flex items-center gap-2 text-indigo-600">
                                                    <Clock size={12}/>
                                                    <span className="text-[10px] font-black tracking-widest">{rem.time}</span>
                                                </div>
                                                <button 
                                                    onClick={() => deleteReminder(rem.id)}
                                                    className="p-2 text-rose-300 hover:text-rose-600 hover:bg-rose-50 rounded-xl transition-all opacity-0 group-hover:opacity-100"
                                                >
                                                    <Trash2 size={16}/>
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        )}
                    </div>
                </div>
            </div>

            {/* Form Modal */}
            {showForm && (
                <div className="fixed inset-0 bg-slate-900/80 backdrop-blur-md z-[150] flex items-end sm:items-center justify-center p-4">
                    <div className="bg-white w-full max-w-md rounded-t-[3rem] sm:rounded-[3rem] shadow-2xl overflow-hidden animate-slide-up sm:animate-in sm:zoom-in">
                        <div className="px-8 py-6 bg-indigo-600 text-white flex justify-between items-center">
                            <h3 className="font-black text-xs uppercase tracking-widest">Draft New Reminder</h3>
                            <button onClick={() => setShowForm(null)} className="p-2 hover:bg-white/10 rounded-full transition-colors"><X size={24}/></button>
                        </div>
                        <form onSubmit={handleAdd} className="p-8 space-y-6">
                            <div className="space-y-4">
                                <div className="space-y-1">
                                    <label className="text-[9px] font-black uppercase text-slate-400 ml-2 tracking-widest">Subject</label>
                                    <input 
                                        type="text" 
                                        required 
                                        placeholder="e.g. Call Supplier A"
                                        className="w-full p-4 border border-slate-200 rounded-xl font-bold bg-slate-50 outline-none focus:ring-2 focus:ring-indigo-600" 
                                        value={formData.title} 
                                        onChange={(e) => setFormData({ ...formData, title: e.target.value })} 
                                    />
                                </div>
                                <div className="grid grid-cols-2 gap-4">
                                    <div className="space-y-1">
                                        <label className="text-[9px] font-black uppercase text-slate-400 ml-2 tracking-widest">Date</label>
                                        <input type="date" required className="w-full p-4 border border-slate-200 rounded-xl font-bold bg-slate-50 outline-none" value={formData.date} onChange={(e) => setFormData({ ...formData, date: e.target.value })} />
                                    </div>
                                    <div className="space-y-1">
                                        <label className="text-[9px] font-black uppercase text-slate-400 ml-2 tracking-widest">Time</label>
                                        <input type="time" required className="w-full p-4 border border-slate-200 rounded-xl font-bold bg-slate-50 outline-none" value={formData.time} onChange={(e) => setFormData({ ...formData, time: e.target.value })} />
                                    </div>
                                </div>
                                <div className="space-y-1">
                                    <label className="text-[9px] font-black uppercase text-slate-400 ml-2 tracking-widest">Priority Rank</label>
                                    <div className="flex gap-2">
                                        {(['Low', 'Medium', 'High'] as Priority[]).map(p => (
                                            <button
                                                key={p}
                                                type="button"
                                                onClick={() => setFormData({...formData, priority: p})}
                                                className={`flex-1 py-3 rounded-xl text-[8px] font-black uppercase transition-all border-2 ${formData.priority === p ? 'bg-indigo-600 text-white border-indigo-600 shadow-md' : 'bg-slate-50 text-slate-400 border-slate-100 hover:border-indigo-100'}`}
                                            >
                                                {p}
                                            </button>
                                        ))}
                                    </div>
                                </div>
                                <div className="space-y-1">
                                    <label className="text-[9px] font-black uppercase text-slate-400 ml-2 tracking-widest">Context / Notes</label>
                                    <textarea 
                                        rows={3} 
                                        className="w-full p-4 border border-slate-200 rounded-xl font-bold bg-slate-50 outline-none focus:ring-2 focus:ring-indigo-600" 
                                        value={formData.description} 
                                        onChange={(e) => setFormData({ ...formData, description: e.target.value })} 
                                    />
                                </div>
                            </div>
                            <button type="submit" className="w-full py-5 bg-indigo-600 text-white rounded-2xl font-black uppercase text-[10px] tracking-widest shadow-xl active:scale-95 transition-all">
                                Secure Entry
                            </button>
                        </form>
                    </div>
                </div>
            )}
        </div>
    );
};

export default Reminders;
