import React, { useState, useMemo } from 'react';
import { useStore } from '../store';
import { 
    RotateCcw, 
    Trash2, 
    Plus, 
    Search, 
    X, 
    ShoppingCart, 
    ArrowDownToLine, 
    AlertTriangle,
    Calendar,
    ChevronRight,
    ShoppingBag
} from 'lucide-react';
import { SaleItem, Product, Sale, Purchase } from '../types';

type ReturnTab = 'Sale' | 'Purchase' | 'Wastage';

const Returns: React.FC = () => {
    const { 
        data, 
        addSaleReturn, 
        deleteSaleReturn, 
        addPurchaseReturn, 
        deletePurchaseReturn, 
        addWastage, 
        deleteWastage, 
        language, 
        currentUser 
    } = useStore();
    const [activeTab, setActiveTab] = useState<ReturnTab>('Sale');
    const [searchTerm, setSearchTerm] = useState('');
    
    // Selection state for forms
    const [selectedOriginalId, setSelectedOriginalId] = useState('');
    const [returnItems, setReturnItems] = useState<SaleItem[]>([]);
    const [reason, setReason] = useState('');
    const [wastageData, setWastageData] = useState({ productId: '', quantity: 0, reason: '' });

    const isOwner = currentUser?.role === 'Owner';

    // Filter Logic
    const historyList = useMemo(() => {
        let baseList: any[] = [];
        if (activeTab === 'Sale') baseList = data.saleReturns;
        else if (activeTab === 'Purchase') baseList = data.purchaseReturns;
        else baseList = data.wastages;

        if (!searchTerm) return baseList;

        const term = searchTerm.toLowerCase();
        return baseList.filter(item => {
            if (activeTab === 'Wastage') {
                const prod = data.products.find(p => p.id === item.productId);
                return prod?.name.toLowerCase().includes(term) || item.reason?.toLowerCase().includes(term);
            }
            return item.id.toLowerCase().includes(term) || item.reason?.toLowerCase().includes(term);
        });
    }, [activeTab, data, searchTerm]);

    const handleProcessSaleReturn = (e: React.FormEvent) => {
        e.preventDefault();
        if (!selectedOriginalId || returnItems.length === 0) return;
        const total = returnItems.reduce((s, i) => s + i.total, 0);
        addSaleReturn({
            date: new Date().toISOString(),
            saleId: selectedOriginalId,
            items: returnItems,
            total,
            reason
        });
        resetForm();
    };

    const handleProcessPurchaseReturn = (e: React.FormEvent) => {
        e.preventDefault();
        if (!selectedOriginalId || returnItems.length === 0) return;
        const total = returnItems.reduce((s, i) => s + i.total, 0);
        addPurchaseReturn({
            date: new Date().toISOString(),
            purchaseId: selectedOriginalId,
            items: returnItems,
            total,
            reason
        });
        resetForm();
    };

    const handleProcessWastage = (e: React.FormEvent) => {
        e.preventDefault();
        const product = data.products.find(p => p.id === wastageData.productId);
        if (!product || wastageData.quantity <= 0) return;
        addWastage({
            date: new Date().toISOString(),
            productId: wastageData.productId,
            quantity: wastageData.quantity,
            reason: wastageData.reason,
            lossValue: product.buyPrice * wastageData.quantity
        });
        resetForm();
    };

    const handleDelete = (id: string) => {
        if (!isOwner) return;
        const confirmed = window.confirm(`Are you sure you want to delete this ${activeTab} record? This will reverse all impacts on stock and balances.`);
        if (!confirmed) return;

        if (activeTab === 'Sale') deleteSaleReturn(id);
        else if (activeTab === 'Purchase') deletePurchaseReturn(id);
        else if (activeTab === 'Wastage') deleteWastage(id);
    };

    const resetForm = () => {
        setSelectedOriginalId('');
        setReturnItems([]);
        setReason('');
        setWastageData({ productId: '', quantity: 0, reason: '' });
    };

    const selectedOriginalSale = useMemo(() => 
        data.sales.find(s => s.id === selectedOriginalId), [selectedOriginalId, data.sales]);

    const selectedOriginalPurchase = useMemo(() => 
        data.purchases.find(p => p.id === selectedOriginalId), [selectedOriginalId, data.purchases]);

    const addItemToReturn = (item: SaleItem) => {
        setReturnItems(prev => {
            const exists = prev.find(i => i.productId === item.productId);
            if (exists) return prev;
            return [...prev, { ...item, quantity: 1, total: item.price }];
        });
    };

    return (
        <div className="space-y-6 pb-24">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                <div>
                    <h2 className="text-3xl font-black text-slate-900 tracking-tighter uppercase leading-none">Returns & Wastage</h2>
                    <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mt-1">Inventory Correction Hub</p>
                </div>
                <div className="flex bg-white border border-slate-200 rounded-[1.5rem] p-1.5 shadow-sm overflow-x-auto scrollbar-hide w-full md:w-auto">
                    {(['Sale', 'Purchase', 'Wastage'] as ReturnTab[]).map((tab) => (
                        <button
                            key={tab}
                            onClick={() => { setActiveTab(tab); resetForm(); }}
                            className={`flex-1 md:flex-none px-6 py-2.5 text-[10px] font-black rounded-xl transition-all uppercase tracking-widest ${activeTab === tab ? 'bg-indigo-600 text-white shadow-lg' : 'text-slate-400 hover:bg-slate-50'}`}
                        >
                            {tab}
                        </button>
                    ))}
                </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
                {/* Form Section */}
                <div className="lg:col-span-5 bg-white p-6 md:p-8 rounded-[2.5rem] border border-slate-200 shadow-sm space-y-6 h-fit">
                    <h3 className="font-black text-xs uppercase tracking-[0.2em] flex items-center gap-2">
                        <Plus size={18} className="text-indigo-600" />
                        Record New {activeTab === 'Wastage' ? 'Waste' : 'Return'}
                    </h3>

                    {activeTab === 'Sale' && (
                        <form onSubmit={handleProcessSaleReturn} className="space-y-4">
                            <div>
                                <label className="text-[9px] font-black text-slate-400 uppercase tracking-widest ml-2">Select Invoice</label>
                                <select className="w-full p-4 border border-slate-200 rounded-xl font-bold bg-slate-50 outline-none focus:ring-2 focus:ring-indigo-600" value={selectedOriginalId} onChange={e => setSelectedOriginalId(e.target.value)}>
                                    <option value="">Choose Sale Invoice...</option>
                                    {data.sales.map(s => <option key={s.id} value={s.id}>#{s.invoiceNo} - {data.customers.find(c => c.id === s.customerId)?.name}</option>)}
                                </select>
                            </div>

                            {selectedOriginalSale && (
                                <div className="space-y-4">
                                    <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest ml-2">Click items to return</p>
                                    <div className="flex flex-wrap gap-2">
                                        {selectedOriginalSale.items.map((item, idx) => (
                                            <button type="button" key={idx} onClick={() => addItemToReturn(item)} className="px-4 py-2 bg-slate-100 rounded-xl text-[10px] font-black uppercase hover:bg-indigo-50 hover:text-indigo-600 transition-all">
                                                {item.name}
                                            </button>
                                        ))}
                                    </div>
                                    <div className="space-y-2">
                                        {returnItems.map(ri => (
                                            <div key={ri.productId} className="flex items-center justify-between p-3 bg-indigo-50 rounded-xl border border-indigo-100">
                                                <span className="text-[10px] font-black uppercase">{ri.name}</span>
                                                <div className="flex items-center gap-3">
                                                    <input type="number" className="w-16 p-1 text-center bg-white border rounded text-xs font-bold" value={ri.quantity} onChange={e => setReturnItems(prev => prev.map(i => i.productId === ri.productId ? {...i, quantity: Number(e.target.value), total: Number(e.target.value) * i.price} : i))}/>
                                                    <button type="button" onClick={() => setReturnItems(prev => prev.filter(i => i.productId !== ri.productId))}><X size={14} className="text-rose-500"/></button>
                                                </div>
                                            </div>
                                        ))}
                                    </div>
                                    <textarea placeholder="Reason for return..." className="w-full p-4 border border-slate-200 rounded-xl font-bold bg-slate-50 outline-none" rows={2} value={reason} onChange={e => setReason(e.target.value)} />
                                    <button type="submit" className="w-full py-5 bg-indigo-600 text-white rounded-2xl font-black uppercase text-[10px] tracking-widest shadow-xl">Complete Return</button>
                                </div>
                            )}
                        </form>
                    )}

                    {activeTab === 'Purchase' && (
                        <form onSubmit={handleProcessPurchaseReturn} className="space-y-4">
                            <div>
                                <label className="text-[9px] font-black text-slate-400 uppercase tracking-widest ml-2">Select Purchase</label>
                                <select className="w-full p-4 border border-slate-200 rounded-xl font-bold bg-slate-50 outline-none focus:ring-2 focus:ring-rose-600" value={selectedOriginalId} onChange={e => setSelectedOriginalId(e.target.value)}>
                                    <option value="">Choose Purchase Entry...</option>
                                    {data.purchases.map(p => <option key={p.id} value={p.id}>Ref: #{p.id.slice(-6)} - {data.suppliers.find(s => s.id === p.supplierId)?.name}</option>)}
                                </select>
                            </div>

                            {selectedOriginalPurchase && (
                                <div className="space-y-4">
                                    <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest ml-2">Click items to return</p>
                                    <div className="flex flex-wrap gap-2">
                                        {selectedOriginalPurchase.items.map((item, idx) => (
                                            <button type="button" key={idx} onClick={() => addItemToReturn(item)} className="px-4 py-2 bg-slate-100 rounded-xl text-[10px] font-black uppercase hover:bg-rose-50 hover:text-rose-600 transition-all">
                                                {item.name}
                                            </button>
                                        ))}
                                    </div>
                                    <div className="space-y-2">
                                        {returnItems.map(ri => (
                                            <div key={ri.productId} className="flex items-center justify-between p-3 bg-rose-50 rounded-xl border border-rose-100">
                                                <span className="text-[10px] font-black uppercase">{ri.name}</span>
                                                <div className="flex items-center gap-3">
                                                    <input type="number" className="w-16 p-1 text-center bg-white border rounded text-xs font-bold" value={ri.quantity} onChange={e => setReturnItems(prev => prev.map(i => i.productId === ri.productId ? {...i, quantity: Number(e.target.value), total: Number(e.target.value) * i.price} : i))}/>
                                                    <button type="button" onClick={() => setReturnItems(prev => prev.filter(i => i.productId !== ri.productId))}><X size={14} className="text-rose-500"/></button>
                                                </div>
                                            </div>
                                        ))}
                                    </div>
                                    <textarea placeholder="Reason for return..." className="w-full p-4 border border-slate-200 rounded-xl font-bold bg-slate-50 outline-none" rows={2} value={reason} onChange={e => setReason(e.target.value)} />
                                    <button type="submit" className="w-full py-5 bg-rose-600 text-white rounded-2xl font-black uppercase text-[10px] tracking-widest shadow-xl">Complete Return</button>
                                </div>
                            )}
                        </form>
                    )}

                    {activeTab === 'Wastage' && (
                        <form onSubmit={handleProcessWastage} className="space-y-4">
                            <div>
                                <label className="text-[9px] font-black text-slate-400 uppercase tracking-widest ml-2">Select Damaged Product</label>
                                <select className="w-full p-4 border border-slate-200 rounded-xl font-bold bg-slate-50 outline-none focus:ring-2 focus:ring-amber-600" value={wastageData.productId} onChange={e => setWastageData({...wastageData, productId: e.target.value})}>
                                    <option value="">Choose Product...</option>
                                    {data.products.map(p => <option key={p.id} value={p.id}>{p.name} (Stock: {p.stock})</option>)}
                                </select>
                            </div>
                            <div>
                                <label className="text-[9px] font-black text-slate-400 uppercase tracking-widest ml-2">Quantity Wasted</label>
                                <input type="number" className="w-full p-4 border border-slate-200 rounded-xl font-bold bg-slate-50 outline-none" value={wastageData.quantity || ''} onChange={e => setWastageData({...wastageData, quantity: Number(e.target.value)})} />
                            </div>
                            <div>
                                <label className="text-[9px] font-black text-slate-400 uppercase tracking-widest ml-2">Reason (Broken, Expired, etc.)</label>
                                <textarea className="w-full p-4 border border-slate-200 rounded-xl font-bold bg-slate-50 outline-none" rows={2} value={wastageData.reason} onChange={e => setWastageData({...wastageData, reason: e.target.value})} />
                            </div>
                            <button type="submit" className="w-full py-5 bg-amber-600 text-white rounded-2xl font-black uppercase text-[10px] tracking-widest shadow-xl">Record Loss</button>
                        </form>
                    )}
                </div>

                {/* History Section */}
                <div className="lg:col-span-7 space-y-4">
                    <div className="bg-white p-4 rounded-[1.75rem] border border-slate-200 flex items-center gap-4">
                        <Search className="text-slate-400" size={18} />
                        <input type="text" placeholder={`Search ${activeTab} records...`} className="flex-1 text-xs font-bold outline-none uppercase tracking-widest" value={searchTerm} onChange={e => setSearchTerm(e.target.value)} />
                    </div>

                    <div className="space-y-3">
                        {historyList.length === 0 ? (
                            <div className="bg-white py-20 rounded-[2.5rem] border border-slate-200 border-dashed flex flex-col items-center justify-center opacity-40">
                                <RotateCcw size={48} className="mb-4 text-slate-300" strokeWidth={1} />
                                <p className="text-[10px] font-black uppercase tracking-[0.3em]">No {activeTab} Records</p>
                            </div>
                        ) : (
                            historyList.map((item: any) => (
                                <div key={item.id} className="group bg-white p-5 rounded-[2rem] border border-slate-200 shadow-sm hover:shadow-md transition-all relative overflow-hidden">
                                    <div className="flex justify-between items-start mb-3">
                                        <div className="flex items-center gap-3">
                                            <div className={`w-10 h-10 rounded-xl flex items-center justify-center font-black text-[10px] ${activeTab === 'Sale' ? 'bg-indigo-50 text-indigo-600' : activeTab === 'Purchase' ? 'bg-rose-50 text-rose-600' : 'bg-amber-50 text-amber-600'}`}>
                                                {activeTab.charAt(0)}
                                            </div>
                                            <div>
                                                <h4 className="font-black text-slate-900 uppercase text-xs tracking-tighter">
                                                    {activeTab === 'Wastage' 
                                                        ? data.products.find(p => p.id === item.productId)?.name 
                                                        : `REF: ${item.id.slice(-6)}`}
                                                </h4>
                                                <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest mt-1">
                                                    {new Date(item.date).toLocaleDateString()}
                                                </p>
                                            </div>
                                        </div>
                                        <div className="text-right flex items-start gap-3">
                                            <div className="text-right">
                                                <p className={`font-black text-lg ${activeTab === 'Sale' ? 'text-indigo-600' : activeTab === 'Purchase' ? 'text-rose-600' : 'text-amber-600'}`}>
                                                    {activeTab === 'Wastage' ? item.quantity : item.total} 
                                                    <span className="text-[9px] ml-1">{activeTab === 'Wastage' ? 'Units' : data.settings.currency}</span>
                                                </p>
                                            </div>
                                            {isOwner && (
                                                <button 
                                                    onClick={() => handleDelete(item.id)}
                                                    className="p-2 bg-rose-50 text-rose-400 rounded-xl hover:bg-rose-600 hover:text-white transition-all opacity-0 group-hover:opacity-100"
                                                >
                                                    <Trash2 size={16}/>
                                                </button>
                                            )}
                                        </div>
                                    </div>
                                    <div className="bg-slate-50 p-3 rounded-xl border border-slate-100 mb-2">
                                        <p className="text-[9px] font-bold text-slate-500 uppercase leading-relaxed italic line-clamp-2">
                                            {item.reason || "No reason specified"}
                                        </p>
                                    </div>
                                    {activeTab !== 'Wastage' && (
                                        <div className="flex flex-wrap gap-1">
                                            {item.items.map((i: any, idx: number) => (
                                                <span key={idx} className="bg-white px-2 py-0.5 rounded-lg border border-slate-200 text-[8px] font-black uppercase">
                                                    {i.name} x{i.quantity}
                                                </span>
                                            ))}
                                        </div>
                                    )}
                                </div>
                            ))
                        )}
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Returns;