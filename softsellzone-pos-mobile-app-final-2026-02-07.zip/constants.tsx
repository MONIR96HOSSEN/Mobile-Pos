
import { AppData } from './types';

export const INITIAL_DATA: AppData = {
  users: [
    { id: 'u1', username: 'admin', password: '123', role: 'Owner', name: 'Admin User' },
    { id: 'u2', username: 'staff', password: '123', role: 'Staff', name: 'Sales Staff' }
  ],
  products: [],
  customers: [
    { id: 'c1', name: 'Walk-in Customer', phone: '0000000000', address: 'N/A', balance: 0 },
  ],
  suppliers: [],
  sales: [],
  purchases: [],
  saleReturns: [],
  purchaseReturns: [],
  wastages: [],
  ledgers: [],
  expenses: [],
  reminders: [],
  settings: {
    name: 'softsellzone POS',
    address: 'Your Business Address Here',
    phone: '01XXXXXXXXX',
    email: 'contact@yourbusiness.com',
    logo: 'https://picsum.photos/100/100',
    currency: '৳',
    invoiceFooter: 'Thank you for choosing SoftSellZone Solutions!'
  }
};

export const TRANSLATIONS = {
  en: {
    dashboard: 'Dashboard',
    pos: 'POS Sales',
    salesList: 'Sales List',
    due: 'Dues',
    purchases: 'Purchases',
    expenses: 'Expenses',
    reminders: 'Notes & Reminders',
    returns: 'Returns & Wastage',
    customers: 'Customers',
    suppliers: 'Suppliers',
    inventory: 'Inventory',
    reports: 'Reports',
    settings: 'Settings',
    todaySales: "Today's Sales",
    todayDue: "Today's Due Collection",
    totalDue: "Total Customer Due",
    cashInHand: "Cash in Hand",
    searchProduct: "Search Product...",
    total: "Total",
    paid: "Paid",
    dueAmount: "Due",
    confirm: "Confirm",
    savePrint: "Save & Print",
    invoice: "Invoice",
    print: "Print Receipt",
    logout: "Logout",
    login: "Login",
    username: "Username",
    password: "Password"
  },
  bn: {
    dashboard: 'ড্যাশবোর্ড',
    pos: 'বিক্রয় (POS)',
    salesList: 'বিক্রয় তালিকা',
    due: 'বকেয়া হিসাব',
    purchases: 'ক্রয়',
    expenses: 'খরচ',
    reminders: 'নোট ও রিমাইন্ডার',
    returns: 'রিটার্ন ও ওয়েস্টেজ',
    customers: 'ক্রেতা',
    suppliers: 'সরবরাহকারী',
    inventory: 'স্টক/মালামাল',
    reports: 'রিপোর্ট',
    settings: 'সেটিংস',
    todaySales: "আজকের বিক্রি",
    todayDue: "আজকের বকেয়া সংগ্রহ",
    totalDue: "মোট বকেয়া",
    cashInHand: "নগদ টাকা",
    searchProduct: "পণ্য খুঁজুন...",
    total: "মোট",
    paid: "পরিশোধিত",
    dueAmount: "বকেয়া",
    confirm: "নিশ্চিত করুন",
    savePrint: "সেভ ও প্রিন্ট",
    invoice: "চালান/রসিদ",
    print: "প্রিন্ট রসিদ",
    logout: "লগ আউট",
    login: "লগইন",
    username: "ইউজার নেম",
    password: "পাসওয়ার্ড"
  }
};
